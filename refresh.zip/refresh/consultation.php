<!doctype html>
<html class="no-js" lang="zxx">

 <!-- Favicons - Place favicon.ico in the root directory -->
    <link rel="icon" type="image/png" size="16x16" href="assets/img/logo-1.png">
    <!-- <link rel="manifest" href="assets/img/favicons/manifest.json"> -->

<body>
    <?php include'header.php'?>
    
   
    
    <style>
        .fontcolor
        {
            color: #c73475 !important;
            font-weight: bold;
        }
    </style>


    
    <div class="breadcumb-wrapper" data-bg-src="assets/img/bg/banner13.jpg">
        <div class="container z-index-common">
            <div class="breadcumb-content text-center">
                <h1 class="breadcumb-title">Consult <span class="inner-text">Now</span></h1>
                <div class="breadcumb-menu-wrap">
                    <ul class="breadcumb-menu">
                        <li><a href="index.html">Home</a></li>
                        <li><span class="inner-text">Consult Now</span></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

        <!-- form end -->

        <section class="space-extra-bottom">
    <h2 class="sec-title text-center my-4">Consultation <span class="text-theme">Form</span></h2>

    <div class="mt-5 space-negative-bottom container consult">
        <div class="consulation-background-image">
            <div class="form-container">
                <form id="consultationForm" action="code.php" method="POST" enctype="multipart/form-data">

                    <!-- Step 1: Personal Information -->
                    <div class="form-step">
                        <h3 class="text-white fontcolor">Personal Information</h3>
                        <div class="form-group">
                            <label  for="name" class="fontcolor">Name:</label>
                            <input type="text" id="name" name="name" placeholder="Name" autocomplete="off" required>
                        </div>
                        <div class="form-group">
                            <label for="email" class="fontcolor">Email:</label>
                            <input type="email" id="email" name="email" placeholder="Email"  autocomplete="off" required>
                        </div>
                        <div class="form-group">
                            <label for="phone" class="fontcolor">Phone:</label>
                            <input type="tel" id="phone" name="phone" placeholder="Phone" autocomplete="off" required>
                        </div>
                    </div>

                    <!-- Step 2: Preferences -->
                    <div class="form-step">
                        <h3 class="fontcolor">Preferences</h3>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-sm-8 d-flex flex-column align-items-center justify-content-center">
                                    <label class="fontcolor">Please attach a current photo of your hair</label>
                                    <label for="hair" class="custom-file-label">Browse Files</label>
                                    <input type="file" id="hair" name="hair" accept="image/*" required>
                                </div>
                                <div class="col-sm-4 d-flex justify-content-center">
                                    <img src="assets/img/bg/preview.png" id="currentPhotoPreview" alt="Preview">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-sm-8">
                                    <label class="fontcolor">Please attach any inspirational photos you have:</label>
                                    <label for="inspirational" class="custom-file-label fontcolor">Browse Files</label>
                                    <input type="file" id="inspirational" name="inspirational" accept="image/*" required>
                                </div>
                                <div class="col-sm-4 d-flex justify-content-center">
                                    <img src="assets/img/bg/preview.png" id="inspirationalPhotoPreview" alt="Preview">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="message" class="fontcolor">When was the last time you had your hair colored and what did you have done?</label>
                            <textarea id="message" name="message" required placeholder="Message"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="coverage" class="fontcolor">Are you looking for grey coverage?</label>
                            <div class="d-flex justify-content-evenly flex-wrap">
                                <div class="form-group d-flex">
                                    <label for="yes" class="fontcolor">Yes</label>
                                    <input type="radio" name="coverage" value="yes" class="consult-radio mx-3" id="yes" required>
                                </div>
                                <div class="form-group d-flex">
                                    <label for="no" class="fontcolor">No</label>
                                    <input type="radio" name="coverage" value="no" class="consult-radio mx-3" id="no" required>
                                </div>
                                <div class="form-group d-flex">
                                    <label for="unsure" class="fontcolor">Unsure</label>
                                    <input type="radio" name="coverage" value="unsure" class="consult-radio mx-3" id="unsure" required>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Step 3: Hair Condition and History -->
                    <div class="form-step">
                        <h3 class="fontcolor">Hair Condition and History</h3>
                        <div class="form-group">
                            <label for="typeofhair" class="fontcolor">Type of Hair</label>
                            <div class="d-flex justify-content-evenly flex-wrap">
                                <div class="form-group d-flex">
                                    <label for="straight" class="fontcolor">Straight</label>
                                    <input type="radio" name="typeofhair" value="straight" class="consult-radio mx-3" id="straight" required>
                                </div>
                                <div class="form-group d-flex">
                                    <label for="curly" class="fontcolor">Curly</label>
                                    <input type="radio" name="typeofhair" value="curly" class="consult-radio mx-3" id="curly" required>
                                </div>
                                <div class="form-group d-flex">
                                    <label for="wavy" class="fontcolor">Wavy</label>
                                    <input type="radio" name="typeofhair" value="wavy" class="consult-radio mx-3" id="wavy" required>
                                </div>
                                <div class="form-group d-flex">
                                    <label for="Other" class="fontcolor">Other</label>
                                    <input type="radio" name="typeofhair" value="other" class="consult-radio mx-3" id="other">
                                </div>
                            </div>
                        </div>
                        <hr class="text-dark">
                        <div class="form-group">
                            <label for="lengthofhair" class="fontcolor">Current length of Hair</label>
                            <div class="d-flex justify-content-evenly flex-wrap">
                                <div class="form-group d-flex">
                                    <label for="short" class="fontcolor">Short</label>
                                    <input type="radio" name="lengthofhair" value="short" class="consult-radio mx-3" id="short" required>
                                </div>
                                <div class="form-group d-flex">
                                    <label for="medium" class="fontcolor">Medium</label>
                                    <input type="radio" name="lengthofhair" value="medium" class="consult-radio mx-3" id="medium" required>
                                </div>
                                <div class="form-group d-flex">
                                    <label for="shoulderlength" class="fontcolor">Shoulder Length</label>
                                    <input type="radio" name="lengthofhair" value="shoulder length" class="consult-radio mx-3" id="shoulderlength" required>
                                </div>
                                <div class="form-group d-flex">
                                    <label for="other" class="fontcolor">Other</label>
                                    <input type="radio" name="lengthofhair" value="other" class="consult-radio mx-3" id="other">
                                </div>
                            </div>
                        </div>
                        <hr class="text-dark">
                        <div class="form-group">
                            <label for="haircondition" class="fontcolor">Hair condition</label>
                            <div class="d-flex justify-content-evenly flex-wrap">
                                <div class="form-group d-flex">
                                    <label for="normal" class="fontcolor">Normal</label>
                                    <input type="radio" name="haircondition" value="normal" class="consult-radio mx-3" id="normal" required>
                                </div>
                                <div class="form-group d-flex">
                                    <label for="dry" class="fontcolor">Dry</label>
                                    <input type="radio" name="haircondition" value="dry" class="consult-radio mx-3" id="dry" required>
                                </div>
                                <div class="form-group d-flex">
                                    <label for="oily" class="fontcolor">Oily</label>
                                    <input type="radio" name="haircondition" value="oily" class="consult-radio mx-3" id="oily" required>
                                </div>
                                <div class="form-group d-flex">
                                    <label for="other" class="fontcolor">Other</label>
                                    <input type="radio" name="haircondition" value="other" class="consult-radio mx-3" id="other">
                                </div>
                            </div>
                        </div>
                        <hr class="text-dark">
                        <div class="form-group">
                            <label for="scalpcondition" class="fontcolor">Scalp condition</label>
                            <div class="d-flex justify-content-evenly flex-wrap">
                                <div class="form-group d-flex">
                                    <label for="flaky" class="fontcolor">Flaky</label>
                                    <input type="radio" name="scalpcondition" value="flaky" class="consult-radio mx-3" id="flaky" required>
                                </div>
                                <div class="form-group d-flex">
                                    <label for="scalpdry" class="fontcolor">Dry</label>
                                    <input type="radio" name="scalpcondition" value="dry" class="consult-radio mx-3" id="scalpdry" required>
                                </div>
                                <div class="form-group d-flex">
                                    <label for="itchy" class="fontcolor">Itchy</label>
                                    <input type="radio" name="scalpcondition" value="itchy" class="consult-radio mx-3" id="itchy" required>
                                </div>
                                <div class="form-group d-flex">
                                    <label for="scalpoily" class="fontcolor">Oily</label>
                                    <input type="radio" name="scalpcondition" value="oily" class="consult-radio mx-3" id="scalpoily" required>
                                </div>
                                <div class="form-group d-flex">
                                    <label for="other" class="fontcolor">Other</label>
                                    <input type="radio" name="scalpcondition" value="other" class="consult-radio mx-3" id="other">
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Step 4: Salon and Style History -->
                    <div class="form-step">
                        <h3 class="fontcolor">Salon and Style History</h3>
                        <div class="form-group">
                            <label for="saloon" class="fontcolor">How often do you go to salon?</label>
                            <select name="saloon" id="saloon" required>
                                <option selected disabled value="">Select go to salon</option>
                                <option value="Every week">Every week</option>
                                <option value="Every 2 weeks">Every 2 weeks</option>
                                <option value="Every 3-4 weeks">Every 3-4 weeks</option>
                                <option value="Every 2 months">Every 2 months</option>
                                <option value="Every 2-6 months">Every 2-6 months</option>
                                <option value="Twice a year">Twice a year</option>
                                <option value="Once a year">Once a year</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="visited" class="fontcolor">When is the last time you visited a salon?</label>
                            <input type="text" id="visited" name="visited" autocomplete="off" required placeholder="Visited">
                        </div>
                        <div class="form-group">
                            <label for="style" class="fontcolor">How often do you change the style of your hair?</label>
                            <input type="text" id="style" name="style" autocomplete="off" required placeholder="Style">
                        </div>
                        <div class="form-group">
                            <label for="about" class="fontcolor">How did you hear about us?</label>
                            <input type="text" id="about" name="about" autocomplete="off" required placeholder="About us">
                        </div>
                        <div class="form-group">
                            <label for="referred" class="fontcolor">If you were referred, let us know by who, so we can thank them!</label>
                            <input type="text" id="referred" name="referred" autocomplete="off" required placeholder="Referred">
                        </div>

                        <!-- Submit Button -->
                        <div class="form-group">
                            <button type="submit" name="consultation"  class="vs-btn">Submit</button>
                        </div>
                    </div>

                    <!-- Navigation Buttons -->
                    <div class="form-navigation">
                        <!--<button class="vs-btn" type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>-->
                        <button  class="vs-btn" type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
                    </div>

                </form>
            </div>
        </div>
    </div>
</section>



















<script>
        document.getElementById('hair').addEventListener('change', function (event) {
            const input = event.target;
            const preview = document.getElementById('currentPhotoPreview');
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function (e) {
                    preview.src = e.target.result;
                };
                reader.readAsDataURL(input.files[0]);
            }
        });
        document.getElementById('inspirational').addEventListener('change', function (event) {
            const input = event.target;
            const preview = document.getElementById('inspirationalPhotoPreview');
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function (e) {
                    preview.src = e.target.result;
                };
                reader.readAsDataURL(input.files[0]);
            }
        });

    //    Radio with Other input 
        document.getElementById('typeother-radio').addEventListener('change', function () {
            if (this.checked) {
                document.getElementById('typeother-input').focus();
            }
        });
        document.getElementById('typeother-input').addEventListener('focus', function () {
            document.getElementById('typeother-radio').checked = true;
        });
       
        document.getElementById('lengthofhair-radio').addEventListener('change', function () {
            if (this.checked) {
                document.getElementById('lengthofhair-input').focus();
            }
        });
        document.getElementById('lengthofhair-input').addEventListener('focus', function () {
            document.getElementById('lengthofhair-radio').checked = true;
        });
       
        document.getElementById('haircondition-radio').addEventListener('change', function () {
            if (this.checked) {
                document.getElementById('haircondition-input').focus();
            }
        });
        document.getElementById('haircondition-input').addEventListener('focus', function () {
            document.getElementById('haircondition-radio').checked = true;
        });
       
        document.getElementById('scalpcondition-radio').addEventListener('change', function () {
            if (this.checked) {
                document.getElementById('scalpcondition-input').focus();
            }
        });
        document.getElementById('scalpcondition-input').addEventListener('focus', function () {
            document.getElementById('scalpcondition-radio').checked = true;
        });
    </script>




<script>

    let currentStep = 0;
    showStep(currentStep);

    function showStep(step) {
        const steps = document.getElementsByClassName("form-step");
        steps[step].classList.add("active");

        if (step == 0) {
            document.getElementById("prevBtn").style.display = "none";
        } else {
            document.getElementById("prevBtn").style.display = "inline";
        }

        if (step == (steps.length - 1)) {
            document.getElementById("nextBtn").style.display = "none";
        } else {
            document.getElementById("nextBtn").style.display = "inline";
        }
    }

    function nextPrev(n) {
        const steps = document.getElementsByClassName("form-step");
        const currentInputs = steps[currentStep].querySelectorAll("input, select, textarea");
        
        let valid = true;
        currentInputs.forEach(input => {
            if (!input.checkValidity()) {
                valid = false;
                input.classList.add("invalid");
            } else {
                input.classList.remove("invalid");
            }
        });

        if (valid) {
            steps[currentStep].classList.remove("active");
            currentStep += n;
            if (currentStep >= steps.length) {
                document.getElementById("consultationForm").submit();
                return false;
            }
            showStep(currentStep);
        }
        
        console.log(currentStep);
    }
</script>




    <?php include'footer.php'?>
</body>

</html>