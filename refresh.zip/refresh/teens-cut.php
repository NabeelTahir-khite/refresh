<!doctype html>
<html class="no-js" lang="zxx">
     <!-- Favicons - Place favicon.ico in the root directory -->
    <link rel="icon" type="image/png" size="16x16" href="assets/img/logo-1.png">
    <!-- <link rel="manifest" href="assets/img/favicons/manifest.json"> -->



<body>


    <?php include'header.php'?>
    <!--==============================
    Breadcumb
============================== -->
    <div class="breadcumb-wrapper " data-bg-src="assets/img/bg/banner14.jpg">
        <div class="container z-index-common">
            <div class="breadcumb-content text-center">
                <h1 class="breadcumb-title">Teens Cut and Style</h1>
                <div class="breadcumb-menu-wrap">
                    <ul class="breadcumb-menu">
                        <li><a href="index.php">Home</a></li>
                        <li class="active">Teens Cut and Style</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!--==============================
  Team Area
  ============================== -->
    <section class="vs-team-details space-top space-negative-bottom">
        <div class="container">
            <div class="row justify-content-around">
                <!--<div class="col-lg-6 mb-30">-->
                <!--    <div class="position-relative">-->
                <!--        <div class=" " data-mask-src="assets/img/shape/team-mask-2.png"></div>-->
                <!--        <div >-->
                <!--            <img src="assets/img/about/about-1-1.jpg" alt="member Image" class="w-100">-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <div class="col-lg-12 col-xl-12 mb-30 align-self-center">
                    <div class="team-details-content">
                        <h2 class="member-name h3 mb-0 fw-semibold">Express Yourself with a Personalized Teen Haircut at Refresh Hair Studio!</h2>
                        <span class="member-degi">At Refresh Hair Studio, we understand that your teen years are a time of self-discovery and personal expression. That's why we offer <strong>customized teen haircuts</strong> designed to help you rock a style that reflects your unique personality.</span>
                        <div class="row mt-4 mt-xl-3">
                            <div class="col-sm-6 col-lg-6 col-xl-6 mb-20">
                                <h3 class="fw-semibold fs-22 mb-1 mb-lg-2">Trend-Setting & Style-Conscious:</h3>
                                <p class="mb-0">Our stylists are experts in the latest teen hair trends, from edgy fades to effortless waves and textured styles. They'll work closely with you to understand your desired look and create a haircut that's both trendy and flattering for your face shape and hair type.</p>
                                 <br>
                                <a href="https://booksy.com/en-us/644713_refresh-hair-studio-chicago_hair-salon_18229_chicago/staffer/1077596#ba_s=sh_1" class="vs-btn mb-30"> BOOK NOW</a>
                                
                                
                            </div>
                            <div class="col-sm-6 col-lg-6 col-xl-6 mb-20">
                                <h3 class="fw-semibold fs-22 mb-1 mb-lg-2">A Collaborative Experience:</h3>
                                <p class="mb-0">We believe in a collaborative approach. During your consultation, our stylists will listen to your ideas, browse inspiration photos with you, and offer expert advice to bring your vision to life. We want you to leave feeling confident and excited about your new look!</p>
                                <br>
                                <a href="consultation.php" class="vs-btn mb-30"> CONSULT NOW</a>
                            </div>
                        </div>
                        <div class="vs-social style2 hover-black">
                            <h3 class="fw-semibold fs-22 mb-3">Follow On</h3>
                            <ul>
                                <li><a href="https://www.facebook.com/RefreshHairStudioChicago/?_rdr"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="https://goo.gl/maps/dWeauU3M7baxohVSA"><i class="fab fa-google-plus-g"></i></a></li>
                                <li><a href="https://www.instagram.com/refreshhairstudio/"><i class="fab fa-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="team-details-desc mt-4 pt-1">
                <h2 class="inner-title-style2">Expert Haircare Techniques</h2>
                <p>Our stylists aren't just about creating cool styles; they're also haircare specialists. They'll use professional techniques and high-quality products to ensure your haircut is not only stylish but also healthy and manageable.</p>
                <h2 class="inner-title-style2">Salon-Quality Finish</h2>
                <p>We go the extra mile to ensure a flawless finish. From precision cutting techniques to a relaxing scalp massage and blow-dry, you'll leave the salon feeling pampered and ready to turn heads.</p>
                <h2 class="inner-title-style2">Beyond the Haircut</h2>
                <p>Our stylists will also offer styling tips and product recommendations to help you maintain your new look at home. We want you to be able to recreate your salon style with ease and confidence.</p>
                <h2 class="inner-title-style2">More Than Just a Haircut, It's an Experience</h2>
                <p>Getting a haircut at Refresh Hair Studio is more than just a service; it's an experience. Our goal is to create a relaxing and enjoyable environment where you can express yourself and feel confident about your look.</p>
                
                <div class="row g-3 my-1 my-lg-3 my-xl-3 py-xl-3">
                    <div class="col-md-3">
                        <div class="image-scale-hover">
                            <img src="assets/img/about/23b584a1eac270a8b656fbe0c6c4a1a2--hairstyle-ideas-hair-ideas.jpg" alt="About Image" class="w-100">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="image-scale-hover position-relative">
                            <img src="assets/img/about/haircut-1.jpg" alt="About Image" class="w-100">
                            <!--<a href="https://www.youtube.com/watch?v=_sI_Ps7JSEk" class="play-btn position-center popup-video"><i class="fas fa-play"></i></a>-->
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="image-scale-hover">
                            <img src="assets/img/about/0605159fd5ccc20a0946eb919df45d1d.jpg" alt="About Image" class="w-100">
                        </div>
                    </div>
                </div>
                <p class="mt-4 pt-2"><strong>Ready to show off your unique style with a haircut you love?</strong> Schedule an appointment at Refresh Hair Studio today! We look forward to helping you create a look that reflects your personality and makes you feel like the best version of yourself.</p>
                <p><strong>Teen Haircut  $65-80</strong></p>
                 <!--==============================
                            Testimonial Area
        ============================== -->
    <section class="vs-testimonial-wrapper space-bottom space-top">
        <div class="container position-relative">
            

            
            <div class="row justify-content-center">
           <?php
                include_once 'google-reviews.php';
            ?>
            
                <div class="col-lg-9 col-xl-7">
              
                    <div class="vs-carousel" id="testimonialslide1" data-asnavfor="#avaterfly" data-fade="true" data-slide-show="1" data-md-slide-show="1">
                    


                        <!-- <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>Jamie does a n amazing job every time I see her She is always cautious and listens attentively to what the client wants. She is always honest and does not tryto sell you into doing more than what you asked for and will not lie if she believes what you are asking for might not work. I will not go to anyone else. She is extremely knowledgeable, honest, caring and personable. And she will go out of her way to make sure you ae comfortable during your styling and happy with your end results, Jamie is truly one of the very best</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Amy Jo</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div>
                        <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>I've been getting my short hair/pixie cut done by Jamie for years and she never disappoints! Jamie's amazing at both cutting and coloring hair and is super friendly, as well. Before Jamie, I went to a bunch of places in Chicago and could never really find the perfect pixie cut but she really gets it. Thank you Jamie!!!</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Katie F</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div>
                        <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>Absolutely stunning results, hair has dimension, shine, and feels amazing. Jaime is an absolute joy to spend time with and makes the experience feel so personal yet luxurious. 5 stars isn't enough!!!</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Kellie E</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div>
                        <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>I had such a great experience at Jamie's salon! She is down to earth and super friendly, and absolutely love the color and cut she gave me!</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Rachel</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div>
                        <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>Jamie is hands down the best. For years she's been the only one I've let do my hair. She always seems to understand what I want and what would work best for my hair. She's a consummate professional and an incredibly kind and friendly human to boot. Cannot recommend her enough1</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Esther S</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div> -->

                    </div>
                </div>

            </div>
            
         </div>
        

               

            </div>
        </div>
    </section>
  <?php include'footer.php'?>


</body>

</html>