<!doctype html>
<html class="no-js" lang="zxx">
     <!-- Favicons - Place favicon.ico in the root directory -->
    <link rel="icon" type="image/png" size="16x16" href="assets/img/logo-1.png">
    <!-- <link rel="manifest" href="assets/img/favicons/manifest.json"> -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Haarino - Barber and Salon HTML Template - Blog Details</title>
    <meta name="author" content="Vecuro">
    <meta name="description" content="Haarino - Barber and Salon HTML Template">
    <meta name="keywords" content="Haarino - Barber and Salon HTML Template" />
    <meta name="robots" content="INDEX,FOLLOW">

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


    <!--==============================
	    All CSS File
	============================== -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Handlee&family=Open+Sans:wght@400;600&family=Syne:wght@600;700&display=swap" rel="stylesheet">


    <!-- Favicons - Place favicon.ico in the root directory -->
    <link rel="apple-touch-icon" sizes="57x57" href="assets/img/favicons/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="assets/img/favicons/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="assets/img/favicons/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="assets/img/favicons/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="assets/img/favicons/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="assets/img/favicons/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="assets/img/favicons/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="assets/img/favicons/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="assets/img/favicons/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicons/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="assets/img/favicons/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">

    <!--==============================
	    All CSS File
	============================== -->
    <!-- Bootstrap -->
    <!-- <link rel="stylesheet" href="assets/css/app.min.css"> -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- Fontawesome Icon -->
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <!-- Layerslider -->
    <link rel="stylesheet" href="assets/css/layerslider.min.css">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="assets/css/magnific-popup.min.css">
    <!-- Slick Slider -->
    <link rel="stylesheet" href="assets/css/slick.min.css">
    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>


    <!--[if lte IE 9]>
    	<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
  <![endif]-->



    <!--********************************
   		Code Start From Here 
	******************************** -->




    <!--==============================
     Preloader
  ==============================-->
    <div class="preloader  ">
        <button class="vs-btn preloaderCls">Cancel Preloader </button>
        <div class="preloader-inner">
            <img src="assets/img/logo.png" alt="Haarino">
            <span class="loader"></span>
        </div>
    </div>
    <!--==============================
    Mobile Menu
  ============================== -->
    <div class="vs-menu-wrapper">
        <div class="vs-menu-area text-center">
            <button class="vs-menu-toggle"><i class="fal fa-times"></i></button>
            <div class="mobile-logo">
                <a href="index.html"><img src="assets/img/logo-mobile.png" alt="Haarino"></a>
            </div>
            <div class="vs-mobile-menu">
                <ul>
                    <li class="menu-item-has-children">
                        <a href="index.html">Home</a>
                        <ul class="sub-menu">
                            <li><a href="index.html">Home One</a></li>
                            <li><a href="index-2.html">Home Two</a></li>
                            <li><a href="index-3.html">Home Three</a></li>
                            <li><a href="index-4.html">Home Four<span class="new-label">New</span></a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="about.html">About</a>
                    </li>
                    <li class="menu-item-has-children">
                        <a href="blog.html">Blog</a>
                        <ul class="sub-menu">
                            <li><a href="blog.html">Blog One</a></li>
                            <li><a href="blog-2.html">Blog Two</a></li>
                            <li><a href="blog-details.html">Blog Details</a></li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children">
                        <a href="#">Pages</a>
                        <ul class="sub-menu">
                            <li><a href="find-salon.html">Find a Salon</a></li>
                            <li><a href="gallery.html">Gallery One</a></li>
                            <li><a href="gallery-2.html">Gallery Two</a></li>
                            <li><a href="price-list.html">Price List One</a></li>
                            <li><a href="price-list-2.html">Price List Two</a></li>
                            <li><a href="price-list-3.html">Price List Three</a></li>
                            <li><a href="team-details.html">Team Details</a></li>
                            <li><a href="discount-offers.html">Discount Offers</a></li>
                            <li><a href="product-details.html">Products Details</a></li>
                            <li><a href="cart.html">Shopping Cart</a></li>
                            <li><a href="checkout.html">Check Out</a></li>
                            <li><a href="error.html">Error Page</a></li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children">
                        <a href="#">Elements</a>
                        <ul class="sub-menu">
                            <li><a href="element-typography.html">Typography</a></li>
                            <li><a href="element-buttons.html">Buttons</a></li>
                            <li><a href="element-columns.html">Columns</a></li>
                            <li><a href="element-messagebox.html">Message Box</a></li>
                            <li><a href="element-separators.html">Separators</a></li>
                            <li><a href="element-services.html">Services Card</a></li>
                            <li><a href="element-testimonials.html">Testimonials</a></li>
                            <li><a href="element-projectbox.html">Gallery</a></li>
                            <li><a href="element-priceplan.html">Price Plan</a></li>
                            <li><a href="element-counters.html">Counters</a></li>
                            <li><a href="element-accordions.html">Accordions</a></li>
                            <li><a href="element-team.html">Team</a></li>
                            <li><a href="element-forms.html">Forms</a></li>
                            <li><a href="element-blogcard.html">Blog Card</a></li>
                            <li><a href="element-ctas.html">Call To Actions</a></li>
                            <li><a href="element-map.html">Google Map</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="contact.html">Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!--==============================
        Header Area
    ==============================-->
    <header class="vs-header header-layout1">
        <!-- Header Top Area -->
        <div class="header-top py-15 d-none d-sm-block">
            <div class="container">
                <div class="row align-items-center justify-content-center justify-content-lg-between">
                    <div class="col-sm-auto d-none d-lg-block">
                        <p class="m-0 fw-semibold text-white"><i class="fal fa-map-marker-alt me-2"></i> <a href="find-salon.html" class="text-reset">Locate a Salon</a></p>
                    </div>
                    <div class="col-auto">
                        <div class="header-info-list text-white">
                            <ul>
                                <li><i class="fas fa-phone-alt"></i>Phone: <a class="text-reset" href="tel:02073885619">020 7388 5619</a></li>
                                <li><i class="fal fa-envelope"></i>Email: <a class="text-reset" href="mailto:info@example.com">info@example.com</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="sticky-wrapper">
            <div class="sticky-active">
                <!-- Main Menu Area -->
                <div class="header-inner">
                    <div class="container">
                        <div class="row align-items-center justify-content-between">
                            <div class="col-7 col-sm-auto order-1">
                                <div class="header-logo py-2 py-lg-0">
                                    <a href="index.html"><img src="assets/img/logo.png" alt="Haarino"></a>
                                </div>
                            </div>
                            <div class="col-auto order-3 order-sm-2">
                                <nav class="main-menu menu-style1 d-none d-lg-block">
                                    <ul>
                                        <li class="menu-item-has-children">
                                            <a href="index.html"><span class="has-new-lable">Home<span class="new-label">new</span></span></a>
                                            <ul class="sub-menu">
                                                <li><a href="index.html">Home One</a></li>
                                                <li><a href="index-2.html">Home Two</a></li>
                                                <li><a href="index-3.html">Home Three</a></li>
                                                <li><a href="index-4.html">Home Four<span class="new-label">New</span></a></li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="about.html">About</a>
                                        </li>
                                        <li class="menu-item-has-children mega-menu-wrap">
                                            <a href="#"><span class="has-new-lable">Elements<span class="new-label">new</span></span></a>
                                            <ul class="mega-menu">
                                                <li><a href="shop.html">Elements</a>
                                                    <ul>
                                                        <li><a href="element-typography.html">Typography</a></li>
                                                        <li><a href="element-buttons.html">Buttons</a></li>
                                                        <li><a href="element-columns.html">Columns</a></li>
                                                        <li><a href="element-messagebox.html">Message Box</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="#">Elements</a>
                                                    <ul>
                                                        <li><a href="element-separators.html">Separators</a></li>
                                                        <li><a href="element-services.html">Services Card</a></li>
                                                        <li><a href="element-testimonials.html">Testimonials</a></li>
                                                        <li><a href="element-projectbox.html">Gallery</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="#">Elements</a>
                                                    <ul>
                                                        <li><a href="element-priceplan.html">Price Plan</a></li>
                                                        <li><a href="element-counters.html">Counters</a></li>
                                                        <li><a href="element-accordions.html">Accordions</a></li>
                                                        <li><a href="element-team.html">Team</a></li>

                                                    </ul>
                                                </li>
                                                <li><a href="#">Elements</a>
                                                    <ul>
                                                        <li><a href="element-forms.html">Forms</a></li>
                                                        <li><a href="element-blogcard.html">Blog Card</a></li>
                                                        <li><a href="element-ctas.html">Call To Actions</a></li>
                                                        <li><a href="element-map.html">Google Map</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class="menu-item-has-children mega-menu-wrap">
                                            <a href="#">Pages</a>
                                            <ul class="mega-menu">
                                                <li><a href="shop.html">Pagelist 1</a>
                                                    <ul>
                                                        <li><a href="index.html">Home One</a></li>
                                                        <li><a href="index-2.html">Home Two</a></li>
                                                        <li><a href="index-3.html">Home Three</a></li>
                                                        <li><a href="index-4.html">Home Four<span class="new-label">New</span></a></li>
                                                        <li><a href="about.html">About Us</a></li>
                                                        <li><a href="find-salon.html">Find a Salon</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="#">Pagelist 2</a>
                                                    <ul>
                                                        <li><a href="gallery.html">Gallery One</a></li>
                                                        <li><a href="gallery-2.html">Gallery Two</a></li>
                                                        <li><a href="price-list.html">Price List One</a></li>
                                                        <li><a href="price-list-2.html">Price List Two</a></li>
                                                        <li><a href="price-list-3.html">Price List Three</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="#">Pagelist 3</a>
                                                    <ul>
                                                        <li><a href="team-details.html">Team Details</a></li>
                                                        <li><a href="discount-offers.html">Discount Offers</a></li>
                                                        <li><a href="shop.html">Our Products<span class="new-label">New</span></a></li>
                                                        <li><a href="product-details.html">Products Details</a></li>
                                                        <li><a href="cart.html">Shopping Cart</a></li>
                                                        <li><a href="checkout.html">Check Out</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="#">Pagelist 4</a>
                                                    <ul>
                                                        <li><a href="blog.html">Blog One</a></li>
                                                        <li><a href="blog-2.html">Blog Two</a></li>
                                                        <li><a href="blog-details.html">Blog Details</a></li>
                                                        <li><a href="contact.html">Contact Us</a></li>
                                                        <li><a href="error.html">Error Page</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="contact.html">Contact</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                            <div class="col-5 col-sm-auto order-2 order-sm-3 text-end">
                                <div class="header-btn">
                                    <a href="cart.html" class="cart-icon me-4 me-lg-3 mr-xl-0"><i class="fal fa-shopping-cart"></i><span class="badge">1</span></a>
                                    <a href="contact.html" class="vs-btn d-none d-xl-inline-block">Book Now</a>
                                    <button class="vs-menu-toggle d-inline-block d-lg-none"><i class="fas fa-bars"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!--==============================
    Breadcumb
============================== -->
    <div class="breadcumb-wrapper " data-bg-src="assets/img/breadcumb/breadcumb-1.jpg">
        <div class="container z-index-common">
            <div class="breadcumb-content text-center">
                <h1 class="breadcumb-title">Blog Details</h1>
                <div class="breadcumb-menu-wrap">
                    <ul class="breadcumb-menu">
                        <li><a href="index.html">Home</a></li>
                        <li class="active">Blog Details</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!--==============================
        Blog Area
    ==============================-->
    <section class="vs-blog-wrapper blog-details space-top space-negative-bottom">
        <div class="container">
            <div class="row gx-30">
                <div class="col-lg-8">
                    <div class="vs-blog blog-single">
                        <div class="blog-img">
                            <img src="assets/img/blog/blog-s-1-1.jpg" alt="Blog Image">
                        </div>
                        <div class="blog-content">
                            <div class="blog-meta">
                                <a href="blog.html"><i class="fal fa-eye"></i>232 Views</a>
                                <a href="blog.html"><i class="fal fa-comments"></i>17 Comments</a>
                                <a href="blog.html"><i class="fal fa-calendar-alt"></i>22 June, 2022</a>
                            </div>
                            <h2 class="blog-title">Hair stylist and makeup artist for over 12 years redefine.</h2>
                            <p>Conveniently whiteboard team building architectures without sticky partnerships. Energistically redefine emerging paradigms after resource sucking bandwidth. Dramatically supply transparent expertise whereas market-driven testing procedures. Professionally visualize client-centric services via inexpensive models.</p>
                            <p>Conveniently whiteboard team building architectures without sticky partnerships. Energistically redefine emerging paradigms after resource sucking bandwidth. Dramatically supply transparent expertise whereas market-driven testing procedures.</p>
                            <blockquote>
                                <p>Continually restore premier strategic theme areas through magnetic customer service. Holisticly embrace optimal processes without B2C</p>
                                <cite>Redwan Ahmed</cite>
                            </blockquote>
                            <p>Objectively optimize strategic technology without 2.0 bandwidth. Monotonectally administrate user-centric results whereas performance based manufactured products. Continually restore premier strategic theme areas through magnetic customer service. Holisticly embrace optimal processes without B2C infomediaries. Holisticly deploy future-proof leadership skills rather than vertical technologies.</p>
                            <img src="assets/img/blog/blog-s-1-5.jpg" alt="Blog Image" class="mt-10 mb-25">
                            <h2>High quality for timely markets.</h2>
                            <p>Conveniently whiteboard team building architectures without sticky partnerships. Energistically redefine emerging paradigms after resource sucking bandwidth. Dramatically supply transparent expertise whereas market-driven testing procedures. Professionally visualize client-centric services via inexpensive models.</p>
                            <p>Conveniently whiteboard team building architectures without sticky partnerships. Energistically redefine emerging paradigms after resource sucking bandwidth. Dramatically supply transparent expertise whereas market-driven testing procedures.</p>
                        </div>
                        <div class="share-links clearfix  ">
                            <div class="row justify-content-between">
                                <div class="col-md-auto">
                                    <span class="share-links-title">Tags</span>
                                    <div class="tagcloud">
                                        <a href="blog.html">Colored</a>
                                        <a href="blog.html">Hair</a>
                                        <a href="blog.html">Haircut</a>
                                    </div>
                                </div>
                                <div class="col-md-auto text-md-end mt-20 mt-md-0">
                                    <span class="share-links-title">Social Network</span>
                                    <ul class="social-links">
                                        <li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
                                        <li><a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a></li>
                                        <li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
                                    </ul><!-- End Social Share -->
                                </div><!-- Share Links Area end -->
                            </div>
                        </div> <!-- Post Pagination Style -->
                        <div class="post-pagination  ">
                            <div class="row justify-content-between align-items-center">
                                <div class="col">
                                    <div class="post-pagi-box prev">
                                        <a href="blog.html">Prev Post</a>
                                        <h4 class="pagi-title"><a href="#" class="text-inherit">Tips On Minimalist</a></h4>
                                    </div>
                                </div>
                                <div class="col-auto d-none d-sm-block">
                                    <a href="blog.html" class="pagi-icon"><i class="flaticon-menu-1 fa-3x"></i></a>
                                </div>
                                <div class="col">
                                    <div class="post-pagi-box next">
                                        <a href="blog.html">Next Post</a>
                                        <h4 class="pagi-title"><a href="#" class="text-inherit">Now An Olternative</a></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="blog-author d-md-flex align-items-center ">
                            <div class="media-img">
                                <img src="assets/img/blog/blog-author.jpg" alt="Blog Author Image">
                            </div>
                            <div class="media-body">
                                <p class="author-degi">Written by</p>
                                <h3 class="author-name h4"><a class="text-inherit" href="team-details.html">Hasmine Yulk</a></h3>
                                <p class="author-text mb-0">Monotonectally procrastinate transparent architectures before robust opportunities. Progressively parallel task 24/365 mindshare and multimedia based e-markets.</p>
                            </div>
                        </div>
                        <div class="vs-comments-wrap   ">
                            <h2 class="blog-inner-title h3">3 Comments</h2>
                            <ul class="comment-list">
                                <li class="vs-comment-item">
                                    <div class="vs-post-comment">
                                        <div class="comment-avater">
                                            <img src="assets/img/blog/comment-author-1.jpg" alt="Comment Author">
                                        </div>
                                        <div class="comment-content">
                                            <h4 class="name h4">Rosalina Kelian</h4>
                                            <span class="commented-on"><i class="fal fa-calendar-alt"></i> 22 April, 2022</span>
                                            <p class="text">Progressively procrastinate mission-critical action items before team building ROI.
                                                Interactively provide access to cross functional quality vectors for client-centric catalysts for change.
                                            </p>
                                            <div class="reply_and_edit">
                                                <a href="blog-details.html" class="replay-btn"><i class="fal fa-reply"></i>Replay</a>
                                            </div>
                                        </div>
                                    </div>
                                    <ul class="children">
                                        <li class="vs-comment-item">
                                            <div class="vs-post-comment">
                                                <div class="comment-avater">
                                                    <img src="assets/img/blog/comment-author-2.jpg" alt="Comment Author">
                                                </div>
                                                <div class="comment-content">
                                                    <h4 class="name h4">John Deo</h4>
                                                    <span class="commented-on"><i class="fal fa-calendar-alt"></i> 23 April, 2022</span>
                                                    <p class="text">Competently provide access to fully researched methods of empowerment without sticky models. Credibly morph front-end niche markets.</p>
                                                    <div class="reply_and_edit">
                                                        <a href="blog-details.html" class="replay-btn"><i class="fal fa-reply"></i>Replay</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                                <li class="vs-comment-item">
                                    <div class="vs-post-comment">
                                        <div class="comment-avater">
                                            <img src="assets/img/blog/comment-author-3.jpg" alt="Comment Author">
                                        </div>
                                        <div class="comment-content">
                                            <h4 class="name h4">Tara sing</h4>
                                            <span class="commented-on"><i class="fal fa-calendar-alt"></i> 26 April, 2022</span>
                                            <p class="text">Competently provide access to fully researched methods of empowerment without sticky models. Credibly morph front-end niche markets whereas 2.0 users. Enthusiastically seize team.</p>
                                            <div class="reply_and_edit">
                                                <a href="blog-details.html" class="replay-btn"><i class="fal fa-reply"></i>Replay</a>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div> <!-- Comment Form -->
                        <div class="vs-comment-form  ">
                            <div class="form-title">
                                <h3 class="blog-inner-title h3">Leave a Comment</h3>
                                <p class="form-text">Your email address will not be published. Required fields are marked *</p>
                            </div>
                            <div class="row">
                                <div class="col-12 form-group mb-4">
                                    <textarea placeholder="Write a Message" class="form-control style3"></textarea>
                                    <i class="far fa-pencil-alt"></i>
                                </div>
                                <div class="col-md-6 form-group mb-4">
                                    <input type="text" placeholder="Your Name" class="form-control style3">
                                    <i class="far fa-user"></i>
                                </div>
                                <div class="col-md-6 form-group mb-4">
                                    <input type="text" placeholder="Your Email" class="form-control style3">
                                    <i class="far fa-envelope"></i>
                                </div>
                                <div class="col-12 form-group mb-0">
                                    <button class="vs-btn style2">Post Comment</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <aside class="sidebar-area">
                        <div class="widget widget_search   ">
                            <form class="search-form">
                                <input type="text" placeholder="Search Here">
                                <button type="submit"><i class="far fa-search"></i></button>
                            </form>
                        </div>
                        <div class="widget  ">
                            <h3 class="widget_title">Recent Post</h3>
                            <div class="recent-post-wrap">
                                <div class="recent-post">
                                    <div class="media-img">
                                        <a href="blog-details.html"><img src="assets/img/blog/recent-post-1-1.jpg" alt="Blog Image"></a>
                                    </div>
                                    <div class="media-body">
                                        <h4 class="post-title"><a class="text-inherit" href="blog-details.html">Easy DIY homemade hair treatments</a></h4>
                                        <div class="recent-post-meta">
                                            <a href="blog.html"><i class="fal fa-calendar-alt"></i>Dec 12, 2022</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="recent-post">
                                    <div class="media-img">
                                        <a href="blog-details.html"><img src="assets/img/blog/recent-post-1-2.jpg" alt="Blog Image"></a>
                                    </div>
                                    <div class="media-body">
                                        <h4 class="post-title"><a class="text-inherit" href="blog-details.html">Hair treatment isn't always top of mind</a></h4>
                                        <div class="recent-post-meta">
                                            <a href="blog.html"><i class="fal fa-calendar-alt"></i>Feb 22, 2022</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="recent-post">
                                    <div class="media-img">
                                        <a href="blog-details.html"><img src="assets/img/blog/recent-post-1-3.jpg" alt="Blog Image"></a>
                                    </div>
                                    <div class="media-body">
                                        <h4 class="post-title"><a class="text-inherit" href="blog-details.html">Hair tends to be oily, you can do a leave</a></h4>
                                        <div class="recent-post-meta">
                                            <a href="blog.html"><i class="fal fa-calendar-alt"></i>Mar 13, 2022</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="widget widget_categories   ">
                            <h3 class="widget_title">Categories</h3>
                            <ul>
                                <li>
                                    <a href="blog.html">Hair treatment</a>
                                    <span>15</span>
                                </li>
                                <li>
                                    <a href="blog.html">Colored Hair</a>
                                    <span>11</span>
                                </li>
                                <li>
                                    <a href="blog.html">Haircut Styles</a>
                                    <span>55</span>
                                </li>
                                <li>
                                    <a href="blog.html">Hair Health</a>
                                    <span>60</span>
                                </li>
                                <li>
                                    <a href="blog.html">Hair Oil</a>
                                    <span>12</span>
                                </li>
                                <li>
                                    <a href="blog.html">Quality Products</a>
                                    <span>18</span>
                                </li>
                            </ul>
                        </div>
                        <div class="widget  ">
                            <h3 class="widget_title">Intro Video</h3>
                            <div class="vs-video-widget">
                                <div class="video-thumb">
                                    <img src="assets/img/blog/intro-video-thumb.jpg" alt="Video Thumb" class="w-100">
                                    <a href="https://www.youtube.com/watch?v=_sI_Ps7JSEk" class="play-btn popup-video"><i class="fas fa-play"></i></a>
                                </div>
                                <h4 class="video-thumb-title">Hairdressers by helping them to continuously improve</h4>
                            </div>
                        </div>
                        <div class="widget  ">
                            <h4 class="widget_title">Gallery Posts</h4>
                            <div class="sidebar-gallery">
                                <div class="gallery-thumb">
                                    <img src="assets/img/widget/gal-1-1.jpg" alt="Gallery Image" class="w-100">
                                    <a href="assets/img/widget/gal-1-1.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                                </div>
                                <div class="gallery-thumb">
                                    <img src="assets/img/widget/gal-1-2.jpg" alt="Gallery Image" class="w-100">
                                    <a href="assets/img/widget/gal-1-2.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                                </div>
                                <div class="gallery-thumb">
                                    <img src="assets/img/widget/gal-1-3.jpg" alt="Gallery Image" class="w-100">
                                    <a href="assets/img/widget/gal-1-3.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                                </div>
                                <div class="gallery-thumb">
                                    <img src="assets/img/widget/gal-1-4.jpg" alt="Gallery Image" class="w-100">
                                    <a href="assets/img/widget/gal-1-4.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                                </div>
                                <div class="gallery-thumb">
                                    <img src="assets/img/widget/gal-1-5.jpg" alt="Gallery Image" class="w-100">
                                    <a href="assets/img/widget/gal-1-5.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                                </div>
                                <div class="gallery-thumb">
                                    <img src="assets/img/widget/gal-1-6.jpg" alt="Gallery Image" class="w-100">
                                    <a href="assets/img/widget/gal-1-6.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                    </aside>
                </div>
            </div>
        </div>
    </section>
    <!--==============================
			Footer Area
	==============================-->
    <footer class="footer-wrapper footer-layout1 bg-dark">
        <div class="widget-area">
            <div class="container">
                <div class="row justify-content-between">
                    <div class="col-md-12 col-lg-4">
                        <div class="widget footer-widget pt-0  ">
                            <h3 class="widget_title">About Us</h3>
                            <div class="vs-widget-about">
                                <!-- <div class="footer-logo mb-3">
      <a href="index.html"><img src="assets/img/logo-mix.png" alt="Haarino"></a>
    </div> -->
                                <p class="pe-xl-5 mb-3">My course involved cutting, colouring, relaxing and all sort of hair treatments Available for Appointment.</p>
                                <div class="footer-rating">
                                    <p class="text-uppercase text-white mb-0">5 Star - 3,674 reviews</p>
                                    <div class="text-theme fs-16">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 col-xl-3">
                        <div class="widget footer-widget  ">
                            <h3 class="widget_title">Contact Us</h3>
                            <div class="vs-widget-about">
                                <p class="footer-info"><i class="fas fa-map-marker-alt"></i>66 Walker Road, Suite D, Great Virginia 22066</p>
                                <p class="footer-info"><i class="fas fa-envelope"></i>Email: <a class="text-inherit" href="mailto:Haarino@email.com">Haarino@email.com</a></p>
                                <p class="footer-info"><i class="fas fa-phone-alt"></i>Tel: <a class="text-inherit" href="tel:703-261-6660">703-261-6660</a></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 col-xl-3">
                        <div class="widget footer-widget   ">
                            <h3 class="widget_title">Openinng Hours</h3>
                            <div class="footer-table text-white">
                                <table>
                                    <tr>
                                        <td>Mon - Thu:</td>
                                        <td>10am - 7pm</td>
                                    </tr>
                                    <tr>
                                        <td>Saturday:</td>
                                        <td>10am - 7pm</td>
                                    </tr>
                                    <tr>
                                        <td>Sunday:</td>
                                        <td><a class="text-theme" href="contact.html">By Appointment</a></td>
                                    </tr>
                                    <tr>
                                        <td>Friday:</td>
                                        <td><a class="text-theme" href="contact.html">By Call</a></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer-instagram pt-30" data-pos-for=".copyright-wrap" data-sec-pos="bottom-half">
                    <div class="row vs-carousel" data-slide-show="6" data-lg-slide-show="5" data-md-slide-show="4" data-sm-slide-show="3" data-xs-slide-show="2">
                        <div class="col-md-2">
                            <div class="gallery-thumb">
                                <img src="assets/img/insta/insta-1-1.jpg" class="w-100" alt="Thumb Image">
                                <a href="assets/img/insta/insta-1-1.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="gallery-thumb">
                                <img src="assets/img/insta/insta-1-2.jpg" class="w-100" alt="Thumb Image">
                                <a href="assets/img/insta/insta-1-2.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="gallery-thumb">
                                <img src="assets/img/insta/insta-1-3.jpg" class="w-100" alt="Thumb Image">
                                <a href="assets/img/insta/insta-1-3.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="gallery-thumb">
                                <img src="assets/img/insta/insta-1-4.jpg" class="w-100" alt="Thumb Image">
                                <a href="assets/img/insta/insta-1-4.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="gallery-thumb">
                                <img src="assets/img/insta/insta-1-5.jpg" class="w-100" alt="Thumb Image">
                                <a href="assets/img/insta/insta-1-5.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="gallery-thumb">
                                <img src="assets/img/insta/insta-1-6.jpg" class="w-100" alt="Thumb Image">
                                <a href="assets/img/insta/insta-1-6.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright-wrap bg-theme">
            <div class="container">
                <div class="row  py-30 align-items-center justify-content-between">
                    <div class="col-lg-auto text-center text-lg-end">
                        <p class="mb-0 text-white">Copyright <i class="fal fa-copyright"></i> 2022 <a class="text-white" href="index.html">Haarino</a> - All rights reserved by <a class="text-white" href="https://themeforest.net/user/vecuro_themes">Vecuro</a>.</p>
                    </div>
                    <div class="col-auto d-none d-lg-block">
                        <div class="vs-social">
                            <ul>
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--********************************
                Code End  Here 
        ******************************** -->


    <!-- Scroll To Top -->
    <a href="#" class="scrollToTop scroll-btn"><i class="far fa-arrow-up"></i></a>



    <!--==============================
        All Js File
    ============================== -->
    <!-- Jquery -->
    <script src="assets/js/vendor/jquery.min.js"></script>
    <!-- Slick Slider -->
    <!-- <script src="assets/js/app.min.js"></script> -->
    <script src="assets/js/slick.min.js"></script>
    <!-- Layerslider -->
    <script src="assets/js/layerslider.utils.js"></script>
    <script src="assets/js/layerslider.transitions.js"></script>
    <script src="assets/js/layerslider.kreaturamedia.jquery.js"></script>
    <!-- Bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Magnific Popup -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <!-- Isotope Filter -->
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <!-- Custom Carousel -->
    <script src="assets/js/vscustom-carousel.min.js"></script>
    <!-- Form Js -->
    <script src="assets/js/ajax-mail.js"></script>
    <!-- Main Js File -->
    <script src="assets/js/main.js"></script>


</body>

</html>