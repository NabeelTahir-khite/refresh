<!doctype html>
<html class="no-js" lang="zxx">
 <!-- Favicons - Place favicon.ico in the root directory -->
    <link rel="icon" type="image/png" size="16x16" href="assets/img/logo-1.png">
    <!-- <link rel="manifest" href="assets/img/favicons/manifest.json"> -->



<body>


    <?php include'header.php'?>
    <!--==============================
    Breadcumb
============================== -->
    <div class="breadcumb-wrapper " data-bg-src="assets/img/bg/banner6.jpg">
        <div class="container z-index-common">
            <div class="breadcumb-content text-center">
                <h1 class="breadcumb-title">Full Custom Color Transformation</h1>
                <div class="breadcumb-menu-wrap">
                    <ul class="breadcumb-menu">
                        <li><a href="index.php">Home</a></li>
                        <li class="active">Full Custom Color Transformation</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!--==============================
  Team Area
  ============================== -->
    <section class="vs-team-details space-top space-negative-bottom">
        <div class="container">
            <div class="row justify-content-around">
                <!--<div class="col-lg-6 mb-30">-->
                <!--    <div class="position-relative">-->
                <!--        <div class=" " data-mask-src="assets/img/shape/team-mask-2.png"></div>-->
                <!--        <div >-->
                <!--            <img src="assets/img/about/about-1-1.jpg" alt="member Image" class="w-100">-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <div class="col-lg-12 col-xl-12 mb-30 align-self-center">
                    <div class="team-details-content">
                        <h2 class="member-name h3 mb-0 fw-semibold">Unleash Your Hair's Inner Artistry with a Full Custom Color Transformation 
Tired of one-dimensional hair color? Craving something unique that reflects your personality? Look no further than our custom color services at Refresh Hair Studio!</h2>
                        <span class="member-degi">Think of it as bespoke hair artistry. We ditch the cookie-cutter approach and collaborate with you to create a color masterpiece that complements your features and lifestyle.  </span>
                        <p>Think of it as bespoke hair artistry. We ditch the cookie-cutter approach and collaborate with you to create a color masterpiece that complements your features and lifestyle.  Sun-kissed highlights for a beachy vibe? Rich, dimensional brunette with balayage? Cool blonde with playful lowlights? The possibilities are endless.</p>
                        <p>Our skilled colorists are masters of their craft. They utilize a blend of techniques like balayage, highlighting, and lowlighting to create a natural, multi-tonal look. Imagine a base color that creates a seamless canvas, followed by expertly woven highlights and lowlights for depth and dimension. A final toner polishes the result, ensuring your color truly shines.</p>
                        <p>But beautiful hair goes beyond just color. We prioritize your hair health throughout the process. Expect high-quality products and the option to add a deep conditioning treatment to keep your hair nourished and radiant.</p>
                        <p>The beauty of custom color lies in its longevity. It's designed to grow out gracefully, minimizing harsh lines and root touch-ups. During your consultation, we'll discuss a personalized maintenance plan and recommend at-home care products to keep your vibrant color looking fresh.</p>
                        <div class="row mt-4 mt-xl-3">
                            <div class="col-sm-6 col-lg-6 col-xl-6 mb-20">
                                <h3 class="fw-semibold fs-22 mb-1 mb-lg-2">INDIVIDUAL COLOR TRIP | MORE THAN $350</h3>
                                <p class="mb-0">Set out on a personalized color journey to realize your ideal hair makeover.</p>
                                <br>
                                <a href="consultation.php" class="vs-btn mb-30"> BOOK NOW</a>
                                
                            </div>
                            <div class="col-sm-6 col-lg-6 col-xl-6 mb-20">
                                <h3 class="fw-semibold fs-22 mb-1 mb-lg-2">TRANSFORMATION OF COLOR | $350+</h3>
                                <p class="mb-0">A customized color journey designed to help you reach your ultimate hair transformation goal.</p>
                                
                            </div>
                        </div>
                        <div class="vs-social style2 hover-black">
                            <h3 class="fw-semibold fs-22 mb-3">Follow On</h3>
                            <ul>
                                 <li><a href="https://www.facebook.com/RefreshHairStudioChicago/?_rdr"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="https://goo.gl/maps/dWeauU3M7baxohVSA"><i class="fab fa-google-plus-g"></i></a></li>
                                <li><a href="https://www.instagram.com/refreshhairstudio/"><i class="fab fa-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="team-details-desc mt-4 pt-1">
                <h2 class="inner-title-style2">You Will Turn Heads</h2>
                <p>Our custom color service which is designed to meet your hair goals, will take your hair on a new journey. We start with skilled pre-treatments and end with precise styling to guarantee vivid, long-lasting results specific to your individual preferences and type of hair.</p>
                <div class="row g-3 my-1 my-lg-3 my-xl-3 py-xl-3">
                    <div class="col-md-3">
                        <div class="image-scale-hover">
                            <img src="assets/img/about/269840008_1291873384621499_5761281974525558930_n.jfif" alt="About Image" class="w-100" >
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="image-scale-hover position-relative">
                            <img src="assets/img/about/266366856_1896624033878110_776920364922681483_n.jfif" alt="About Image" class="w-100">
                          
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="image-scale-hover">
                            <img src="assets/img/about/265912119_4721914771202467_7260487073605011634_n.jfif" alt="About Image" class="w-100" >
                        </div>
                    </div>
                </div>
                <p class="mt-4 pt-2">Ready to ditch the ordinary and embrace hair color that's as unique as you are? Schedule your consultation today and let's create something truly magical together!</p>
                 <!--==============================
                            Testimonial Area
        ============================== -->
    <section class="vs-testimonial-wrapper space-bottom space-top">
        <div class="container position-relative">
            
            
            <div class="row justify-content-center">
            <?php
                include_once 'google-reviews.php';
            ?>
            
                <div class="col-lg-9 col-xl-7">
              
                    <div class="vs-carousel" id="testimonialslide1" data-asnavfor="#avaterfly" data-fade="true" data-slide-show="1" data-md-slide-show="1">
                    


                        <!-- <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>Jamie does a n amazing job every time I see her She is always cautious and listens attentively to what the client wants. She is always honest and does not tryto sell you into doing more than what you asked for and will not lie if she believes what you are asking for might not work. I will not go to anyone else. She is extremely knowledgeable, honest, caring and personable. And she will go out of her way to make sure you ae comfortable during your styling and happy with your end results, Jamie is truly one of the very best</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Amy Jo</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div>
                        <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>I've been getting my short hair/pixie cut done by Jamie for years and she never disappoints! Jamie's amazing at both cutting and coloring hair and is super friendly, as well. Before Jamie, I went to a bunch of places in Chicago and could never really find the perfect pixie cut but she really gets it. Thank you Jamie!!!</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Katie F</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div>
                        <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>Absolutely stunning results, hair has dimension, shine, and feels amazing. Jaime is an absolute joy to spend time with and makes the experience feel so personal yet luxurious. 5 stars isn't enough!!!</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Kellie E</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div>
                        <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>I had such a great experience at Jamie's salon! She is down to earth and super friendly, and absolutely love the color and cut she gave me!</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Rachel</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div>
                        <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>Jamie is hands down the best. For years she's been the only one I've let do my hair. She always seems to understand what I want and what would work best for my hair. She's a consummate professional and an incredibly kind and friendly human to boot. Cannot recommend her enough1</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Esther S</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div> -->

                    </div>
                </div>

            </div>
            
         </div>
        

               

            </div>
        </div>
    </section>
  <?php include'footer.php'?>


</body>

</html>