<!doctype html>
<html class="no-js" lang="zxx">

 <!-- Favicons - Place favicon.ico in the root directory -->
    <link rel="icon" type="image/png" size="16x16" href="assets/img/logo-1.png">
    <!-- <link rel="manifest" href="assets/img/favicons/manifest.json"> -->

<body>


   <?php include'header.php' ?>
    <!--==============================
    Breadcumb
============================== -->
    <div class="breadcumb-wrapper " data-bg-src="assets/img/breadcumb/breadcumb-1.jpg">
        <div class="container z-index-common">
            <div class="breadcumb-content text-center">
                <h1 class="breadcumb-title">Our Blog</h1>
                <div class="breadcumb-menu-wrap">
                    <ul class="breadcumb-menu">
                        <li><a href="index.html">Home</a></li>
                        <li class="active">Our Blog</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!--==============================
        Blog Area
    ==============================-->
    <section class="vs-blog-wrapper space-top space-negative-bottom">
        <div class="container">
            <div class="row gx-30">
                <div class="col-lg-8">
                    <div class="vs-blog blog-single">
                        <div class="blog-img">
                            <a href="blog-details.html"><img src="assets/img/blog/blog-s-1-1.jpg" alt="Blog Image"></a>
                        </div>
                        <div class="blog-content">
                            <div class="blog-meta">
                                <a href="blog.html"><i class="fal fa-eye"></i>17 Views</a>
                                <a href="blog.html"><i class="fal fa-comments"></i>09 Comments</a>
                                <a href="blog.html"><i class="fal fa-calendar-alt"></i>10 Augest, 2022</a>
                            </div>
                            <h2 class="blog-title"><a href="blog-details.html">Hair stylist and makeup artist for over 12 years redefine.</a></h2>
                            <p>Conveniently whiteboard team building architectures without sticky partnerships. Energistically redefine emerging paradigms after resource sucking bandwidth. Dramatically supply transparent expertise whereas market-driven testingtodo procedures. Professionally visualize client-centric services via inexpensive models.</p>
                            <a href="blog-details.html" class="link-btn"><i class="fas fa-chevron-right"></i>Continue Reading</a>
                        </div>
                    </div>
                    <div class="vs-blog blog-single">
                        <div class="blog-img vs-carousel" data-arrows="true" data-slide-show="1">
                            <a href="blog-details.html"><img src="assets/img/blog/blog-s-1-2.jpg" alt="Blog Image"></a>
                            <a href="blog-details.html"><img src="assets/img/blog/blog-s-1-3.jpg" alt="Blog Image"></a>
                        </div>
                        <div class="blog-content">
                            <div class="blog-meta">
                                <a href="blog.html"><i class="fal fa-eye"></i>456 Views</a>
                                <a href="blog.html"><i class="fal fa-comments"></i>11 Comments</a>
                                <a href="blog.html"><i class="fal fa-calendar-alt"></i>25 December, 2022</a>
                            </div>
                            <h2 class="blog-title"><a href="blog-details.html">Latin derived from Cicero's 1st-century BC text De Finibus</a></h2>
                            <p>Conveniently whiteboard team building architectures without sticky partnerships. Energistically redefine emerging paradigms after resource sucking bandwidth. Dramatically supply transparent expertise whereas market-driven testingtodo procedures. Professionally visualize client-centric services via inexpensive models.</p>
                            <a href="blog-details.html" class="link-btn"><i class="fas fa-chevron-right"></i>Continue Reading</a>
                        </div>
                    </div>
                    <div class="vs-blog blog-single">
                        <div class="blog-content">
                            <div class="blog-meta">
                                <a href="blog.html"><i class="fal fa-eye"></i>232 Views</a>
                                <a href="blog.html"><i class="fal fa-comments"></i>17 Comments</a>
                                <a href="blog.html"><i class="fal fa-calendar-alt"></i>22 June, 2022</a>
                            </div>
                            <h2 class="blog-title"><a href="blog-details.html">Until recently, the prevailing view lorem ipsum was born as a</a></h2>
                            <p>Conveniently whiteboard team building architectures without sticky partnerships. Energistically redefine emerging paradigms after resource sucking bandwidth. Dramatically supply transparent expertise whereas market-driven testingtodo procedures. Professionally visualize client-centric services via inexpensive models.</p>
                            <a href="blog-details.html" class="link-btn"><i class="fas fa-chevron-right"></i>Continue Reading</a>
                        </div>
                    </div>
                    <div class="vs-blog blog-single">
                        <div class="blog-img">
                            <a href="blog-details.html"><img src="assets/img/blog/blog-s-1-4.jpg" alt="Blog Image"></a>
                            <a href="https://www.youtube.com/watch?v=_sI_Ps7JSEk" class="play-btn popup-video"><i class="fas fa-play"></i></a>
                        </div>
                        <div class="blog-content">
                            <div class="blog-meta">
                                <a href="blog.html"><i class="fal fa-eye"></i>576 Views</a>
                                <a href="blog.html"><i class="fal fa-comments"></i>05 Comments</a>
                                <a href="blog.html"><i class="fal fa-calendar-alt"></i>17 Augest, 2022</a>
                            </div>
                            <h2 class="blog-title"><a href="blog-details.html">In particular, the garbled lorem bear an unmist resemblance </a></h2>
                            <p>Conveniently whiteboard team building architectures without sticky partnerships. Energistically redefine emerging paradigms after resource sucking bandwidth. Dramatically supply transparent expertise whereas market-driven testingtodo procedures. Professionally visualize client-centric services via inexpensive models.</p>
                            <a href="blog-details.html" class="link-btn"><i class="fas fa-chevron-right"></i>Continue Reading</a>
                        </div>
                    </div>
                    <div class="vs-blog blog-single">
                        <div class="blog-audio">
                            <iframe title="Tell Me U Luv Me (with Trippie Redd) by Juice WRLD" width="751" height="200" src="https://w.soundcloud.com/player/?visual=true&amp;url=https%3A%2F%2Fapi.soundcloud.com%2Ftracks%2F830279092&amp;show_artwork=true&amp;maxwidth=751&amp;maxheight=1000&amp;dnt=1"></iframe>
                        </div>
                        <div class="blog-content">
                            <div class="blog-meta">
                                <a href="blog.html"><i class="fal fa-eye"></i>899 Views</a>
                                <a href="blog.html"><i class="fal fa-comments"></i>25 Comments</a>
                                <a href="blog.html"><i class="fal fa-calendar-alt"></i>22 July, 2022</a>
                            </div>
                            <h2 class="blog-title"><a href="blog-details.html">Creation for the standard lorem ipsum redefine the classical</a></h2>
                            <p>Conveniently whiteboard team building architectures without sticky partnerships. Energistically redefine emerging paradigms after resource sucking bandwidth. Dramatically supply transparent expertise whereas market-driven testingtodo procedures. Professionally visualize client-centric services via inexpensive models.</p>
                            <a href="blog-details.html" class="link-btn"><i class="fas fa-chevron-right"></i>Continue Reading</a>
                        </div>
                    </div>
                    <div class="vs-pagination pb-30">
                        <ul>
                            <li><a href="#" class="active">1</a></li>
                            <li><a href="#">2</a></li>
                            <li><a href="#">3</a></li>
                            <li><a href="#"><i class="fas fa-angle-right"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4">
                    <aside class="sidebar-area">
                        <div class="widget  ">
                            <h3 class="widget_title">Recent Post</h3>
                            <div class="recent-post-wrap">
                                <div class="recent-post">
                                    <div class="media-img">
                                        <a href="blog-details.html"><img src="assets/img/blog/recent-post-1-1.jpg" alt="Blog Image"></a>
                                    </div>
                                    <div class="media-body">
                                        <h4 class="post-title"><a class="text-inherit" href="blog-details.html">Easy DIY homemade hair treatments</a></h4>
                                        <div class="recent-post-meta">
                                            <a href="blog.html"><i class="fal fa-calendar-alt"></i>Dec 12, 2022</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="recent-post">
                                    <div class="media-img">
                                        <a href="blog-details.html"><img src="assets/img/blog/recent-post-1-2.jpg" alt="Blog Image"></a>
                                    </div>
                                    <div class="media-body">
                                        <h4 class="post-title"><a class="text-inherit" href="blog-details.html">Hair treatment isn't always top of mind</a></h4>
                                        <div class="recent-post-meta">
                                            <a href="blog.html"><i class="fal fa-calendar-alt"></i>Feb 22, 2022</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="recent-post">
                                    <div class="media-img">
                                        <a href="blog-details.html"><img src="assets/img/blog/recent-post-1-3.jpg" alt="Blog Image"></a>
                                    </div>
                                    <div class="media-body">
                                        <h4 class="post-title"><a class="text-inherit" href="blog-details.html">Hair tends to be oily, you can do a leave</a></h4>
                                        <div class="recent-post-meta">
                                            <a href="blog.html"><i class="fal fa-calendar-alt"></i>Mar 13, 2022</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="widget widget_categories   ">
                            <h3 class="widget_title">Categories</h3>
                            <ul>
                                <li>
                                    <a href="blog.html">Hair treatment</a>
                                    <span>15</span>
                                </li>
                                <li>
                                    <a href="blog.html">Colored Hair</a>
                                    <span>11</span>
                                </li>
                                <li>
                                    <a href="blog.html">Haircut Styles</a>
                                    <span>55</span>
                                </li>
                                <li>
                                    <a href="blog.html">Hair Health</a>
                                    <span>60</span>
                                </li>
                                <li>
                                    <a href="blog.html">Hair Oil</a>
                                    <span>12</span>
                                </li>
                                <li>
                                    <a href="blog.html">Quality Products</a>
                                    <span>18</span>
                                </li>
                            </ul>
                        </div>
                        <div class="widget  ">
                            <h3 class="widget_title">Intro Video</h3>
                            <div class="vs-video-widget">
                                <div class="video-thumb">
                                    <img src="assets/img/blog/intro-video-thumb.jpg" alt="Video Thumb" class="w-100">
                                    <a href="https://www.youtube.com/watch?v=_sI_Ps7JSEk" class="play-btn popup-video"><i class="fas fa-play"></i></a>
                                </div>
                                <h4 class="video-thumb-title">Hairdressers by helping them to continuously improve</h4>
                            </div>
                        </div>
                        <div class="widget  ">
                            <h4 class="widget_title">Gallery Posts</h4>
                            <div class="sidebar-gallery">
                                <div class="gallery-thumb">
                                    <img src="assets/img/widget/gal-1-1.jpg" alt="Gallery Image" class="w-100">
                                    <a href="assets/img/widget/gal-1-1.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                                </div>
                                <div class="gallery-thumb">
                                    <img src="assets/img/widget/gal-1-2.jpg" alt="Gallery Image" class="w-100">
                                    <a href="assets/img/widget/gal-1-2.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                                </div>
                                <div class="gallery-thumb">
                                    <img src="assets/img/widget/gal-1-3.jpg" alt="Gallery Image" class="w-100">
                                    <a href="assets/img/widget/gal-1-3.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                                </div>
                                <div class="gallery-thumb">
                                    <img src="assets/img/widget/gal-1-4.jpg" alt="Gallery Image" class="w-100">
                                    <a href="assets/img/widget/gal-1-4.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                                </div>
                                <div class="gallery-thumb">
                                    <img src="assets/img/widget/gal-1-5.jpg" alt="Gallery Image" class="w-100">
                                    <a href="assets/img/widget/gal-1-5.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                                </div>
                                <div class="gallery-thumb">
                                    <img src="assets/img/widget/gal-1-6.jpg" alt="Gallery Image" class="w-100">
                                    <a href="assets/img/widget/gal-1-6.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                        </div>
                    </aside>
                </div>
            </div>
        </div>
    </section>
    <?php include'footer.php' ?>

</body>

</html>