<!doctype html>
<html class="no-js" lang="zxx">
       <!-- Favicons - Place favicon.ico in the root directory -->
    <link rel="icon" type="image/png" size="16x16" href="assets/img/logo-1.png">
    <!-- <link rel="manifest" href="assets/img/favicons/manifest.json"> -->
    



<body>

    <?php include'connection.php'; ?>
    <?php include'header.php'?> 
    <style>
    .ls-bg1{
        transform:translateX(0px) translateY(-10px) !important;
    }
    .ls-bg2{
        transform:translateX(0px) translateY(-50px) !important;
    }
    </style>
    <!--==============================
      Hero Area
    ==============================-->
    <section class="vs-hero-wrapper position-relative  ">
        <div class="vs-hero-carousel" data-height="850" data-container="1900" data-slidertype="responsive" data-navprevnext="true">
            <!-- Slide 4 -->
            <div class="ls-slide" data-ls="duration:12000; transition2d:5; kenburnsscale:1.2;">
                <img src="assets/img/hero/04.jpg" class="ls-bg" alt="bgimg" />
                <!-- <p style="top:770px; left:50%; background-size:inherit; background-position:inherit; width:230px; height:1px; background-color:#ad8858; z-index:800;" class="ls-l ls-hide-tablet ls-hide-phone" data-ls="durationin:11900; fadein:false; scalexin:0; transformoriginin:0% 50% 0;"></p>
                <p style="top:755px; left:810px; font-weight:600; background-size:inherit; background-position:inherit; font-size:26px; font-family:Syne; color:#fff;" class="ls-l ls-hide-tablet ls-hide-phone" data-ls="fadein:true; fadeout:true;">3</p> -->
                <h1 style="top:361px; left:50%; font-weight:600; background-size:inherit; background-position:inherit; font-size:80px; color:#fff; font-family:Syne;" class="ls-l ls-hide-tablet ls-hide-phone" data-ls="offsetyin:-100; durationin:1500; delayin:400; easingin:easeOutQuint; offsetyout:-100; easingout:easeOutQuint;">
                  <img src="assets/img/logo-loader.png" class="w-100" alt="Haarino">
                </h1>
            
                <a class="ls-l ls-hide-tablet ls-hide-phone" href="our-stylist.php" target="_self" data-ls="offsetyin:100; delayin:500; easingin:easeOutQuint; offsetyout:100; easingout:easeOutQuint; hover:true; hoverdurationin:300; hovereasingin:easeOutQuint; hoverbgcolor:#fff; hovercolor:#000;"><span style="top:610px; left:50%; text-align:center; font-weight:600; background-size:inherit; background-position:inherit; padding-top:0px; padding-right:50px; padding-bottom:0px; padding-left:50px; font-size:16px; background-image:linear-gradient(to right, #902E81 0%, #DF3973 51%, #902E81 100%);; color:#fff; border-radius:9999px; font-family:Syne; line-height:70px;" class="">FIND OUT MORE</span></a>
                <h1 style="top:310px; left:50%; font-weight:600; background-size:inherit; background-position:inherit; font-size:100px; color:#fff; font-family:Syne;" class="ls-l ls-hide-desktop ls-hide-phone" data-ls="offsetyin:-100; durationin:1500; delayin:400; easingin:easeOutQuint; offsetyout:-100; easingout:easeOutQuint;">
                <img src="assets/img/logo-loader.png" class="w-100" alt="Haarino">
                </h1>
             
                <a class="ls-l ls-hide-desktop ls-hide-phone" href="our-stylist.php" target="_self" data-ls="offsetyin:100; delayin:500; easingin:easeOutQuint; offsetyout:100; easingout:easeOutQuint; hover:true; hoverdurationin:300; hovereasingin:easeOutQuint; hoverbgcolor:#fff; hovercolor:#000;"><span style="top:610px; left:50%; text-align:center; font-weight:400; background-size:inherit; background-position:inherit; padding-top:0px; padding-right:60px; padding-bottom:0px; padding-left:60px; font-size:26px; background-image:linear-gradient(to right, #902E81 0%, #DF3973 51%, #902E81 100%); color:#fff; border-radius:9999px; font-family:Syne; line-height:100px; letter-spacing:2px;" class="">FIND OUT MORE</span></a>
                <h1 style="top:200px; left:50%; font-weight:600; background-size:inherit; background-position:inherit; font-size:120px; color:#fff; font-family:Syne;" class="ls-l ls-hide-desktop ls-hide-tablet" data-ls="offsetyin:-100; durationin:1500; delayin:400; easingin:easeOutQuint; offsetyout:-100; easingout:easeOutQuint;">
                   <img src="assets/img/logo-loader.png" class="w-100" alt="Haarino">
                </h1>
                
                <a class="ls-l ls-hide-desktop ls-hide-tablet" href="our-stylist.php" target="_self" data-ls="offsetyin:100; delayin:500; easingin:easeOutQuint; offsetyout:100; easingout:easeOutQuint; hover:true; hoverdurationin:300; hovereasingin:easeOutQuint; hoverbgcolor:#fff; hovercolor:#000;"><span style="top:540px; left:50%; text-align:center; font-weight:400; background-size:inherit; background-position:inherit; padding-top:0px; padding-right:90px; padding-bottom:0px; padding-left:90px; background-image:linear-gradient(to right, #902E81 0%, #DF3973 51%, #902E81 100%); color:#fff; border-radius:9999px; font-family:Syne; line-height:160px; letter-spacing:2px; font-size:58px;" class="">FIND OUT MORE</span></a>
            </div>
            <!-- Slide 4 -->
            <div class="ls-slide" data-ls="duration:12000; transition2d:5; kenburnsscale:1.2;">
                <img src="assets/img/hero/hairdresser-taking.jpg" class="ls-bg" alt="bgimg" />
                <!-- <p style="top:770px; left:50%; background-size:inherit; background-position:inherit; width:230px; height:1px; background-color:#ad8858; z-index:800;" class="ls-l ls-hide-tablet ls-hide-phone" data-ls="durationin:11900; fadein:false; scalexin:0; transformoriginin:0% 50% 0;"></p>
                <p style="top:755px; left:810px; font-weight:600; background-size:inherit; background-position:inherit; font-size:26px; font-family:Syne; color:#fff;" class="ls-l ls-hide-tablet ls-hide-phone" data-ls="fadein:true; fadeout:true;">3</p> -->
                <h1 style="top:361px; left:50%; font-weight:600; background-size:inherit; background-position:inherit; font-size:80px; color:#fff; font-family:Syne;" class="ls-l ls-hide-tablet ls-hide-phone" data-ls="offsetyin:-100; durationin:1500; delayin:400; easingin:easeOutQuint; offsetyout:-100; easingout:easeOutQuint;">
                  <img src="assets/img/logo-loader.png" class="w-100" alt="Haarino">
                </h1>
            
                <a class="ls-l ls-hide-tablet ls-hide-phone" href="our-stylist.php" target="_self" data-ls="offsetyin:100; delayin:500; easingin:easeOutQuint; offsetyout:100; easingout:easeOutQuint; hover:true; hoverdurationin:300; hovereasingin:easeOutQuint; hoverbgcolor:#fff; hovercolor:#000;"><span style="top:610px; left:50%; text-align:center; font-weight:600; background-size:inherit; background-position:inherit; padding-top:0px; padding-right:50px; padding-bottom:0px; padding-left:50px; font-size:16px; background-image:linear-gradient(to right, #902E81 0%, #DF3973 51%, #902E81 100%);; color:#fff; border-radius:9999px; font-family:Syne; line-height:70px;" class="">FIND OUT MORE</span></a>
                <h1 style="top:310px; left:50%; font-weight:600; background-size:inherit; background-position:inherit; font-size:100px; color:#fff; font-family:Syne;" class="ls-l ls-hide-desktop ls-hide-phone" data-ls="offsetyin:-100; durationin:1500; delayin:400; easingin:easeOutQuint; offsetyout:-100; easingout:easeOutQuint;">
                <img src="assets/img/logo-loader.png" class="w-100" alt="Haarino">
                </h1>
             
                <a class="ls-l ls-hide-desktop ls-hide-phone" href="our-stylist.php" target="_self" data-ls="offsetyin:100; delayin:500; easingin:easeOutQuint; offsetyout:100; easingout:easeOutQuint; hover:true; hoverdurationin:300; hovereasingin:easeOutQuint; hoverbgcolor:#fff; hovercolor:#000;"><span style="top:610px; left:50%; text-align:center; font-weight:400; background-size:inherit; background-position:inherit; padding-top:0px; padding-right:60px; padding-bottom:0px; padding-left:60px; font-size:26px; background-image:linear-gradient(to right, #902E81 0%, #DF3973 51%, #902E81 100%); color:#fff; border-radius:9999px; font-family:Syne; line-height:100px; letter-spacing:2px;" class="">FIND OUT MORE</span></a>
                <h1 style="top:200px; left:50%; font-weight:600; background-size:inherit; background-position:inherit; font-size:120px; color:#fff; font-family:Syne;" class="ls-l ls-hide-desktop ls-hide-tablet" data-ls="offsetyin:-100; durationin:1500; delayin:400; easingin:easeOutQuint; offsetyout:-100; easingout:easeOutQuint;">
                   <img src="assets/img/logo-loader.png" class="w-100" alt="Haarino">
                </h1>
                
                <a class="ls-l ls-hide-desktop ls-hide-tablet" href="our-stylist.php" target="_self" data-ls="offsetyin:100; delayin:500; easingin:easeOutQuint; offsetyout:100; easingout:easeOutQuint; hover:true; hoverdurationin:300; hovereasingin:easeOutQuint; hoverbgcolor:#fff; hovercolor:#000;"><span style="top:540px; left:50%; text-align:center; font-weight:400; background-size:inherit; background-position:inherit; padding-top:0px; padding-right:90px; padding-bottom:0px; padding-left:90px; background-image:linear-gradient(to right, #902E81 0%, #DF3973 51%, #902E81 100%); color:#fff; border-radius:9999px; font-family:Syne; line-height:160px; letter-spacing:2px; font-size:58px;" class="">FIND OUT MORE</span></a>
            </div>
            <!-- Slide 4 -->
            <div class="ls-slide" data-ls="duration:12000; transition2d:5; kenburnsscale:1.2;">
                <img src="assets/img/hero/high-angle.jpg" class="ls-bg" alt="bgimg" />
                <!-- <p style="top:770px; left:50%; background-size:inherit; background-position:inherit; width:230px; height:1px; background-color:#ad8858; z-index:800;" class="ls-l ls-hide-tablet ls-hide-phone" data-ls="durationin:11900; fadein:false; scalexin:0; transformoriginin:0% 50% 0;"></p>
                <p style="top:755px; left:810px; font-weight:600; background-size:inherit; background-position:inherit; font-size:26px; font-family:Syne; color:#fff;" class="ls-l ls-hide-tablet ls-hide-phone" data-ls="fadein:true; fadeout:true;">3</p> -->
                <h1 style="top:361px; left:50%; font-weight:600; background-size:inherit; background-position:inherit; font-size:80px; color:#fff; font-family:Syne;" class="ls-l ls-hide-tablet ls-hide-phone" data-ls="offsetyin:-100; durationin:1500; delayin:400; easingin:easeOutQuint; offsetyout:-100; easingout:easeOutQuint;">
                  <img src="assets/img/logo-loader.png" class="w-100" alt="Haarino">
                </h1>
            
                <a class="ls-l ls-hide-tablet ls-hide-phone" href="our-stylist.php" target="_self" data-ls="offsetyin:100; delayin:500; easingin:easeOutQuint; offsetyout:100; easingout:easeOutQuint; hover:true; hoverdurationin:300; hovereasingin:easeOutQuint; hoverbgcolor:#fff; hovercolor:#000;"><span style="top:610px; left:50%; text-align:center; font-weight:600; background-size:inherit; background-position:inherit; padding-top:0px; padding-right:50px; padding-bottom:0px; padding-left:50px; font-size:16px; background-image:linear-gradient(to right, #902E81 0%, #DF3973 51%, #902E81 100%);; color:#fff; border-radius:9999px; font-family:Syne; line-height:70px;" class="">FIND OUT MORE</span></a>
                <h1 style="top:310px; left:50%; font-weight:600; background-size:inherit; background-position:inherit; font-size:100px; color:#fff; font-family:Syne;" class="ls-l ls-hide-desktop ls-hide-phone" data-ls="offsetyin:-100; durationin:1500; delayin:400; easingin:easeOutQuint; offsetyout:-100; easingout:easeOutQuint;">
                <img src="assets/img/logo-loader.png" class="w-100" alt="Haarino">
                </h1>
             
                <a class="ls-l ls-hide-desktop ls-hide-phone" href="our-stylist.php" target="_self" data-ls="offsetyin:100; delayin:500; easingin:easeOutQuint; offsetyout:100; easingout:easeOutQuint; hover:true; hoverdurationin:300; hovereasingin:easeOutQuint; hoverbgcolor:#fff; hovercolor:#000;"><span style="top:610px; left:50%; text-align:center; font-weight:400; background-size:inherit; background-position:inherit; padding-top:0px; padding-right:60px; padding-bottom:0px; padding-left:60px; font-size:26px; background-image:linear-gradient(to right, #902E81 0%, #DF3973 51%, #902E81 100%); color:#fff; border-radius:9999px; font-family:Syne; line-height:100px; letter-spacing:2px;" class="">FIND OUT MORE</span></a>
                <h1 style="top:200px; left:50%; font-weight:600; background-size:inherit; background-position:inherit; font-size:120px; color:#fff; font-family:Syne;" class="ls-l ls-hide-desktop ls-hide-tablet" data-ls="offsetyin:-100; durationin:1500; delayin:400; easingin:easeOutQuint; offsetyout:-100; easingout:easeOutQuint;">
                   <img src="assets/img/logo-loader.png" class="w-100" alt="Haarino">
                </h1>
                
                <a class="ls-l ls-hide-desktop ls-hide-tablet" href="our-stylist.php" target="_self" data-ls="offsetyin:100; delayin:500; easingin:easeOutQuint; offsetyout:100; easingout:easeOutQuint; hover:true; hoverdurationin:300; hovereasingin:easeOutQuint; hoverbgcolor:#fff; hovercolor:#000;"><span style="top:540px; left:50%; text-align:center; font-weight:400; background-size:inherit; background-position:inherit; padding-top:0px; padding-right:90px; padding-bottom:0px; padding-left:90px; background-image:linear-gradient(to right, #902E81 0%, #DF3973 51%, #902E81 100%); color:#fff; border-radius:9999px; font-family:Syne; line-height:160px; letter-spacing:2px; font-size:58px;" class="">FIND OUT MORE</span></a>
            </div>
            <!-- Slide 4 -->
            <div class="ls-slide" data-ls="duration:12000; transition2d:5; kenburnsscale:1.2;">
                <img src="assets/img/hero/Imagesadsd.jpg" class="ls-bg" alt="bgimg" />
                <!-- <p style="top:770px; left:50%; background-size:inherit; background-position:inherit; width:230px; height:1px; background-color:#ad8858; z-index:800;" class="ls-l ls-hide-tablet ls-hide-phone" data-ls="durationin:11900; fadein:false; scalexin:0; transformoriginin:0% 50% 0;"></p>
                <p style="top:755px; left:810px; font-weight:600; background-size:inherit; background-position:inherit; font-size:26px; font-family:Syne; color:#fff;" class="ls-l ls-hide-tablet ls-hide-phone" data-ls="fadein:true; fadeout:true;">3</p> -->
                <h1 style="top:361px; left:50%; font-weight:600; background-size:inherit; background-position:inherit; font-size:80px; color:#fff; font-family:Syne;" class="ls-l ls-hide-tablet ls-hide-phone" data-ls="offsetyin:-100; durationin:1500; delayin:400; easingin:easeOutQuint; offsetyout:-100; easingout:easeOutQuint;">
                  <img src="assets/img/logo-loader.png" class="w-100" alt="Haarino">
                </h1>
            
                <a class="ls-l ls-hide-tablet ls-hide-phone" href="our-stylist.php" target="_self" data-ls="offsetyin:100; delayin:500; easingin:easeOutQuint; offsetyout:100; easingout:easeOutQuint; hover:true; hoverdurationin:300; hovereasingin:easeOutQuint; hoverbgcolor:#fff; hovercolor:#000;"><span style="top:610px; left:50%; text-align:center; font-weight:600; background-size:inherit; background-position:inherit; padding-top:0px; padding-right:50px; padding-bottom:0px; padding-left:50px; font-size:16px; background-image:linear-gradient(to right, #902E81 0%, #DF3973 51%, #902E81 100%);; color:#fff; border-radius:9999px; font-family:Syne; line-height:70px;" class="">FIND OUT MORE</span></a>
                <h1 style="top:310px; left:50%; font-weight:600; background-size:inherit; background-position:inherit; font-size:100px; color:#fff; font-family:Syne;" class="ls-l ls-hide-desktop ls-hide-phone" data-ls="offsetyin:-100; durationin:1500; delayin:400; easingin:easeOutQuint; offsetyout:-100; easingout:easeOutQuint;">
                <img src="assets/img/logo-loader.png" class="w-100" alt="Haarino">
                </h1>
             
                <a class="ls-l ls-hide-desktop ls-hide-phone" href="our-stylist.php" target="_self" data-ls="offsetyin:100; delayin:500; easingin:easeOutQuint; offsetyout:100; easingout:easeOutQuint; hover:true; hoverdurationin:300; hovereasingin:easeOutQuint; hoverbgcolor:#fff; hovercolor:#000;"><span style="top:610px; left:50%; text-align:center; font-weight:400; background-size:inherit; background-position:inherit; padding-top:0px; padding-right:60px; padding-bottom:0px; padding-left:60px; font-size:26px; background-image:linear-gradient(to right, #902E81 0%, #DF3973 51%, #902E81 100%); color:#fff; border-radius:9999px; font-family:Syne; line-height:100px; letter-spacing:2px;" class="">FIND OUT MORE</span></a>
                <h1 style="top:200px; left:50%; font-weight:600; background-size:inherit; background-position:inherit; font-size:120px; color:#fff; font-family:Syne;" class="ls-l ls-hide-desktop ls-hide-tablet" data-ls="offsetyin:-100; durationin:1500; delayin:400; easingin:easeOutQuint; offsetyout:-100; easingout:easeOutQuint;">
                   <img src="assets/img/logo-loader.png" class="w-100" alt="Haarino">
                </h1>
                
                <a class="ls-l ls-hide-desktop ls-hide-tablet" href="our-stylist.php" target="_self" data-ls="offsetyin:100; delayin:500; easingin:easeOutQuint; offsetyout:100; easingout:easeOutQuint; hover:true; hoverdurationin:300; hovereasingin:easeOutQuint; hoverbgcolor:#fff; hovercolor:#000;"><span style="top:540px; left:50%; text-align:center; font-weight:400; background-size:inherit; background-position:inherit; padding-top:0px; padding-right:90px; padding-bottom:0px; padding-left:90px; background-image:linear-gradient(to right, #902E81 0%, #DF3973 51%, #902E81 100%); color:#fff; border-radius:9999px; font-family:Syne; line-height:160px; letter-spacing:2px; font-size:58px;" class="">FIND OUT MORE</span></a>
            </div>
            
            
        </div>
    </section>




    <!-- new-new-services start-->
    <!-- <section class="vs-about-wrapper space-top">
        <div class="shape-mockup jump-reverse-img d-none d-xxl-block" data-top="22%" data-left="-7%">
            
        </div>
        <div class="shape-mockup jump-img d-none d-xxxl-block" data-top="17%" data-right="13%"><img
                src="assets/img/shape/leaf-1-4.png" alt="shape"></div>
        <div class="container">
            <div class="row justify-content-center text-center">
                <div class="col-lg-8 col-xl-9">
                    <div class="title-area">
                        <div class="sec-icon">
                            <img src="assets/img/icon/sec-icon.png" alt="Section Title">
                        </div>
                        <span class="sub-title">REFRESH HAIR<span class="sec-subtext">STUDIO</span></span>
                        <h2 class="sec-title">A WHOLE <span class="text-theme">NEW YOU</span></h2>
                        <p class="quote-text">"Your hair should look great and suit your lifestyle. Refresh your style today."</p>
                </div>
            </div>


    </section>




<div class="position-relative space-extra-bottom">
        <div class="hero-layout3">
            <div class="vs-carousel" data-arrows="true" data-slide-show="1" data-lg-slide-show="1"
                data-center-mode="true" data-xl-center-mode="true" data-ml-center-mode="true" data-lg-center-mode="true"
                data-md-center-mode="true" data-center-padding="575px" data-xl-center-padding="475px"
                data-ml-center-padding="400px" data-lg-center-padding="450px" data-md-center-padding="180px"
                data-sm-center-padding="150px" data-xs-center-padding="200px" id="heroimg" data-asnavfor="#herocontent">
                <div>
                    <div class="hero-img">
                        <a href="assets/img/hero/double-dose2.jpeg" data-lightbox="gallery">
                            <img src="assets/img/hero/double-dose2.jpeg" alt="hero" class="w-100">
                        </a>
                    </div>
                </div>
                <div>
                    <div class="hero-img">
                        <a href="assets/img/hero/the-works3.jpeg" data-lightbox="gallery">
                            <img src="assets/img/hero/the-works3.jpeg" alt="hero" class="w-100">
                    </div>
                    </a>
                </div>
                <div>
                    <div class="hero-img">
                        <a href="assets/img/hero/pick-me-up3.jpeg" data-lightbox="gallery">
                            <img src="assets/img/hero/pick-me-up3.jpeg" alt="hero" class="w-100">
                    </div>
                    </a>
                </div>
                <div>
                    <div class="hero-img">
                        <a href="assets/img/hero/single-dose2.jpeg" data-lightbox="gallery">
                            <img src="assets/img/hero/single-dose2.jpeg" alt="hero" class="w-100">
                    </div>
                    </a>
                </div>



              




            </div>
            <div class="media-slider">

                <div class="vs-carousel" data-asnavfor="#heroimg" id="herocontent" data-slide-show="3"
                    data-center-mode="true" data-xl-center-mode="true" data-ml-center-mode="true"
                    data-lg-center-mode="true" data-md-center-mode="true" data-md-center-padding="120px">
                    <div>
                        <div class="media-style2">
                            <div class="media-shape"></div><span class="media-label">Two Step Color Application</span>
                            <p class="media-title">A DOUBLE DOSE</p>
                            <div class="media-line"></div>
                        </div>
                    </div>
                    <div>
                        <div class="media-style2">
                            <div class="media-shape"></div><span class="media-label">Full Custom Color
                                Transformation</span>
                            <p class="media-title">THE WORKS</p>
                            <div class="media-line"></div>
                        </div>
                    </div>
                    <div>
                        <div class="media-style2">
                            <div class="media-shape"></div><span class="media-label">Partial Custom Color
                                Transformation</span>
                            <p class="media-title">A PICK ME UP</p>
                            <div class="media-line"></div>
                        </div>
                    </div>
                    <div>
                        <div class="media-style2">
                            <div class="media-shape"></div><span class="media-label">One Color Application</span>
                            <p class="media-title">A SINGLE DOSE</p>
                            <div class="media-line"></div>
                        </div>
                    </div>





                </div>
            </div>
        </div>

        

    </div> -->


     <!-- new-new-services end-->







<!--==============================
    About Area
    ==============================-->
    <section class="vs-about-wrapper space-top">
        <div class="shape-mockup jump-reverse-img d-none d-xxl-block" data-top="22%" data-left="-7%">
        </div>
        <div class="shape-mockup jump-img d-none d-xxxl-block" data-top="17%" data-right="13%"><img
                src="assets/img/shape/leaf-1-4.png" alt="shape"></div>
        <div class="container">
            <div class="row justify-content-center text-center">
                <div class="col-lg-8 col-xl-9">
                    <div class="title-area">
                        <!--<div class="sec-icon">-->
                        <!--    <img src="assets/img/icon/sec-icon.png" alt="Section Title">-->
                        <!--</div>-->
                        
                        <h2 class="sec-title">Specializing In  <span class="text-theme">Custom Color!</span></h2>
                        <p class="quote-text">"We work with you to create a plan based on your desired goals! "</p>
                </div>
            </div>


    </section>
    <!--==============================
  What We Do
  ============================== -->
    <section class="what-we-do-wrapper space-negative-bottom">



        <div class="container">
            <!--<div class="carousel-controls">-->
            <!--  <button type="button" data-slick-prev=".vs-carousel" class="slick-prev">-->
            <!--    <i class="long-arrow"></i>-->
            <!--  </button>-->
            <!--  <button type="button" data-slick-next=".vs-carousel" class="slick-next">-->
            <!--    <i class="long-arrow"></i>-->
            <!--  </button>-->
            <!--</div>-->
            <div class="row vs-carousel" data-slide-show="4" data-sm-slide-show="2" data-xs-slide-show="1">
                <div class="col-xl-3">
                    <div class="process-box">
                        <div class="process-img">
                            <span class="process-border"></span>
                            <span class="process-border border2"></span>
                            <img src="assets/img/process/IMG_3575.jpeg" alt="Process image" class="w-100">
                        </div>
                        <div class="process-content">
                            <h3 class="process-title"><a class="text-reset" href="Full-Custom-Color-Transformation.php">Full Refresh Custom Color</a></h3>
                        </div>
                        <!--<a href="Full-Custom-Color-Transformation.php" class="process-btn"><i class="fas fa-chevron-right"></i></a>-->
                    </div>
                </div>
                 <div class="col-xl-3">
                    <div class="process-box">
                        <div class="process-img">
                            <span class="process-border"></span>
                            <span class="process-border border2"></span>
                            <img src="assets/img/process/Download (1).jpg" alt="Process image" class="w-100">
                            <!--<img src="assets/img/process/Full-Custom-Color-Transformation.jpg" alt="Process image" class="w-100">-->
                        </div>
                        <div class="process-content">
                            <h3 class="process-title"><a class="text-reset" href="Partial-Custom-Color-Transformation.php">Partial Refresh Custom Color</a></h3>
                        </div>
                        <!--<a href="Partial-Custom-Color-Transformation.php" class="process-btn"><i class="fas fa-chevron-right"></i></a>-->
                    </div>
                </div>
                <div class="col-xl-3">
                    <div class="process-box">
                        <div class="process-img">
                            <span class="process-border"></span>
                            <span class="process-border border2"></span>
                            <img src="assets/img/process/mini.jpg" alt="Process image" class="w-100">
                        </div>
                        <div class="process-content">
                            <h3 class="process-title"><a class="text-reset" href="teens-cut.php">Mini Makeover
                            </a></h3>
                        </div>
                        <!--<a href="Custom-Color-Consultation.php" class="process-btn"><i class="fas fa-chevron-right"></i></a>-->
                    </div>
                </div>
                 <div class="col-xl-3">
                    <div class="process-box">
                        <div class="process-img">
                            <span class="process-border"></span>
                            <span class="process-border border2"></span>
                            <img src="assets/img/process/Single-Application-or-Glaze.jpg" alt="Process image" class="w-100">
                        </div>
                        <div class="process-content">
                            <h3 class="process-title"><a class="text-reset" href="Single-Application.php">Single Dose Application</a></h3>
                        </div>
                        <!--<a href="Single-Application.php" class="process-btn"><i class="fas fa-chevron-right"></i></a>-->
                    </div>
                </div>
                <div class="col-xl-3">
                    <div class="process-box">
                        <div class="process-img">
                            <span class="process-border"></span>
                            <span class="process-border border2"></span>
                            <img src="assets/img/process/2-Color-Application-Color-Melt.jpg" alt="Process image" class="w-100">
                        </div>
                        <div class="process-content">
                            <h3 class="process-title"><a class="text-reset" href="2-color-application.php">Double Dose Application</a></h3>
                        </div>
                        <!--<a href="2-color-application.php" class="process-btn"><i class="fas fa-chevron-right"></i></a>-->
                    </div>
                </div>
                  <div class="col-xl-3">
                    <div class="process-box">
                        <div class="process-img">
                            <span class="process-border"></span>
                            <span class="process-border border2"></span>
                            <img src="assets/img/process/EXPRESS-ROOT-COVERAGE.jpg" alt="Process image" class="w-100">
                        </div>
                        <div class="process-content">
                            <h3 class="process-title"><a class="text-reset" href="EXPRESS-ROOT-COVERAGE.php">Express Root Touch Up</a></h3>
                        </div>
                        <!--<a href="EXPRESS-ROOT-COVERAGE.php" class="process-btn"><i class="fas fa-chevron-right"></i></a>-->
                    </div>
                </div>



                <div class="col-xl-3">
                    <div class="process-box">
                        <div class="process-img">
                            <span class="process-border"></span>
                            <span class="process-border border2"></span>
                            <img src="assets/img/process/the-works.jpg" alt="Process image" class="w-100">
                        </div>
                        <div class="process-content">
                            <h3 class="process-title"><a class="text-reset" href="THE-WORKS.php">THE WORKS</a></h3>
                        </div>
                        <!--<a href="THE-WORKS.php" class="process-btn"><i class="fas fa-chevron-right"></i></a>-->
                    </div>
                </div>
                <div class="col-xl-3">
                    <div class="process-box">
                        <div class="process-img">
                            <span class="process-border"></span>
                            <span class="process-border border2"></span>
                            <img src="assets/img/process/HAIRCUT-STYLE.jpg" alt="Process image" class="w-100">
                        </div>
                        <div class="process-content">
                            <h3 class="process-title"><a class="text-reset" href="haircut-style.php">Haircut and style
                            </a></h3>
                        </div>
                        <!--<a href="Custom-Color-Consultation.php" class="process-btn"><i class="fas fa-chevron-right"></i></a>-->
                    </div>
                </div>
                <div class="col-xl-3">
                    <div class="process-box">
                        <div class="process-img">
                            <span class="process-border"></span>
                            <span class="process-border border2"></span>
                            <img src="assets/img/process/SHORT-PIXIE-CLIPPER-CUT.jpg" alt="Process image" class="w-100">
                        </div>
                        <div class="process-content">
                            <h3 class="process-title"><a class="text-reset" href="short-clipper-cut.php">Gender Neutral Pixie/Clipper Cut
                            </a></h3>
                        </div>
                        <!--<a href="Custom-Color-Consultation.php" class="process-btn"><i class="fas fa-chevron-right"></i></a>-->
                    </div>
                </div>
                 <div class="col-xl-3">
                    <div class="process-box">
                        <div class="process-img">
                            <span class="process-border"></span>
                            <span class="process-border border2"></span>
                            <img src="assets/img/process/HAIR-DETOX-Add-on.jpg" alt="Process image" class="w-100">
                        </div>
                        <div class="process-content">
                            <h3 class="process-title"><a class="text-reset" href="HAIR-DETOX-Add-on.php">HAIR DETOX Add on</a></h3>
                        </div>
                        <!--<a href="HAIR-DETOX-Add-on.php" class="process-btn"><i class="fas fa-chevron-right"></i></a>-->
                    </div>
                </div>

                <!--<div class="col-xl-3">-->
                <!--    <div class="process-box">-->
                <!--        <div class="process-img">-->
                <!--            <span class="process-border"></span>-->
                <!--            <span class="process-border border2"></span>-->
                <!--            <img src="assets/img/process/Custom-Color-Consultation.jpg" alt="Process image" class="w-100">-->
                <!--        </div>-->
                <!--        <div class="process-content">-->
                <!--            <h3 class="process-title"><a class="text-reset" href="Custom-Color-Consultation.php">Custom Color Consultation-->
                <!--            </a></h3>-->
                <!--        </div>-->
                        <!--<a href="Custom-Color-Consultation.php" class="process-btn"><i class="fas fa-chevron-right"></i></a>-->
                <!--    </div>-->
                <!--</div>-->
                
                <!--hair cut -->

                
                <div class="col-xl-3">
                    <div class="process-box">
                        <div class="process-img">
                            <span class="process-border"></span>
                            <span class="process-border border2"></span>
                            <img src="assets/img/process/IMG_4261.jpeg" alt="Process image" class="w-100">
                        </div>
                        <div class="process-content">
                            <h3 class="process-title"><a class="text-reset" href="teens-cut.php">Teens Cut and Style
                            </a></h3>
                        </div>
                        <!--<a href="Custom-Color-Consultation.php" class="process-btn"><i class="fas fa-chevron-right"></i></a>-->
                    </div>
                </div>
                <div class="col-xl-3">
                    <div class="process-box">
                        <div class="process-img">
                            <span class="process-border"></span>
                            <span class="process-border border2"></span>
                            <img src="assets/img/process/IMG_2189.jpeg" alt="Process image" class="w-100">
                        </div>
                        <div class="process-content">
                            <h3 class="process-title"><a class="text-reset" href="kids-cut.php">Kids under 12 Cut and Style
                            </a></h3>
                        </div>
                        <!--<a href="Custom-Color-Consultation.php" class="process-btn"><i class="fas fa-chevron-right"></i></a>-->
                    </div>
                </div>
                
                <div class="col-xl-3">
                    <div class="process-box">
                        <div class="process-img">
                            <span class="process-border"></span>
                            <span class="process-border border2"></span>
                            <img src="assets/img/process/grey.jpg" alt="Process image" class="w-100">
                        </div>
                        <div class="process-content">
                            <h3 class="process-title"><a class="text-reset" href="teens-cut.php">GREY BLENDING
                            </a></h3>
                        </div>
                        <!--<a href="Custom-Color-Consultation.php" class="process-btn"><i class="fas fa-chevron-right"></i></a>-->
                    </div>
                </div>


            </div>
            
            <div class="pt-40 d-flex justify-content-center gap-4">
                <button  data-slick-prev=".vs-carousel" class="slick-arrow slick-prev default"><span class="long-arrow"></span></button>
                <button  data-slick-next=".vs-carousel" class="slick-arrow slick-next default"><span class="long-arrow"></span></button>
            </div>
        </div>











        
        <!-- <div class="space-top space-negative-bottom bg-light">
            <div class="container">
                <div class="row gx-2 vs-carousel" data-slide-show="4" data-lg-slide-show="3" data-sm-slide-show="2" data-dots="true" data-speed="1500">
                    <div class="col-xl-3 mb-30">
                        <div class="vs-trends-box">
                            <div class="trends-img">
                                <img src="assets/img/trends/Untitled-1.png" alt="trends img" class="w-100">
                            </div>
                            <div class="trends-header">
                                <h3 class="trends-label">A REFRESH</h3>
                            </div>
                            <div class="trends-body">
                                <div class="trends-content">
                                    <h4 class="trends-title"><a class="text-reset" href="#">A REFRESH</a></h4>
                                    <p class="trends-text">This Service is a Full Custom Color transformation . We utilize any technique and color combination that will work in achieving your goals!</p>
                                </div>
                                <div class="trends-actions">
                                    <span class="price">$350+ <br> 3 hr & 30 min</span>
                                    <a href="#" class="icon-btn"><i class="fas fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 mb-30">
                        <div class="vs-trends-box">
                            <div class="trends-img">
                                <img src="assets/img/trends/Untitled-2.png" alt="trends img" class="w-100">
                            </div>
                            <div class="trends-header">
                                <h3 class="trends-label">A PICK ME UP</h3>
                            </div>
                            <div class="trends-body">
                                <div class="trends-content">
                                    <h4 class="trends-title"><a class="text-reset" href="#">A PICK ME UP</a></h4>
                                    <p class="trends-text">This service is recommended to be scheduled within three months of your full custom color to maintain the outgrowth and tone. May also be used to create subtle transformational color utilizing any technique necessary.</p>
                                </div>
                                <div class="trends-actions">
                                    <span class="price">$240+ <br>2 hr & 30 min</span>
                                    <a href="#" class="icon-btn"><i class="fas fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 mb-30">
                        <div class="vs-trends-box">
                            <div class="trends-img">
                                <img src="assets/img/trends/Untitled-3.png" alt="trends img" class="w-100">
                            </div>
                            <div class="trends-header">
                                <h3 class="trends-label">A SINGLE DOSE</h3>
                            </div>
                            <div class="trends-body">
                                <div class="trends-content">
                                    <h4 class="trends-title"><a class="text-reset" href="#">A SINGLE DOSE</a></h4>
                                    <p class="trends-text">A one color application from roots to ends. No lightning involved.Starts at $150 and up for additional length and or thickness</p>
                                </div>
                                <div class="trends-actions">
                                    <span class="price">$150+ <br>1 hr & 45 min</span>
                                    <a href="#" class="icon-btn"><i class="fas fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 mb-30">
                        <div class="vs-trends-box">
                            <div class="trends-img">
                                <img src="assets/img/trends/Untitled-4.png" alt="trends img" class="w-100">
                            </div>
                            <div class="trends-header">
                                <h3 class="trends-label">A DOUBLE DOSE</h3>
                            </div>
                            <div class="trends-body">
                                <div class="trends-content">
                                    <h4 class="trends-title"><a class="text-reset" href="#">A DOUBLE DOSE</a></h4>
                                    <p class="trends-text">This is a Two step color application. When going from very light to dark we will need two processing times with 2 applications. Our 1st application is to fill your hair with missing color then the 2nd application for bringing it home.</p>
                                </div>
                                <div class="trends-actions">
                                    <span class="price">$200+ <br>2 hr</span>
                                    <a href="#" class="icon-btn"><i class="fas fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 mb-30">
                        <div class="vs-trends-box">
                            <div class="trends-img">
                                <img src="assets/img/trends/Untitled-5.png" alt="trends img" class="w-100">
                            </div>
                            <div class="trends-header">
                                <h3 class="trends-label">Custom Color Consultation</h3>
                            </div>
                            <div class="trends-body">
                                <div class="trends-content">
                                    <h4 class="trends-title"><a class="text-reset" href="#">Custom Color Consultation</a></h4>
                                    <p class="trends-text">Requires an in-depth consultation in the salon to discuss your goals and desired outcome. Additional charges apply based on desired outcome, length, thickness and amount of color applied.</p>
                                </div>
                                <div class="trends-actions">
                                    <span class="price">$50.00 <br>30 min</span>
                                    <a href="#" class="icon-btn"><i class="fas fa-chevron-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->



    </section>




    <!--==============================
      Appointment Area
    ==============================-->
    <!--<section class="bg-fixed space" data-bg-src="assets/img/bg/appointment-bg.jpg" data-overlay="black" data-opacity="6" id="contact">-->
    <section class="bg-fixed space" data-overlay="black" data-opacity="6" id="contact" style="background: black;">
        <!--<div class="container z-index-common">-->
        <!--    <div class="form-media">-->
        <!--        <div class="media-icon"><i class="fal fa-calendar-alt"></i></div>-->
        <!--        <div class="media-body">-->
        <!--            <p class="media-text">Refresh Hair Studio</p>-->
        <!--            <h2 class="media-title">Make Appointment</h2>-->
        <!--        </div>-->
        <!--    </div>-->
        <!--    <form action="code.php" class="form-style1" method="POST">-->
        <!--        <div class="row gx-20">-->
        <!--            <div class="col-md-6 col-lg-4 form-group">-->
        <!--                <input type="text" name="name" class="form-control" placeholder="Your Name" required >-->
        <!--                <i class="fal fa-user"></i>-->
        <!--            </div>-->
        <!--            <div class="col-md-6 col-lg-4 form-group">-->
        <!--                <input type="email" name="email" class="form-control" placeholder="Email address" required>-->
        <!--                <i class="fal fa-envelope"></i>-->
        <!--            </div>-->
        <!--            <div class="col-md-6 col-lg-4 form-group">-->
        <!--                <input type="number" name="phone" class="form-control" placeholder="Phone number" required>-->
        <!--                <i class="fal fa-phone-alt"></i>-->
        <!--            </div>-->
        <!--            <div class="col-md-6 col-lg-4 form-group">-->
        <!--                <select name="subject" required>-->
        <!--                    <option value="">Select Subject</option>-->
        <!--                    <option value="A REFRESH">A REFRESH</option>-->
        <!--                    <option value="A PICK ME UP">A PICK ME UP</option>-->
        <!--                    <option value="A SINGLE DOSE">A SINGLE DOSE</option>-->
        <!--                    <option value="A DOUBLE DOSE">A DOUBLE DOSE</option>-->
        <!--                    <option value="EXPRESS ROOT COVERAGE">EXPRESS ROOT COVERAGE</option>-->
        <!--                    <option value="THE WORKS">THE WORKS</option>-->
        <!--                    <option value="HAIR DETOX Add on">HAIR DETOX Add on</option>-->
        <!--                    <option value="Custom Color Consultation">Custom Color Consultation</option>-->
        <!--                </select>-->
        <!--            </div>-->
        <!--            <div class="col-md-6 col-lg-4 form-group">-->
        <!--                <input type="date" name="pick_date" class="form-control date-pick" placeholder="Select Date" required>-->
                        <!--<i class="fal fa-calendar-alt"></i>-->
        <!--            </div>-->
        <!--            <div class="col-md-6 col-lg-4 form-group">-->
        <!--                <input type="time" name="pick_time" class="form-control time-pick" placeholder="Select Time" required>-->
                        <!--<i class="fal fa-clock"></i>-->
        <!--            </div>-->
        <!--            <div class="col-12 text-center">-->
        <!--                <button type="submit" name="appointment" class="vs-btn">Make Appointment<i class="fal fa-arrow-right"></i></button>-->
        <!--            </div>-->
        <!--        </div>-->
        <!--    </form>-->
        <!--</div>-->
        <div class="container">
            <div class="row justify-content-center my-lg-0 my-30">
                <div class="col-xl-8">
                    <div class="cta-content text-center link-inherit">
                        <div class="cta-thumb mb-2 mb-lg-4">
                            <img src="assets/img/white-logo.png" alt="logo">
                        </div>
                        <p class="text-white text-md">Don’t hassitate <a href="consultation.php" class="text-white"><u><b>Contact With</b></u></a> us any time</p>
                        <h2 class="sec-title mb-3 mb-lg-4 text-white">Get Your Next Look</h2>
                        <div class="d-flex gap-3 flex-wrap justify-content-center">
                            <a href="services.php" class="vs-btn">Our Services</a>
                            <a href="tel:7738157576" class="vs-btn outline-white">Make A Call</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </section>
    <!--==============================
  About Area
==============================-->
    <section class="position-relative space">
        <div class="about-shape1 d-none d-xxxl-block"><img src="assets/img/about/shape-4-1.png" alt="Shape"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-xl-5 mb-30 mb-lg-0">
                    <div class="image-box4">
                        <div class="img-1"><img src="assets/img/package/jamie-stylist.jpg" class="w-100" alt="About Image"></div>
                        <!--<div class="img-2 w-auto" style="right: -65px;"><img src="assets/img/package/jamie-sitting.jpg" alt="About Image" style="height: 170px; width: 170px;"></div>-->
                        <div class="exp-box">
                            <span class="exp-number">20</span>
                            <p class="exp-title">Year Experience</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-xl-6 align-self-center offset-xl-1">
                    <div class="ps-xl-5">
                        <h2 class="sec-title">Hey there, I am Jamie!</h2>
                        <p class="fs-md mb-4 pb-2">Never a day do I regret my career choice. I grew up around hair. My mother owned a salon and I knew it was going to be my calling as well.</p>
                        <div class="row mb-4 pb-xl-2 gy-4">
                            <div class="col-sm-auto">
                                <div class="border-left-img">
                                <p class="mb-0 mt-n2">I have been professionally licensed since 2004 and every day since continued to love what I do.</p>
                                </div>
                            </div>
                            
                        </div>
                        <p>I truly believe this is one of the most rewarding and therapeutic industries to work in. The connection and relationships I build with my clients is life-changing. I can't wait to get into the salon and see what new things I learn about others and myself.</p>
                        <div class="d-flex gap-3 flex-wrap mt-4 pt-xl-4">
                            <a href="https://booksy.com/en-us/644713_refresh-hair-studio-chicago_hair-salon_18229_chicago/staffer/1077596#ba_s=sh_1" class="vs-btn">  Book with Jamie</a>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>





















        <!-- <div class="pattern-text-img text-center px-2 px-md-5" data-sec-pos="bottom-half" data-pos-for="#location-sec">
            <img src="assets/img/shape/shape-2-1-1.png" alt="Pattern Image">
        </div> -->
    <!--==============================
    Location Find Section
    ==============================-->
    <!-- <section class="location-find-wrapper bg-top-left bg-black space" data-bg-src="assets/img/bg/location-search-bg.jpg" id="location-sec">
        <div class="container mt-n1">
            <div class="row text-center text-md-start">
                <div class="offset-xl-1 col-xl-7">
                    <div class="row gx-xxl-0">
                        <div class="col-xl-10">
                            <h2 class="sec-title text-white">Find your nearest modern salon</h2>
                            <span class="sub-title text-white">Discover best in-class salons near you</span>
                        </div>
                        <div class="col-lg-8 col-xl-11 pt-2 pt-xl-4">
                            <form action="#" class="location-form">
                                <input type="text" class="form-control" placeholder="Enter a city, postal code">
                                <button type="submit" class="vs-btn"><i class="far fa-search"></i>Search</button>
                            </form>
                            <div class="mt-3 mt-xl-4 mb-n2">
                                <a href="find-salon.html" class="simple-link text-white"><i class="fal fa-location"></i>Geolocate Me</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    
    
     <!--==============================
  Subscribe Section
  ============================== -->
    <!-- <section class="subscribe-wrapper subscribe-layout1 position-relative space-top">-->
    <!--    <div class="subscribe-shape" data-bg-src="assets/img/shape/shape-2-1.jpg"></div>-->
    <!--    <div class="container">-->
    <!--        <div class="row text-center text-lg-start justify-content-center justify-content-lg-start">-->
                <!--<div class="col-lg-6 col-xl-6 mb-30 mb-lg-0">-->
                <!--    <div class="position-relative">-->
                <!--        <img src="assets/img/about/subscribe.webp" alt="Subscribe Image">-->
                <!--        <a href="assets\img/about.mp4" class="popup-video play-btn position-center"><i class="fas fa-play"></i></a>-->
                <!--    </div>-->
                <!--</div>-->
    <!--            <div class="col-lg-12 col-xl-12 ">-->
    <!--                <div class="row">-->
    <!--                    <div class="col-xl-10 offset-xl-1">-->
    <!--                        <div class="ms-xl-1 text-center">-->
    <!--                            <h2 class="sec-title text-white">Subscribe today <span class="font-subtitle fw-normal">Get 10% Off</span></h2>-->
    <!--                            <p class=" text-white">Join our newsletter and be the first to hear about exclusive promotions and product sales.</p>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                    <div class="col-xl-8 offset-xl-2">-->
    <!--                        <form action="code.php" class="subscribe-box ms-xl-1 mt-40" method="POST">-->
    <!--                            <input type="email" name="email" class="form-control" placeholder="Enter your email address" autocomplete="off" required>-->
    <!--                            <button type="submit" name="subscriber" class="submit-btn">-->
    <!--                                <span class="hidden"><i class="far fa-arrow-right"></i></span>-->
    <!--                                <span class="default"><i class="fas fa-envelope"></i></span>-->
    <!--                            </button>-->
    <!--                        </form>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</section> -->
     
    
    
    
    
    
    
    
    
<!--   
    <section class="position-relative space">
        <div class="about-shape1 d-none d-xxxl-block"><img src="assets/img/about/shape-4-1.png" alt="Shape"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-xl-5 mb-30 mb-lg-0">
                    <div class="image-box4">
                        <div class="img-1"><img src="assets/img/package/packages-1.jpeg" alt="About Image"></div>
                        <div class="img-2"><img src="assets/img/package/packages.jpeg" alt="About Image" class="w-100"></div>
                        <div class="exp-box">
                            <span class="exp-number">25</span>
                            <p class="exp-title">Years Experience</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-xl-6 align-self-center offset-xl-1">
                    <div class="ps-xl-5">
                        <h2 class="sec-title">Hey there, I am Jamie!</h2>
                        <p class="fs-md mb-4 pb-2">Never a day do I regret my career choice. I grew up around hair. My mother owned a salon and I knew it was going to be my calling as well.</p>
                        <div class="row mb-4 pb-xl-2 gy-4">
                            <div class="col-sm-auto">
                                <div class="border-left-img">
                                <p class="mb-0 mt-n2"> I have been professionally licensed since 2008 and every day since continued to love what I do. </p>
                                </div>
                            </div>
                            
                        </div>
                        <p>I truly believe this is one of the most rewarding and therapeutic industries to work in. The connection and relationships I build with my clients is life-changing. I can't wait to get into the salon and see what new things I learn about others and myself.</p>
                        <div class="d-flex gap-3 flex-wrap mt-4 pt-xl-4">
                            <a href="#" class="vs-btn"> BOOK NOW</a>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->

    
    
        
    <section class="space-top space-extra-bottom insta-desktop">
        <div class="title-area text-center wow fadeInUp" data-wow-delay="0.2s">
            <h2 class="sec-title">Follow Us on Instagram</h2>
            <div class="sec-shape mb-5 pb-1"><img src="assets/img/shape/sec-shape-1.png" alt="shape"></div>
        </div>
        <div class="container">
            <div class="d-flex justify-content-center">
                <a href="https://www.instagram.com/refreshwithjamie/" target="_blank" class="insta-link"
                    title="Follow Us">
                    <p>Refresh With Jamie</p>
                </a>
            </div>
            <div class="row flex-row-reverse gx-55">

                <div class="row  space-bottom-new">
                    <div class="col-lg-3 col-md-4 col-sm-6 my-4">
                        <div class="card">
                            <div class="card-video">
                                <video muted>
                                    <source src="assets/videos/video1.mp4" type="video/mp4">
                                    Your browser does not support the video tag.
                                </video>
                            </div>
                            <div class="card-body px-4">
                                <p class="insta-text">
                                    Ugh I didn’t take a before picture and I’m kick...
                                </p>
                                <div class="date-icon">
                                    <i class="fab fa-instagram"></i>
                                    <span class="date">February 11, 2024</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6 my-4">
                        <div class="card">
                            <div class="card-video">
                                <video muted>
                                    <source src="assets/videos/video2.mp4" type="video/mp4">
                                    Your browser does not support the video tag.
                                </video>
                            </div>
                            <div class="card-body px-4">
                                <p class="insta-text">
                                    I meet so many incredible people!! I can’t even...
                                </p>
                                <div class="date-icon">
                                    <i class="fab fa-instagram"></i>
                                    <span class="date">February 08, 2024</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                    
                    <div class="col-lg-3 col-md-4 col-sm-6 my-4">
                        <div class="card">
                            <div class="card-video">
                                <video muted>
                                    <source src="assets/videos/video3.mp4" type="video/mp4">
                                    Your browser does not support the video tag.
                                </video>
                            </div>
                            <div class="card-body px-4">
                                <p class="insta-text">
                                    I don’t know how to be anything other than me!!...
                                </p>
                                <div class="date-icon">
                                    <i class="fab fa-instagram"></i>
                                    <span class="date">February 03, 2024</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6 my-4">
                        <div class="card">
                            <div class="card-video">
                                <video muted>
                                    <source src="assets/videos/video4.mp4" type="video/mp4">
                                    Your browser does not support the video tag.
                                </video>
                            </div>
                            <div class="card-body px-4">
                                <p class="insta-text ">
                                    Met the most amazing and inspiring woman today!...
                                </p>
                                <div class="date-icon">
                                    <i class="fab fa-instagram"></i>
                                    <span class="date">February 03, 2024</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-4 col-sm-6 my-4">
                        <div class="card">
                            <div class="card-video">
                                <video muted>
                                    <source src="assets/videos/video6.mp4" type="video/mp4">
                                    Your browser does not support the video tag.
                                </video>
                            </div>
                            <div class="card-body px-4">
                                <p class="insta-text ">
                                    By by blonde! It’s been great knowing you! 2 an...
                                </p>
                                <div class="date-icon">
                                    <i class="fab fa-instagram"></i>
                                    <span class="date">December 03, 2023</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6 my-4">
                        <div class="card">
                            <div class="card-video">
                                <video muted>
                                    <source src="assets/videos/video5.mp4" type="video/mp4">
                                    Your browser does not support the video tag.
                                </video>
                            </div>
                            <div class="card-body px-4">
                                <p class="insta-text ">
                                    I love watching Cayla in action! #simplythebest...
                                </p>
                                <div class="date-icon">
                                    <i class="fab fa-instagram"></i>
                                    <span class="date">February 02, 2024</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6 my-4">
                        <div class="card">
                            <div class="card-video">
                                <video muted>
                                    <source src="assets/videos/video8.mp4" type="video/mp4">
                                    Your browser does not support the video tag.
                                </video>
                            </div>
                            <div class="card-body px-4">
                                <p class="insta-text ">
                                    It had been one year since I last saw her! I ad...
                                </p>
                                <div class="date-icon">
                                    <i class="fab fa-instagram"></i>
                                    <span class="date">November 01, 2023</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6 my-4">
                        <div class="card">
                            <div class="card-video">
                                <video muted>
                                    <source src="assets/videos/video7.mp4" type="video/mp4">
                                    Your browser does not support the video tag.
                                </video>
                            </div>
                            <div class="card-body px-4">
                                <p class="insta-text ">
                                    Lived in color transformation. #transform

                                </p>
                                <div class="date-icon">
                                    <i class="fab fa-instagram"></i>
                                    <span class="date">February 03, 2024</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <!-- </div> -->
            </div>
        </div>
    </section>


    
    
    
    
    
    
    
    
    
    <!--==============================
  team Area
  ============================== -->
    <section class="vs-team-wrapper space-top space-bottom">
        <div class="container">
            <div class="title-area text-center">
                <!--<div class="sec-icon"><img src="assets/img/icon/sec-icon.png" alt="Section Title"></div>-->
                <span class="sub-title">Gallery</span>
                <h2 class="sec-title text-uppercase"> Our Gallery</h2>
            </div>
            
            
            
            
                <div class="row g-3 filter-active">
                <div class="col-md-6 col-lg-4 filter-item">
                    <div class="vs-gallery-box">
                        <div class="gallery-img">
                            <img src="assets/img/gallery/gal-2-1.jpg" alt="Image" class="w-100">
                        </div>
                        <div class="gallery-content">
                            <h3 class="gallery-title"><a href="#" class="text-reset">Classic Color</a></h3>
                            <a href="assets/img/gallery/gal-2-1.jpg" class="icon-btn style-outline popup-image"><i class="fas fa-plus"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 filter-item">
                    <div class="vs-gallery-box">
                        <div class="gallery-img">
                            <img src="assets/img/gallery/gal-2-2.jpg" alt="Image" class="w-100">
                        </div>
                        <div class="gallery-content">
                            <h3 class="gallery-title"><a href="#" class="text-reset">Shine Color</a></h3>
                            <a href="assets/img/gallery/gal-2-2.jpg" class="icon-btn style-outline popup-image"><i class="fas fa-plus"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 filter-item">
                    <div class="vs-gallery-box">
                        <div class="gallery-img">
                            <img src="assets/img/gallery/gal-2-3.jpg" alt="Image" class="w-100">
                        </div>
                        <div class="gallery-content">
                            <h3 class="gallery-title"><a href="#" class="text-reset">Hair Cut</a></h3>
                            <a href="assets/img/gallery/gal-2-3.jpg" class="icon-btn style-outline popup-image"><i class="fas fa-plus"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 filter-item">
                    <div class="vs-gallery-box">
                        <div class="gallery-img">
                            <img src="assets/img/gallery/gal-2-4.jpg" alt="Image" class="w-100">
                        </div>
                        <div class="gallery-content">
                            <h3 class="gallery-title"><a href="#" class="text-reset">Actor Color</a></h3>
                            <a href="assets/img/gallery/gal-2-4.jpg" class="icon-btn style-outline popup-image"><i class="fas fa-plus"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 filter-item">
                    <div class="vs-gallery-box">
                        <div class="gallery-img">
                            <img src="assets/img/gallery/gal-2-5.jpg" alt="Image" class="w-100">
                        </div>
                        <div class="gallery-content">
                            <h3 class="gallery-title"><a href="#" class="text-reset">Hair Color</a></h3>
                            <a href="assets/img/gallery/gal-2-5.jpg" class="icon-btn style-outline popup-image"><i class="fas fa-plus"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 filter-item">
                    <div class="vs-gallery-box">
                        <div class="gallery-img">
                            <img src="assets/img/gallery/gal-2-6.jpg" alt="Image" class="w-100">
                        </div>
                        <div class="gallery-content">
                            <h3 class="gallery-title"><a href="#" class="text-reset">Hair Color</a></h3>
                            <a href="assets/img/gallery/gal-2-6.jpg" class="icon-btn style-outline popup-image"><i class="fas fa-plus"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 filter-item">
                    <div class="vs-gallery-box">
                        <div class="gallery-img">
                            <img src="assets/img/gallery/gal-2-7.jpg" alt="Image" class="w-100">
                        </div>
                        <div class="gallery-content">
                            <h3 class="gallery-title"><a href="#" class="text-reset">Hair Color</a></h3>
                            <a href="assets/img/gallery/gal-2-7.jpg" class="icon-btn style-outline popup-image"><i class="fas fa-plus"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 filter-item">
                    <div class="vs-gallery-box">
                        <div class="gallery-img">
                            <img src="assets/img/gallery/gal-2-8.jpg" alt="Image" class="w-100">
                        </div>
                        <div class="gallery-content">
                            <h3 class="gallery-title"><a href="#" class="text-reset">Hair Color</a></h3>
                            <a href="assets/img/gallery/gal-2-8.jpg" class="icon-btn style-outline popup-image"><i class="fas fa-plus"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            <!--<div class="row">-->
            <!--    <div class="col-sm-6 col-lg-4 team-grid mb-30">-->
            <!--        <div class="team-img">-->
            <!--            <img src="assets/img/team/member-1-1.jpg" alt="team Image" class="w-100">-->
            <!--        </div>-->
            <!--        <div class="team-content">-->
            <!--            <h3 class="team-name"><a class="text-inherit" href="team-details.html">Lisa Malliq</a></h3>-->
            <!--            <p class="team-degi">Beauty therapist</p>-->
            <!--            <span class="team-number"><i class="fal fa-phone-alt"></i> <a href="tel:02073885619">020 7388 5619</a></span>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--    <div class="col-sm-6 col-lg-4 team-grid mb-30">-->
            <!--        <div class="team-img">-->
            <!--            <img src="assets/img/team/member-1-2.jpg" alt="team Image" class="w-100">-->
            <!--        </div>-->
            <!--        <div class="team-content">-->
            <!--            <h3 class="team-name"><a class="text-inherit" href="team-details.html">Ellie Chloe</a></h3>-->
            <!--            <p class="team-degi">Therapist</p>-->
            <!--            <span class="team-number"><i class="fal fa-phone-alt"></i> <a href="tel:02073885619">020 7388 5619</a></span>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--    <div class="col-sm-6 col-lg-4 team-grid mb-30">-->
            <!--        <div class="team-img">-->
            <!--            <img src="assets/img/team/member-1-3.jpg" alt="team Image" class="w-100">-->
            <!--        </div>-->
            <!--        <div class="team-content">-->
            <!--            <h3 class="team-name"><a class="text-inherit" href="team-details.html">Jessica Lucy</a></h3>-->
            <!--            <p class="team-degi">Beautician</p>-->
            <!--            <span class="team-number"><i class="fal fa-phone-alt"></i> <a href="tel:02073885619">020 7388 5619</a></span>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--    <div class="col-sm-6 col-lg-4 team-grid mb-30">-->
            <!--        <div class="team-img">-->
            <!--            <img src="assets/img/team/member-1-4.jpg" alt="team Image" class="w-100">-->
            <!--        </div>-->
            <!--        <div class="team-content">-->
            <!--            <h3 class="team-name"><a class="text-inherit" href="team-details.html">Hannah Katie</a></h3>-->
            <!--            <p class="team-degi">Worker</p>-->
            <!--            <span class="team-number"><i class="fal fa-phone-alt"></i> <a href="tel:02073885619">020 7388 5619</a></span>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--    <div class="col-sm-6 col-lg-4 team-grid mb-30">-->
            <!--        <div class="team-img">-->
            <!--            <img src="assets/img/team/member-1-5.jpg" alt="team Image" class="w-100">-->
            <!--        </div>-->
            <!--        <div class="team-content">-->
            <!--            <h3 class="team-name"><a class="text-inherit" href="team-details.html">Grace Mia</a></h3>-->
            <!--            <p class="team-degi">CEO, Director</p>-->
            <!--            <span class="team-number"><i class="fal fa-phone-alt"></i> <a href="tel:02073885619">020 7388 5619</a></span>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--    <div class="col-sm-6 col-lg-4 team-grid mb-30">-->
            <!--        <div class="team-img">-->
            <!--            <img src="assets/img/team/member-1-6.jpg" alt="team Image" class="w-100">-->
            <!--        </div>-->
            <!--        <div class="team-content">-->
            <!--            <h3 class="team-name"><a class="text-inherit" href="team-details.html">Abigail Jack</a></h3>-->
            <!--            <p class="team-degi">Therapist</p>-->
            <!--            <span class="team-number"><i class="fal fa-phone-alt"></i> <a href="tel:02073885619">020 7388 5619</a></span>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--</div>-->
        </div>
    </section>
    <!--==============================
  Testimonial Area
  ============================== -->
    <section class="vs-testimonial-wrapper space-bottom space-top">
        <div class="container position-relative">
            <!--<div class="avater-fly vs-carousel d-none d-lg-block" id="avaterfly" data-asnavfor="#testimonialslide1" data-slide-show="5" data-centermode="true" data-variable-width="true">-->
            <!--    <div class="avater">-->
            <!--        <img src="assets/img/avater/avater-1-1.png" alt="Testimonial Image">-->
            <!--    </div>-->
            <!--    <div class="avater">-->
            <!--        <img src="assets/img/avater/avater-1-3.png" alt="Testimonial Image">-->
            <!--    </div>-->
            <!--    <div class="avater">-->
                    <!--<img src="assets/img/avater/avater-1-2.png" alt="Testimonial Image">-->
            <!--    </div>-->
            <!--    <div class="avater">-->
            <!--        <img src="assets/img/avater/avater-1-5.png" alt="Testimonial Image">-->
            <!--    </div>-->
            <!--    <div class="avater">-->
            <!--        <img src="assets/img/avater/avater-1-4.png" alt="Testimonial Image">-->
            <!--    </div>-->
            <!--</div>-->

            
            <div class="row justify-content-center">
            
            <?php
                include_once 'google-reviews.php';
            ?>

            
                <div class="col-lg-9 col-xl-7">
              
                    <div class="vs-carousel" id="testimonialslide1" data-asnavfor="#avaterfly" data-fade="true" data-slide-show="1" data-md-slide-show="1">
                    


                        <!-- <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>Jamie does a n amazing job every time I see her She is always cautious and listens attentively to what the client wants. She is always honest and does not tryto sell you into doing more than what you asked for and will not lie if she believes what you are asking for might not work. I will not go to anyone else. She is extremely knowledgeable, honest, caring and personable. And she will go out of her way to make sure you ae comfortable during your styling and happy with your end results, Jamie is truly one of the very best</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Amy Jo</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div>
                        <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>I've been getting my short hair/pixie cut done by Jamie for years and she never disappoints! Jamie's amazing at both cutting and coloring hair and is super friendly, as well. Before Jamie, I went to a bunch of places in Chicago and could never really find the perfect pixie cut but she really gets it. Thank you Jamie!!!</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Katie F</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div>
                        <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>Absolutely stunning results, hair has dimension, shine, and feels amazing. Jaime is an absolute joy to spend time with and makes the experience feel so personal yet luxurious. 5 stars isn't enough!!!</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Kellie E</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div>
                        <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>I had such a great experience at Jamie's salon! She is down to earth and super friendly, and absolutely love the color and cut she gave me!</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Rachel</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div>
                        <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>Jamie is hands down the best. For years she's been the only one I've let do my hair. She always seems to understand what I want and what would work best for my hair. She's a consummate professional and an incredibly kind and friendly human to boot. Cannot recommend her enough1</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Esther S</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div> -->

                    </div>
                </div>

            </div>
            
        </div>
    </section>
    <!--==============================
    Packages Area
    ==============================-->
    <section class="vs-packages-wrapper packages-layout1 space" data-bg-src="assets/img/bg/package-bg.jpg">
        <div class="container">
            <div class="row gx-60">
                <div class="col-lg-5 align-self-center">
                    <div class="d-flex flex-column align-items-center d-lg-block">
                        <div class="order-1 order-lg-1">
                            <div class="title-area mb-2 mb-lg-3 pb-lg-2 text-center text-lg-start">
                                <span class="sub-title">Meet Our Stylists</span>
                                <h2 class="sec-title">Our stylists Get Your Hair On</h2>
                            </div>
                        </div>
                        <div class="order-3 w-100 order-lg-2">
                            <div class="row gx-2 vs-carousel" data-slide-show="3" data-md-slide-show="4" data-sm-slide-show="3" data-xs-slide-show="2" data-center-mode="true" data-xl-center-mode="true" data-ml-center-mode="true" data-lg-center-mode="true" data-md-center-mode="true" data-sm-center-mode="true" id="packSlide1" data-asnavfor="#packSlide2">
                                <div class="col-xl-auto">
                                    <div class="package-thumb">
                                        <span class="thumb-icon"><i class="fas fa-plus"></i></span>
                                        <img src="assets/img/package/packages-2.jpeg" class="w-100" alt="Hair Style">
                                    </div>
                                </div>
                                <div class="col-xl-auto">
                                    <div class="package-thumb">
                                        <span class="thumb-icon"><i class="fas fa-plus"></i></span>
                                        <img src="assets/img/package/packages-1.jpeg" class="w-100" alt="Hair Style">
                                    </div>
                                </div>
                                <div class="col-xl-auto">
                                    <div class="package-thumb">
                                        <span class="thumb-icon"><i class="fas fa-plus"></i></span>
                                        <img src="assets/img/package/packages-2.jpeg" class="w-100" alt="Hair Style">
                                    </div>
                                </div>
                                <div class="col-xl-auto">
                                    <div class="package-thumb">
                                        <span class="thumb-icon"><i class="fas fa-plus"></i></span>
                                        <img src="assets/img/package/packages-1.jpeg" class="w-100" alt="Hair Style">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="order-2 order-lg-3">
                            <div class="text-uppercase fw-semibold text-title mb-4 mb-lg-0 mt-lg-4 mt-xl-5 mb-n2">
                                <a href="#" class="text-inherit mb-n2">Find Our More <i class="fas fa-chevron-right ms-2"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-7 mt-30 mt-lg-0">
                    <div class="package-banner vs-carousel" data-slide-show="1" data-md-slide-show="1" data-fade="true" id="packSlide2" data-asnavfor="#packSlide1">

                        <div class="package-banner-big">
                            <img src="assets/img/package/packages-2.jpeg" alt="big image" class="w-100">
                            <div class="offer-pill-2">
                                <span class="price-label">from only</span>
                                <div class="price">$60.00</div>
                            </div>
                        </div>

                        <div class="package-banner-big">
                            <img src="assets/img/package/packages-1.jpeg" alt="big image" class="w-100">
                            <div class="offer-pill-2">
                                <span class="price-label">from only</span>
                                <div class="price">$60.00</div>
                            </div>
                        </div>

                        <div class="package-banner-big">
                            <img src="assets/img/package/packages-2.jpeg" alt="big image" class="w-100">
                            <div class="offer-pill-2">
                                <span class="price-label">from only</span>
                                <div class="price">$60.00</div>
                            </div>
                        </div>

                        <div class="package-banner-big">
                            <img src="assets/img/package/packages-1.jpeg" alt="big image" class="w-100">
                            <div class="offer-pill-2">
                                <span class="price-label">from only</span>
                                <div class="price">$60.00</div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>





    <!--==============================
    Blog Area
    ==============================-->
    <!--<section class="vs-blog-wrapper space-negative-bottom">-->
    <!--    <div class="container">-->
    <!--        <div class="title-area text-center">-->
                <!--<div class="sec-icon"><img src="assets/img/icon/sec-icon.png" alt="Section Title"></div>-->
    <!--            <span class="sub-title">Articles & News</span>-->
    <!--            <h2 class="sec-title text-uppercase">Tips for Hair</h2>-->
    <!--        </div>-->
    <!--        <div class="row vs-carousel" data-slide-show="3">-->

    <!--            <div class="col-xl-4">-->
    <!--                <div class="vs-blog blog-card">-->
    <!--                    <div class="blog-img">-->
    <!--                        <img src="assets/img/blog/blog-1-1.jpg" alt="Blog Image" class="w-100">-->
    <!--                        <div class="meta-box">-->
    <!--                            <a href="#"><i class="far fa-calendar-alt"></i>Dec 12, 2022</a>-->
    <!--                            <a href="#"><i class="fas fa-comment-alt"></i>21</a>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                    <div class="blog-content">-->
    <!--                        <h3 class="blog-title"><a href="#">We’re pledging, and you can too!</a></h3>-->
    <!--                        <p class="blog-text">Alienum phaedrum torquatos nec eu, vis is in mei. Mei an periculaeuripidis, hincart drum torquatos nec eu, vis detraxit.</p>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->

    <!--            <div class="col-xl-4">-->
    <!--                <div class="vs-blog blog-card">-->
    <!--                    <div class="blog-img">-->
    <!--                        <img src="assets/img/blog/blog-1-2.jpg" alt="Blog Image" class="w-100">-->
    <!--                        <div class="meta-box">-->
    <!--                            <a href="#"><i class="far fa-calendar-alt"></i>Feb 30, 2022</a>-->
    <!--                            <a href="#"><i class="fas fa-comment-alt"></i>36</a>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                    <div class="blog-content">-->
    <!--                        <h3 class="blog-title"><a href="#">Until recently, the prevail view</a></h3>-->
    <!--                        <p class="blog-text">Alienum phaedrum torquatos nec eu, vis is in mei. Mei an periculaeuripidis, hincart drum torquatos nec eu, vis detraxit.</p>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->

    <!--            <div class="col-xl-4">-->
    <!--                <div class="vs-blog blog-card">-->
    <!--                    <div class="blog-img">-->
    <!--                        <img src="assets/img/blog/blog-1-3.jpg" alt="Blog Image" class="w-100">-->
    <!--                        <div class="meta-box">-->
    <!--                            <a href="#"><i class="far fa-calendar-alt"></i>Mar 31, 2022</a>-->
    <!--                            <a href="#"><i class="fas fa-comment-alt"></i>89</a>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                    <div class="blog-content">-->
    <!--                        <h3 class="blog-title"><a href="#">The placeholder text, beginn with</a></h3>-->
    <!--                        <p class="blog-text">Alienum phaedrum torquatos nec eu, vis is in mei. Mei an periculaeuripidis, hincart drum torquatos nec eu, vis detraxit.</p>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->

    <!--            <div class="col-xl-4">-->
    <!--                <div class="vs-blog blog-card">-->
    <!--                    <div class="blog-img">-->
    <!--                        <img src="assets/img/blog/blog-1-4.jpg" alt="Blog Image" class="w-100">-->
    <!--                        <div class="meta-box">-->
    <!--                            <a href="#"><i class="far fa-calendar-alt"></i>Aug 26, 2022</a>-->
    <!--                            <a href="#"><i class="fas fa-comment-alt"></i>28</a>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                    <div class="blog-content">-->
    <!--                        <h3 class="blog-title"><a href="#">Richard McClintock, a Latin scholar!</a></h3>-->
    <!--                        <p class="blog-text">Alienum phaedrum torquatos nec eu, vis is in mei. Mei an periculaeuripidis, hincart drum torquatos nec eu, vis detraxit.</p>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->

    <!--        </div>-->
            
    <!--    </div>-->
        
    <!--</section>-->
    
    
    
    <section class="space-top space-extra-bottom insta-mobile">
        <div class="title-area text-center wow fadeInUp" data-wow-delay="0.2s">
            <h2 class="sec-title">Follow Us on Instagram</h2>
            <div class="sec-shape mb-5 pb-1"><img src="assets/img/shape/sec-shape-1.png" alt="shape"></div>
        </div>
        <div class="container">
            <div class="d-flex justify-content-center">
                <a href="https://www.instagram.com/refreshwithjamie/" target="_blank" class="insta-link"
                    title="Follow Us">
                    <p>Refresh With Jamie</p>
                </a>
            </div>
            <div class="row flex-row-reverse gx-55">

                <div class="row  space-bottom-new">
                    <div class="col-lg-3 col-md-4 col-sm-6 my-4">
                        <div class="card">
                            <div class="card-video">
                                <video muted>
                                    <source src="assets/videos/video1.mp4" type="video/mp4">
                                    Your browser does not support the video tag.
                                </video>
                            </div>
                            <div class="card-body px-4">
                                <p class="insta-text">
                                    Ugh I didn’t take a before picture and I’m kick...
                                </p>
                                <div class="date-icon">
                                    <i class="fab fa-instagram"></i>
                                    <span class="date">February 11, 2024</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-6 my-4">
                        <div class="card">
                            <div class="card-video">
                                <video muted>
                                    <source src="assets/videos/video2.mp4" type="video/mp4">
                                    Your browser does not support the video tag.
                                </video>
                            </div>
                            <div class="card-body px-4">
                                <p class="insta-text">
                                    I meet so many incredible people!! I can’t even...
                                </p>
                                <div class="date-icon">
                                    <i class="fab fa-instagram"></i>
                                    <span class="date">February 08, 2024</span>
                                </div>
                            </div>
                        </div>
                    </div>
                
                </div>


                <!-- </div> -->
            </div>
        </div>
    </section>



    <!--==============================
    Brand Area
    ==============================-->
    <!-- <section class="vs-brand-wrapper space-bottom">
        <div class="container">
            <div class="title-area text-center">
                <div class="sec-icon"><img src="assets/img/icon/sec-icon.png" alt="Section Title"></div><span class="sub-title">Partners Sponsers & Brands</span>
                <h2 class="sec-title text-uppercase">WINNERS and Finalists</h2>
            </div>
            <div class="row vs-carousel text-center" data-slide-show="5" data-md-slide-show="3" data-sm-slide-show="3" data-xs-slide-show="2">
                <div class="col-auto">
                    <div class="brand-img">
                        <img src="assets/img/brand/brand-1-1.png" alt="Brand image">
                    </div>
                </div>
                <div class="col-auto">
                    <div class="brand-img">
                        <img src="assets/img/brand/brand-1-2.png" alt="Brand image">
                    </div>
                </div>
                <div class="col-auto">
                    <div class="brand-img">
                        <img src="assets/img/brand/brand-1-3.png" alt="Brand image">
                    </div>
                </div>
                <div class="col-auto">
                    <div class="brand-img">
                        <img src="assets/img/brand/brand-1-4.png" alt="Brand image">
                    </div>
                </div>
                <div class="col-auto">
                    <div class="brand-img">
                        <img src="assets/img/brand/brand-1-5.png" alt="Brand image">
                    </div>
                </div>
                <div class="col-auto">
                    <div class="brand-img">
                        <img src="assets/img/brand/brand-1-1.png" alt="Brand image">
                    </div>
                </div>
                <div class="col-auto">
                    <div class="brand-img">
                        <img src="assets/img/brand/brand-1-2.png" alt="Brand image">
                    </div>
                </div>
                <div class="col-auto">
                    <div class="brand-img">
                        <img src="assets/img/brand/brand-1-3.png" alt="Brand image">
                    </div>
                </div>
                <div class="col-auto">
                    <div class="brand-img">
                        <img src="assets/img/brand/brand-1-4.png" alt="Brand image">
                    </div>
                </div>
                <div class="col-auto">
                    <div class="brand-img">
                        <img src="assets/img/brand/brand-1-5.png" alt="Brand image">
                    </div>
                </div>
            </div>
        </div>
    </section> -->
  <?php include'footer.php'?>
</body>

</html>