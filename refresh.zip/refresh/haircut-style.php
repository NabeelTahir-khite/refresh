<!doctype html>
<html class="no-js" lang="zxx">
     <!-- Favicons - Place favicon.ico in the root directory -->
    <link rel="icon" type="image/png" size="16x16" href="assets/img/logo-1.png">
    <!-- <link rel="manifest" href="assets/img/favicons/manifest.json"> -->



<body>


    <?php include'header.php'?>
    <!--==============================
    Breadcumb
============================== -->
    <div class="breadcumb-wrapper " data-bg-src="assets/img/bg/banner16.jpg">
        <div class="container z-index-common">
            <div class="breadcumb-content text-center">
                <h1 class="breadcumb-title">Haircut and style</h1>
                <div class="breadcumb-menu-wrap">
                    <ul class="breadcumb-menu">
                        <li><a href="index.php">Home</a></li>
                        <li class="active">Haircut and style</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!--==============================
  Team Area
  ============================== -->
    <section class="vs-team-details space-top space-negative-bottom">
        <div class="container">
            <div class="row justify-content-around">
                <!--<div class="col-lg-6 mb-30">-->
                <!--    <div class="position-relative">-->
                <!--        <div class=" " data-mask-src="assets/img/shape/team-mask-2.png"></div>-->
                <!--        <div >-->
                <!--            <img src="assets/img/about/about-1-1.jpg" alt="member Image" class="w-100">-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <div class="col-lg-12 col-xl-12 mb-30 align-self-center">
                    <div class="team-details-content">
                        <h2 class="member-name h3 mb-0 fw-semibold">Unleash Your Hair's Potential with a Personalized Haircut at Refresh Hair Studio!</h2>
                        <span class="member-degi">A great haircut is more than just a trim – it's an investment in your confidence and overall style. At Refresh Hair Studio, we believe every head deserves a personalized haircut experience that flatters your features and complements your lifestyle.</span>
                        <div class="row mt-4 mt-xl-3">
                            <div class="col-sm-6 col-lg-6 col-xl-6 mb-20">
                                <h3 class="fw-semibold fs-22 mb-1 mb-lg-2">Your Vision, Our Expertise: </h3>
                                <p class="mb-0">Whether you're seeking a trendy new style, a classic cut with a modern twist, or a low-maintenance option, our skilled stylists will work closely with you to understand your vision and hair goals. We take the time to listen to your preferences, analyze your hair type and texture, and recommend styles that suit your face shape and personal style.</p>
                                 <br>
                                <a href="https://booksy.com/en-us/644713_refresh-hair-studio-chicago_hair-salon_18229_chicago/staffer/1077596#ba_s=sh_1" class="vs-btn mb-30"> BOOK NOW</a>
                                
                                
                            </div>
                            <div class="col-sm-6 col-lg-6 col-xl-6 mb-20">
                                <h3 class="fw-semibold fs-22 mb-1 mb-lg-2">The Art of Haircutting: </h3>
                                <p class="mb-0">Our stylists are not just scissor-wielders; they're hair artists. They possess a deep understanding of hairdressing techniques and use their skills to create a haircut that enhances your natural beauty and flatters your features. From precision cuts to textured styles, we offer a range of expertise to meet your needs.</p>
                                <br>
                                <a href="consultation.php" class="vs-btn mb-30"> CONSULT NOW</a>
                            </div>
                        </div>
                        <div class="vs-social style2 hover-black">
                            <h3 class="fw-semibold fs-22 mb-3">Follow On</h3>
                            <ul>
                                <li><a href="https://www.facebook.com/RefreshHairStudioChicago/?_rdr"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="https://goo.gl/maps/dWeauU3M7baxohVSA"><i class="fab fa-google-plus-g"></i></a></li>
                                <li><a href="https://www.instagram.com/refreshhairstudio/"><i class="fab fa-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="team-details-desc mt-4 pt-1">
                <h2 class="inner-title-style2">A Tailored Experience</h2>
                <p>No two haircuts are the same at Refresh Hair Studio. We believe in customizing every cut to your unique hair type and texture. Whether you have thick, curly hair, fine, straight locks, or something in between, our stylists have the expertise to create a haircut that complements your natural texture and enhances its manageability.</p>
                <h2 class="inner-title-style2">Long-Lasting Style</h2>
                <p>A great haircut should be more than just a one-day wonder. We take pride in creating haircuts that are designed to grow out beautifully. Our stylists will incorporate cutting techniques that ensure your style remains polished and manageable even as your hair grows.</p>
                <h2 class="inner-title-style2">Beyond the Cut</h2>
                <p>The haircut experience at Refresh Hair Studio doesn't stop at the final snip. We'll provide you with styling tips and product recommendations to help you maintain your new look at home. We want you to be able to recreate your salon style with ease and confidence.</p>
                
                <div class="row g-3 my-1 my-lg-3 my-xl-3 py-xl-3">
                    <div class="col-md-3">
                        <div class="image-scale-hover">
                            <img src="assets/img/about/image_0.jpeg" alt="About Image" class="w-100">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="image-scale-hover position-relative">
                            <img src="assets/img/about/449228677_382812621474695_6530253927529014784_n.jpg" alt="About Image" class="w-100">
                            <!--<a href="https://www.youtube.com/watch?v=_sI_Ps7JSEk" class="play-btn position-center popup-video"><i class="fas fa-play"></i></a>-->
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="image-scale-hover">
                            <img src="assets/img/about/about-4-3.jpg" alt="About Image" class="w-100">
                        </div>
                    </div>
                </div>
                <p class="mt-4 pt-2"><strong>Ready to experience the power of a personalized haircut?</strong> Schedule your appointment at Refresh Hair Studio today and let our stylists unleash the full potential of your hair!</p>
                <h2 class="inner-title-style2">PIXIE/CLIPPER CUT AND STYLE </h2>
                <p class="mt-4 pt-2">Unleash Your Inner Chic with a Pixie or Clipper Cut at Refresh Hair Studio! </p>
                <p class="mt-4 pt-2"><strong>Our custom Haircut $75-$90</strong></p>
                 <!--==============================
                            Testimonial Area
        ============================== -->
    <section class="vs-testimonial-wrapper space-bottom space-top">
        <div class="container position-relative">
            

            
            <div class="row justify-content-center">
           <?php
                include_once 'google-reviews.php';
            ?>
            
                <div class="col-lg-9 col-xl-7">
              
                    <div class="vs-carousel" id="testimonialslide1" data-asnavfor="#avaterfly" data-fade="true" data-slide-show="1" data-md-slide-show="1">
                    


                        <!-- <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>Jamie does a n amazing job every time I see her She is always cautious and listens attentively to what the client wants. She is always honest and does not tryto sell you into doing more than what you asked for and will not lie if she believes what you are asking for might not work. I will not go to anyone else. She is extremely knowledgeable, honest, caring and personable. And she will go out of her way to make sure you ae comfortable during your styling and happy with your end results, Jamie is truly one of the very best</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Amy Jo</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div>
                        <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>I've been getting my short hair/pixie cut done by Jamie for years and she never disappoints! Jamie's amazing at both cutting and coloring hair and is super friendly, as well. Before Jamie, I went to a bunch of places in Chicago and could never really find the perfect pixie cut but she really gets it. Thank you Jamie!!!</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Katie F</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div>
                        <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>Absolutely stunning results, hair has dimension, shine, and feels amazing. Jaime is an absolute joy to spend time with and makes the experience feel so personal yet luxurious. 5 stars isn't enough!!!</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Kellie E</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div>
                        <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>I had such a great experience at Jamie's salon! She is down to earth and super friendly, and absolutely love the color and cut she gave me!</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Rachel</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div>
                        <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>Jamie is hands down the best. For years she's been the only one I've let do my hair. She always seems to understand what I want and what would work best for my hair. She's a consummate professional and an incredibly kind and friendly human to boot. Cannot recommend her enough1</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Esther S</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div> -->

                    </div>
                </div>

            </div>
            
         </div>
        

               

            </div>
        </div>
    </section>
  <?php include'footer.php'?>


</body>

</html>