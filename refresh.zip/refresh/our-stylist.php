<!doctype html>
<html class="no-js" lang="zxx">

 <!-- Favicons - Place favicon.ico in the root directory -->
    <link rel="icon" type="image/png" size="16x16" href="assets/img/logo-1.png">
    <!-- <link rel="manifest" href="assets/img/favicons/manifest.json"> -->

<body>


    <?php include'header.php'?>
    <!--==============================
    Breadcumb
============================== -->
    <div class="breadcumb-wrapper " data-bg-src="assets/img/bg/banner18.jpg">
        <div class="container z-index-common">
            <div class="breadcumb-content text-center">
                <h1 class="breadcumb-title">About Us</h1>
                <div class="breadcumb-menu-wrap">
                    <ul class="breadcumb-menu">
                        <li><a href="index.html">Home</a></li>
                        <li class="active">About Us</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

 <!--==============================
  About Area
==============================-->


    <!--<section class="position-relative space">-->
    <!--    <div class="about-shape1 d-none d-xxxl-block"><img src="assets/img/about/shape-4-1.png" alt="Shape"></div>-->
    <!--    <div class="container">-->
    <!--        <div class="row">-->
    <!--            <div class="col-lg-6 col-xl-5 mb-30 mb-lg-0">-->
    <!--                <div class="image-box4">-->
    <!--                    <div class="img-1"><img src="assets/img/package/refresh-img.jpg" class="w-100" alt="About Image"></div>-->
    <!--                    <div class="img-2 w-auto" style="right: -65px;"><img src="assets/img/package/Refreshbw-177.jpg" alt="About Image" style="height: 170px; width: 170px;"></div>-->
    <!--                    <div class="exp-box">-->
    <!--                        <span class="exp-number">20</span>-->
    <!--                        <p class="exp-title">Years Experience</p>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-lg-6 col-xl-6 align-self-center offset-xl-1">-->
    <!--                <div class="ps-xl-5">-->
    <!--                    <h2 class="sec-title">Hey there, I am Jamie!</h2>-->
    <!--                    <p class="fs-md mb-4 pb-2">Never a day do I regret my career choice I grew up around here. My mother owned a salon and I knew it was going to be my calling as well. I’ve been professionally licensed since 2008 and every day since continued to love what I do. I truly believe this is one of the most rewarding and therapeutic industries to work in. The connection and relationships I build with my clients is life-changing. I can’t wait to get into the salon and see what new things I learn about others and myself. I am A Mom to an incredible 7 year old boy with big aspirations  He is my in vitro baby! My biggest most challenging yet rewarding job is parenting! It’s frickin hard yet couldn’t imagine my life any other way. He gives me the opportunity to be young again yet at the same time teaches me the way of the world today. For sure Bruh!! lol. They are so darn smart it’s scary.</p>-->
    <!--                    <div class="row mb-4 pb-xl-2 gy-4">-->
    <!--                        <div class="col-sm-auto">-->
    <!--                            <div class="border-left-img">-->
    <!--                            <p class="mb-0 mt-n2">I’m married to an Amazing  Mexican Man whom I’ve been with since 2006. He has been my inspiration and a pain in my ass that I love incredibly! I have to thank him for constantly encouraging me to work for myself, as he was right all along. This is where I was meant to be .</p>-->
    <!--                            </div>-->
    <!--                        </div>-->
                            
    <!--                    </div>-->
    <!--                    <p>We live in a small studio in Rogers Park with 3 cats! I ride a e-bike to work and hate the hot and humid weather yet don’t love the feeezing temperatures we can get here in Chicago. But I wouldn’t want to live anywhere else. Even though Im a bit of a homebody I love the convenience of everything I need so close. My biggest desire is to bring on a team of new stylists who need a place to grow and showcase their personalities! I absolutely love learning and being able to give everything I know into helping others grow. I am blessed. I won’t lie, non of this is easy and feels like 90% of my job now is marketing but I’m pulling up my big girl pants and diving in!!</p>-->
    <!--                    <div class="d-flex gap-3 flex-wrap mt-4 pt-xl-4">-->
    <!--                        <a href="consultation.php" class="vs-btn"> BOOK NOW</a>-->
                            
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</section>-->




<section class="position-relative space">
        <div class="about-shape1 d-none d-xxxl-block"><img src="assets/img/about/shape-4-1.png" alt="Shape"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-xl-5 mb-30 mb-lg-0">
                    <div class="image-box4">
                        <div class="img-1"><img src="assets/img/package/jamie-img.jpg" class="w-100" alt="About Image"></div>
                        <!--<div class="img-2"><img src="assets/img/package/jamie.jpg" alt="About Image" style="height: 200px;width: 200px;"></div>-->
                        <div class="exp-box">
                            <!--<span class="exp-number">20</span>-->
                            <p class="exp-title">Senior Stylist</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-xl-6 align-self-center offset-xl-1">
                    <div class="ps-xl-5">
                        <h2 class="sec-title">Hey there, I am Jamie!</h2>
                                            <p class="fs-md mb-4 pb-2">Never a day do I regret my career choice I grew up around here. My mother owned a salon and I knew it was going to be my calling as well. I’ve been professionally licensed since 2008 and every day since continued to love what I do. I truly believe this is one of the most rewarding and therapeutic industries to work in. The connection and relationships I build with my clients is life-changing. I can’t wait to get into the salon and see what new things I learn about others and myself. I am A Mom to an incredible 7 year old boy with big aspirations  He is my in vitro baby! My biggest most challenging yet rewarding job is parenting! It’s frickin hard yet couldn’t imagine my life any other way. He gives me the opportunity to be young again yet at the same time teaches me the way of the world today. For sure Bruh!! lol. They are so darn smart it’s scary.</p>
                        <div class="row mb-4 pb-xl-2 gy-4">
                            <div class="col-sm-auto">
                                <div class="border-left-img">
                                <p class="mb-0 mt-n2">I’m married to an Amazing  Mexican Man whom I’ve been with since 2006. He has been my inspiration and a pain in my ass that I love incredibly! I have to thank him for constantly encouraging me to work for myself, as he was right all along. This is where I was meant to be .</p>
                                </div>
                            </div>
                            
                        </div>
                        
                    </div>
                </div>
                
                        <p class="mt-3">We live in a small studio in Rogers Park with 3 cats! I ride a e-bike to work and hate the hot and humid weather yet don’t love the feeezing temperatures we can get here in Chicago. But I wouldn’t want to live anywhere else. Even though Im a bit of a homebody I love the convenience of everything I need so close. My biggest desire is to bring on a team of new stylists who need a place to grow and showcase their personalities! I absolutely love learning and being able to give everything I know into helping others grow. I am blessed. I won’t lie, non of this is easy and feels like 90% of my job now is marketing but I’m pulling up my big girl pants and diving in!!</p>
                        <div class="d-flex gap-3 flex-wrap pt-xl-4">
                            <a href="https://booksy.com/en-us/644713_refresh-hair-studio-chicago_hair-salon_18229_chicago/staffer/570040#ba_s=sh_1" target="blank"  class="vs-btn"> Book with Jamie</a>
                            
                        </div>
            </div>
            <!--<div class="about-space bg-smoke p-3 p-lg-5 mt-1">Here at Refresh Hair Studio, we are more than just a hair salon — a thriving group of hair stylists committed to giving our clients self-assurance and highlighting their inner beauty. Start your journey toward beauty with our knowledgeable staff, who will customize events to meet your goals for hair and beauty. Every time you visit Refresh Hair Studio, it's as though you have entered an oasis — a haven where you can express your inner and outer beauty-->
            <!--</div>-->
        </div>
    </section>




    
    <!--==============================
    About Area
    ==============================-->
    

    <!-- about 2 -->
    <section class="position-relative space">
        <div class="about-shape1 d-none d-xxxl-block"><img src="assets/img/about/shape-4-1.png" alt="Shape"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-xl-5 mb-30 mb-lg-0">
                    <div class="image-box4">
                        <div class="img-1"><img src="assets/img/package/cayla.jpg" alt="About Image"></div>
                        <div class="exp-box">
                            <!--<span class="exp-number">15</span>-->
                            <p class="exp-title">Junior Stylist</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-xl-6 align-self-center offset-xl-1">
                    <div class="ps-xl-5">
                        <h2 class="sec-title">Hiii! I'm Cayla!</h2>
                        <p class="fs-md mb-4 pb-2">I'm a second generation hairstylist and I absolutely love doing hair! Even though my mom is a hairstylist and I had a salon in my home my entire life, you would think this would have been the obvious career choice for me. But being a stubborn Taurus, I decided to go to college. 5 years and 3 majors later, I graduated with a bachelor's in computer science. Being a programming consultant after college took the LIFE OUT OF ME. I hated being stuck in an office at a desk not being creative at all. By year 5 I was so depressed and anxious and the money was not worth it in the slightest, that I bet on myself and quit to start a pet service company in 2019. When COVID hit the following year I was out of work for a bit, but I was able to rebuild and it was awesome! It wasn't until a friend of mine mentioned wanting to go to beauty school where I even had the idea to go. I thought it would be a good skill to learn and just do it on the side. I wasn't sure what to expect but I sure as hell wasn't expecting to love it as much as I do!</p>
                        <div class="row mb-4 pb-xl-2 gy-4">
                            <div class="col-sm-auto">
                                <div class="border-left-img">
                                <p class="mb-0 mt-n2">Some special interests of mine: cats, witchcraft, Mexican food, astrology, arts & crafts, sleeping, camping, pop music, horror movies, the fall of the patriarchy, mental health, and so much more...</p>
                                </div>
                            </div>
                            
                        </div>
                        <p>I don't know, I think I'm pretty cool and that you should come sit in my chair and hang out with me while I do my hair magic on you!
                        </p>
                        <div class="d-flex gap-3 flex-wrap mt-4 pt-xl-4">
                            <a href="https://booksy.com/en-us/644713_refresh-hair-studio-chicago_hair-salon_18229_chicago/staffer/1077596#ba_s=sh_1" target="blank" class="vs-btn"> Book with Cayla</a>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- about 2 end -->
    
    <!--==============================
    About Area
    ==============================-->
    <section class="vs-about-wrapper bg-dark space" data-overlay="black" data-opacity="5" data-bg-src="assets/img/bg/about-bg-3-11.jpg">
        <div class="container">
            <div class="row text-center text-lg-start  align-items-center justify-content-between flex-row-reverse">
                <div class="col-lg-6 col-xl-6 d-flex justify-content-center">
                    <div >
                        <img src="assets/img/about/Refresh-33.jpg" alt="ABout Image">
                    </div>
                </div>
                <div class="col-lg-6 col-xl-5">
                    <div class="about-content">
                        <span class="sub-title">Your Style Haven</span>
                        <div class="row justify-content-center">
                            <div class="col-lg-12 col-md-10 col-sm-9">
                                <h2 class="sec-title text-white">Enhance Your Beauty Experience</h2>
                            </div>
                            <div class="col-lg-12 col-md-9 col-sm-11">
                                <p class="text-white">We, at Refresh Hair Studio, are dedicated to lifelong learning and development on both a personal and professional level. Our staff is committed to lifelong learning and earning the highest achievements, which keeps us abreast of the most recent developments in cutting-edge hair extensions and contemporary coloring methods. We utilize premium hair care products to offer luxurious experience that ensures satisfaction.</p>
                            </div>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>










    <!--==============================
    Gallery Area
    ==============================-->
    <div class="vs-gallery-wrapper  ">
        <div class="container-fluid px-xxl-0 overflow-hidden">
            <div class="row gallery-cutted-slide">
                <div class="col-auto">
                    <div class="gallery-cutted gallery-thumb">
                        <a href="assets/img/gallery/411310489_17957806073703284_9181812347740530501_n.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                        <img src="assets/img/gallery/411310489_17957806073703284_9181812347740530501_n.jpg" alt="Gallery image" class="w-100">
                    </div>
                </div>
                <div class="col-auto">
                    <div class="gallery-cutted gallery-thumb">
                        <a href="assets/img/gallery/gallery-2.jpeg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                        <img src="assets/img/gallery/gallery-2.jpeg" alt="Gallery image" class="w-100">
                    </div>
                </div>
                <div class="col-auto">
                    <div class="gallery-cutted gallery-thumb">
                        <a href="assets/img/gallery/gallery-1.jpeg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                        <img src="assets/img/gallery/gallery-1.jpeg" alt="Gallery image" class="w-100">
                    </div>
                </div>
                <div class="col-auto">
                    <div class="gallery-cutted gallery-thumb">
                        <a href="assets/img/gallery/gallery-3.jpeg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                        <img src="assets/img/gallery/gallery-3.jpeg" alt="Gallery image" class="w-100">
                    </div>
                </div>
            </div>
            <div class="pt-40 d-flex justify-content-center gap-4">
                <button data-slick-prev=".gallery-cutted-slide" class="slick-arrow slick-prev default"><span class="long-arrow"></span></button>
                <button data-slick-next=".gallery-cutted-slide" class="slick-arrow slick-next default"><span class="long-arrow"></span></button>
            </div>
        </div>
    </div>
   
    
  
      <!--==============================
    Counter Area
    ==============================-->
    <!--<div class="vs-counter-wrapper space-negative bg-light">-->
    <!--    <div class="container">-->
    <!--        <div class="row">-->
    <!--            <div class="col-sm-6 col-lg-3">-->
    <!--                <div class="vs-counter style3 text-center">-->
    <!--                    <div class="counter-icon">-->
    <!--                        <img src="assets/img/icon/counter--1-1.png" alt="Counter icon">-->
    <!--                    </div>-->
    <!--                    <span class="counter-number">3116</span>-->
    <!--                    <p class="counter-text mb-0">Hair Treatments</p>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-sm-6 col-lg-3">-->
    <!--                <div class="vs-counter style3 text-center">-->
    <!--                    <div class="counter-icon">-->
    <!--                        <img src="assets/img/icon/counter--1-2.png" alt="Counter icon">-->
    <!--                    </div>-->
    <!--                    <span class="counter-number">200</span>-->
    <!--                    <p class="counter-text mb-0">Salon Products</p>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-sm-6 col-lg-3">-->
    <!--                <div class="vs-counter style3 text-center">-->
    <!--                    <div class="counter-icon">-->
    <!--                        <img src="assets/img/icon/counter--1-3.png" alt="Counter icon">-->
    <!--                    </div>-->
    <!--                    <span class="counter-number">350</span>-->
    <!--                    <p class="counter-text mb-0">Shades of colors</p>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-sm-6 col-lg-3">-->
    <!--                <div class="vs-counter style3 text-center">-->
    <!--                    <div class="counter-icon">-->
    <!--                        <img src="assets/img/icon/counter--1-4.png" alt="Counter icon">-->
    <!--                    </div>-->
    <!--                    <span class="counter-number">130k</span>-->
    <!--                    <p class="counter-text mb-0">Satisfied Customers</p>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
   
    <?php include'footer.php'?>

</body>

</html>