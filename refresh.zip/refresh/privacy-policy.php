<!doctype html>
<html class="no-js" lang="zxx">
     <!-- Favicons - Place favicon.ico in the root directory -->
    <link rel="icon" type="image/png" size="16x16" href="assets/img/logo-1.png">
    <!-- <link rel="manifest" href="assets/img/favicons/manifest.json"> -->



<body>


    <?php include'header.php'?>
    <!--==============================
    Breadcumb
============================== -->
    <div class="breadcumb-wrapper " data-bg-src="assets/img/bg/banner16.jpg">
        <div class="container z-index-common">
            <div class="breadcumb-content text-center">
                <h1 class="breadcumb-title">Privacy Policy</h1>
                <div class="breadcumb-menu-wrap">
                    <ul class="breadcumb-menu">
                        <li><a href="index.php">Home</a></li>
                        <li class="active">Privacy Policy</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!--==============================
  Team Area
  ============================== -->
    <section class="">
        <div class="container">
            <!--<div class="row justify-content-center text-center">-->
            <!--    <div class="col-md-11 col-lg-8 col-xl-6">-->
            <!--        <div class="title-area">-->
            <!--            <h2 class="sec-title">PRIVACY POLICY</h2>-->
            <!--        </div>-->
            <!--    </div>-->
            <!--</div>-->
            <div class="about-space bg-smoke p-3 p-lg-5 mt-1">
            <p>Appointment Courtesy and Our Cancellation Policy at Refresh Hair Studio
At Refresh Hair Studio, we strive to provide you with the best possible experience, from booking your appointment to the moment you walk out the door looking and feeling your best. To ensure a smooth schedule for both our stylists and valued clients, we kindly ask you to review our appointment courtesy policy.
</p>        
            <h3>Respecting Your Time and Ours</h3>
            <p class="pe-xl-5 mb-3">We understand that life can be unpredictable, and sometimes appointments need to be rescheduled. We kindly request that you provide us with at least 48 hours' notice if you need to cancel or reschedule your appointment. This allows us to adjust our schedule accordingly and offer the time slot to another client.</p>
            <h3>Cancellation Policy</h3>
             <p class="pe-xl-5 mb-3">Cancellations with 48 hours' notice or more: We appreciate your courtesy and will happily reschedule your appointment at your convenience. There is no charge for cancellations within this timeframe.</p>
             <p class="pe-xl-5 mb-3">Cancellations with less than 48 hours' notice:  In the event of a late cancellation (within 48 hours of your appointment), a cancellation fee of 50% of the booked service price will be applied.</p>
             <p class="pe-xl-5 mb-3">No-shows: Clients who miss their scheduled appointment entirely (no-shows) will be charged a cancellation fee of 50% of the booked service price.</p>
             <h3>Cancellation Policy</h3>
             <p class="pe-xl-5 mb-3">Our cancellation policy allows us to maintain a smooth operation and ensure stylists are utilized efficiently. It also helps us minimize lost revenue due to late cancellations and no-shows.</p>
             <h3>We Value Your Understanding</h3>
             <p class="pe-xl-5 mb-3">We appreciate your understanding and cooperation with our cancellation policy. By respecting our time and providing timely notice, you help us continue to offer the highest quality service to all our clients.</p>
             <h3>How to Cancel or Reschedule</h3>
             <p class="pe-xl-5 mb-3">To cancel or reschedule your appointment please reply to your confirmation email or sign into Booksy directly. The sooner you notify us, the easier it is for us to accommodate your request.</p>
             <p class="pe-xl-5 mb-3">Looking Forward to Seeing You!</p>
             <p class="pe-xl-5 mb-3">We appreciate your business and look forward to your next visit to Refresh Hair Studio!</p>
            </div>
        </div>
    </section>
  <?php include'footer.php'?>


</body>

</html>