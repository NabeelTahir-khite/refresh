<!doctype html>
<html class="no-js" lang="zxx">

 <!-- Favicons - Place favicon.ico in the root directory -->
    <link rel="icon" type="image/png" size="16x16" href="assets/img/logo-1.png">
    <!-- <link rel="manifest" href="assets/img/favicons/manifest.json"> -->

<body>

<?php include'header.php'?>
    <!--==============================
    Breadcumb
============================== -->
    <div class="breadcumb-wrapper " data-bg-src="assets/img/bg/4-01.jpg">
        <div class="container z-index-common">
            <div class="breadcumb-content text-center">
                <h1 class="breadcumb-title">Contact Us</h1>
                <div class="breadcumb-menu-wrap">
                    <ul class="breadcumb-menu">
                        <li><a href="index.html">Home</a></li>
                        <li class="active">Contact Us</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!--==============================
  Contact Area
  ==============================-->
    <section class="vs-contact-wrapper space-top space-negative-bottom">
        <div class="container">
            <div class="title-area text-center">
                <!--<div class="sec-icon"><img src="assets/img/icon/sec-icon.png" alt="Section Title"></div>-->
                <h2 class="sec-title mb-1">Get Your Next Look</h2>
                <p class="sec-desc">Contact us online, we’ll be in touch as soon as possible…</p>
            </div>
            <div class="row gx-30">
                <div class="col-lg-6 mb-30">
                    <form action="mail.php" method="POST" class="ajax-contact">
                        <div class="row gx-20">
                            <div class="form-group col-12">
                                <input type="text" class="form-control style3" name="name" id="name" placeholder="Your Name *" required>
                            </div>
                            <div class="form-group col-12">
                                <input type="email" class="form-control style3" name="email" id="email" placeholder="Your Email *" required>
                            </div>
                            <div class="form-group col-12">
                                <input type="number" class="form-control style3" name="number" id="number" placeholder="Phone No *" required>
                            </div>
                            <div class="form-group col-12">
                                <select name="subject" id="subject" class="form-select style3" required>
                                    <option value="" disabled selected hidden>Service *</option>
                                    <option value="hair Cut">Hair Cut</option>
                                    <option value="Hair clean">Hair Clean</option>
                                    <option value="Head Massage">Head Massage</option>
                                    <option value="Classic Style">Classic Style</option>
                                </select>
                            </div>
                            <div class="form-group col-12">
                                <textarea name="message" id="message" cols="30" rows="3" class="form-control style3" placeholder="Message *" required></textarea>
                            </div>
                            <div class="form-btn col-12">
                                <button class="vs-btn">Send Message</button>
                            </div>
                        </div>
                        <p class="form-messages mb-0 mt-3"></p>
                    </form>
                </div>
                <div class="col-lg-6 mb-30">
                    <div class="vs-info-table">
                        <table>
                            <tbody>
                                <tr>
                                    <td>City:</td>
                                    <td>Hair salon in Chicago, Illinois</td>
                                </tr>
                                <tr>
                                    <td>Address: </td>
                                    <td>2232 W Lawrence Ave, Chicago, IL 60625</td>
                                </tr>
                                <tr>
                                    <td>Phone:</td>
                                    <td><a href="tel:7738157576" class="text-reset d-inline">(773) 815-7576</a></td>
                                </tr>
                                <tr>
                                    <td>Email: </td>
                                    <td><a href="mailto:info@refreshhairstudiochicago.com" class="text-reset d-inline">info@refreshhairstudiochicago.com</a></td>
                                </tr>
                                <tr>
                                    <td>Opening Hours: </td>
                                    <td>Mon-Fri: 11am - 8pm
                                    <br>Sat: 10am - 7pm<br>
                                    Sun: closed</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--==============================
    Map Area
    ==============================-->
    <div class="vs-map-wrapper space-bottom">
        <div class="container">
            <div class="google-map ratio ratio-16x9">
                <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d11865.852183807368!2d-87.6855473!3d41.9688671!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x880fd3ce61e3e3ab%3A0xdb7fb436ba020951!2sRefresh%20Hair%20Studio%20Chicago!5e0!3m2!1sen!2sus!4v1719347064344!5m2!1sen!2sus" width="800" height="565" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
            </div>
        </div>
    </div>
     <!--==============================
  Testimonial Area
  ============================== -->
    <section class="vs-testimonial-wrapper space-bottom space-top">
        <div class="container position-relative">
            

            
            <div class="row justify-content-center">
               <?php
                include_once 'google-reviews.php';
            ?>
            
                <div class="col-lg-9 col-xl-7">
              
                    <div class="vs-carousel" id="testimonialslide1" data-asnavfor="#avaterfly" data-fade="true" data-slide-show="1" data-md-slide-show="1">
                    


                      
                    </div>
                </div>

            </div>
            
        </div>
    </section>
 <?php include'footer.php'?>


</body>

</html>