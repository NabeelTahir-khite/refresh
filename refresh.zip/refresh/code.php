<?php
    include'connection.php';
    
    
    if (isset($_POST['subscriber'])) {
         $email = $_POST['email'];

        // Prepare the SQL query to insert the email
        $sql = "INSERT INTO subscriber (email) VALUES (?)";
    
        // Prepare the statement
        if ($stmt = mysqli_prepare($conn, $sql)) {
            // Bind the email parameter to the statement
            mysqli_stmt_bind_param($stmt, "s", $email);
    
            // Execute the statement
            if (mysqli_stmt_execute($stmt)) {
                header('Location: index.php');
                exit();
            } else {
                echo "Error: " . mysqli_error($conn);
            }
    
            // Close the statement
            mysqli_stmt_close($stmt);
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    
        // Close the database connection
        mysqli_close($conn);
    }
    
    if (isset($_POST['appointment'])) {
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $phone = mysqli_real_escape_string($conn, $_POST['phone']);
        $subject = mysqli_real_escape_string($conn, $_POST['subject']);
        $pick_date = mysqli_real_escape_string($conn, $_POST['pick_date']);
        $pick_time = mysqli_real_escape_string($conn, $_POST['pick_time']);
    
        // Prepare the SQL query to insert the data
        $sql = "INSERT INTO appointment (name, email, phone, subject, pick_date, pick_time) VALUES (?, ?, ?, ?, ?, ?)";
    
        // Prepare the statement
        if ($stmt = mysqli_prepare($conn, $sql)) {
            // Bind the parameters to the statement
            mysqli_stmt_bind_param($stmt, "ssssss", $name, $email, $phone, $subject, $pick_date, $pick_time);
    
            // Execute the statement
            if (mysqli_stmt_execute($stmt)) {
                header('Location: index.php'); // Redirect after successful insertion
                exit();
            } else {
                echo "Error: " . mysqli_error($conn);
            }
    
            // Close the statement
            mysqli_stmt_close($stmt);
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    
        // Close the database connection
        mysqli_close($conn);
        
    }
    

    if (isset($_POST['consultation'])) {
        // Sanitize and assign POST data to variables
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $phone = mysqli_real_escape_string($conn, $_POST['phone']);
        $message = mysqli_real_escape_string($conn, $_POST['message']);
        $coverage = mysqli_real_escape_string($conn, $_POST['coverage']);
        $typeofhair = mysqli_real_escape_string($conn, $_POST['typeofhair']);
        $lengthofhair = mysqli_real_escape_string($conn, $_POST['lengthofhair']);
        $haircondition = mysqli_real_escape_string($conn, $_POST['haircondition']);
        $scalpcondition = mysqli_real_escape_string($conn, $_POST['scalpcondition']);
        $saloon = mysqli_real_escape_string($conn, $_POST['saloon']);
        $visited = mysqli_real_escape_string($conn, $_POST['visited']);
        $style = mysqli_real_escape_string($conn, $_POST['style']);
        $about = mysqli_real_escape_string($conn, $_POST['about']);
        $referred = mysqli_real_escape_string($conn, $_POST['referred']);
    
        // Handle file uploads
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
    
        // Generate unique filenames using timestamp and uniqid
        $hair_file_name = time() . "_" . uniqid() . "_" . basename($_FILES["hair"]["name"]);
        $inspirational_file_name = time() . "_" . uniqid() . "_" . basename($_FILES["inspirational"]["name"]);
        
        $hair_file = $target_dir . $hair_file_name;
        $inspirational_file = $target_dir . $inspirational_file_name;
    
        $uploadOk = 1;
        $imageFileType1 = strtolower(pathinfo($hair_file, PATHINFO_EXTENSION));
        $imageFileType2 = strtolower(pathinfo($inspirational_file, PATHINFO_EXTENSION));
    
        // Check if image files are actual images
        $check1 = getimagesize($_FILES["hair"]["tmp_name"]);
        $check2 = getimagesize($_FILES["inspirational"]["tmp_name"]);
        if ($check1 !== false && $check2 !== false) {
            $uploadOk = 1;
        } else {
            echo "One or more files are not images.";
            $uploadOk = 0;
        }
    
        // Check if files already exist
        if (file_exists($hair_file) || file_exists($inspirational_file)) {
            echo "Sorry, one or more files already exist.";
            $uploadOk = 0;
        }
    
        // Check file sizes
        if ($_FILES["hair"]["size"] > 5000000 || $_FILES["inspirational"]["size"] > 5000000) {
            echo "Sorry, one or more files are too large.";
            $uploadOk = 0;
        }
    
        // Allow certain file formats
        $allowedFormats = ["jpg", "jpeg", "png", "gif"];
        if (!in_array($imageFileType1, $allowedFormats) || !in_array($imageFileType2, $allowedFormats)) {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            $uploadOk = 0;
        }
    
        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            echo "Sorry, your files were not uploaded.";
        // if everything is ok, try to upload files
        } else {
            if (move_uploaded_file($_FILES["hair"]["tmp_name"], $hair_file) && move_uploaded_file($_FILES["inspirational"]["tmp_name"], $inspirational_file)) {
                // Prepare the SQL query to insert the data
                $sql = "INSERT INTO consultation (name, email, phone, message, coverage, typeofhair, lengthofhair, haircondition, scalpcondition, saloon, visited, style, about, referred, hair_image, inspirational_image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
                // Prepare the statement
                if ($stmt = mysqli_prepare($conn, $sql)) {
                    // Bind the parameters to the statement
                    mysqli_stmt_bind_param($stmt, "ssssssssssssssss", $name, $email, $phone, $message, $coverage, $typeofhair, $lengthofhair, $haircondition, $scalpcondition, $saloon, $visited, $style, $about, $referred, $hair_file_name, $inspirational_file_name);
            
                    // Execute the statement
                    if (mysqli_stmt_execute($stmt)) {
                        header('Location: thanks.php'); // Redirect after successful insertion
                        exit();
                    } else {
                        echo "Error: " . mysqli_error($conn);
                    }
            
                    // Close the statement
                    mysqli_stmt_close($stmt);
                } else {
                    echo "Error: " . mysqli_error($conn);
                }
            } else {
                echo "Sorry, there was an error uploading your files. Error details: ";
                echo "hair file error: " . $_FILES["hair"]["error"];
                echo "inspirational file error: " . $_FILES["inspirational"]["error"];
            }
        }
    
        
    
        // Close the database connection
        mysqli_close($conn);
    }


?>