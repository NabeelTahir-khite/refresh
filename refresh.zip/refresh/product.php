<!doctype html>
<html class="no-js" lang="zxx">

 <!-- Favicons - Place favicon.ico in the root directory -->
    <link rel="icon" type="image/png" size="16x16" href="assets/img/logo-1.png">
    <!-- <link rel="manifest" href="assets/img/favicons/manifest.json"> -->
<body>


   <?php include'header.php' ?>
    <!--==============================
    Breadcumb
============================== -->
    <div class="breadcumb-wrapper " data-bg-src="assets/img/bg/11-01.jpg">
        <div class="container z-index-common">
            <div class="breadcumb-content text-center">
                <h1 class="breadcumb-title">Mowan Magix|10</h1>
                <div class="breadcumb-menu-wrap">
                    <ul class="breadcumb-menu">
                        <li><a href="index.html">Home</a></li>
                        <li class="active">Mowan Magix|10</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!--==============================
    Product Details
    ==============================-->
    <section class="vs-product-wrapper product-details space-top space-negative-bottom">
        <div class="container">
            <div class="row mb-5 pb-4 gx-40 align-items-center">
                <div class="col-lg-6 mb-30 mb-lg-0">
                    <div class="position-relative">
                        <div class="discount-tagged">15% off</div>
                        <div class="product-tagged">
                            <a href="#" class="offers">Offers</a>
                            <a href="#">New</a>
                        </div>
                        <div class="product-big-img vs-carousel" data-slide-show="1" data-lg-slide-show="1" data-md-slide-show="1" data-sm-slide-show="1" data-fade="true" data-dots="true">
                            <div class="product-img">
                                <img src="assets/img/product/Mowan-1.jpeg" alt="Shop Image" class="w-100">
                            </div>
                            <div class="product-img">
                                <img src="assets/img/product/Mowan-2.jpeg" alt="Shop Image" class="w-100">
                            </div>
                            <div class="product-img">
                                <img src="assets/img/product/Mowan-3.jpeg" alt="Shop Image" class="w-100">
                            </div>
                            <div class="product-img">
                                <img src="assets/img/product/Mowan-4.jpeg" alt="Shop Image" class="w-100">
                            </div>
                            <div class="product-img">
                                <img src="assets/img/product/Mowan-5.jpeg" alt="Shop Image" class="w-100">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="product-about">
                        <span class="price font-theme">
                        Mowan
                        <!-- <del>$1,245.69</del> -->
                        </span>
                        <h3   class="gallery-title">Time Efficient Spectrum Technology</h3>
                        <div class="mt-2">
                            <div class="star-rating" role="img" aria-label="Rated 5.00 out of 5">
                                <span style="width:100%">Rated <strong class="rating">5.00</strong> out of 5 based on <span class="rating">1</span> customer rating</span>
                            </div>
                        </div>
                        <p class="my-4"><b>Hair colouring system with enhanced chromatic coalescence</b><br>Years of research and development have produced a revolutionary hair colouring system unique in its kind, today offering increased performance, efficiency and peace of mind. Today you can have superior results while safeguarding your health and your hair.
                        Size</p>
                        <div class="mt-2 link-inherit">
                            <p><strong class="text-title me-3 font-theme">Availability :</strong><a href="#"><i class="far fa-check-square me-2 ms-1"></i>In Stock</a></p>
                        </div>
                        <!-- <div class="actions mb-4 pb-2">
                            <div class="quantity style2 ">
                                <input type="number" class="qty-input" value="1" min="1" max="99">
                                <button class="quantity-minus qut-btn"><i class="far fa-chevron-down"></i></button>
                                <button class="quantity-plus qut-btn"><i class="far fa-chevron-up"></i></button>
                            </div>
                            <a href="cart.html" class="vs-btn shadow-none">Add To Cart</a>
                            <a href="#" class="icon-btn style2"><i class="far fa-heart"></i></a>
                        </div> -->
                        <div class="product_meta">
                            <span class="sku_wrapper"> 100ml /<span class="sku">3,52 fl.Oz</span></span>
                            <!-- <span class="posted_in"><a href="#" rel="tag">100ml /</a></span> -->
                        </div>
                    </div>
                </div>
            </div>
            <ul class="nav product-tab-style1 mb-30 justify-content-center mb-4" id="productTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <a class="nav-link active" id="description-tab" data-bs-toggle="tab" href="#description" role="tab" aria-controls="description" aria-selected="false">description</a>
                </li>
                <!--<li class="nav-item" role="presentation">-->
                <!--    <a class="nav-link" id="reviews-tab" data-bs-toggle="tab" href="#reviews" role="tab" aria-controls="reviews" aria-selected="true">Book Now</a>-->
                <!--</li>-->
            </ul>
            <div class="tab-content mb-30" id="productTabContent">
                <div class="tab-pane fade show active" id="description" role="tabpanel" aria-labelledby="description-tab">
                    <p class="fs-md">A unique complex of 18 vegetable amino acids that restore hair’s natural health while hair color is developing. Anti age properties combat deterioration of hair and scalp and protect against atmospheric damage. Totally regenerates the hair fibre providing unsurpassed results.</p>
                    <div class="row mt-30">
                        <div class="col-md-6 mb-30">
                            <img src="assets/img/product/Mowan-3.jpeg" class="w-100" alt="Shop Image">
                        </div>
                        <div class="col-md-6 mb-30">
                            <img src="assets/img/product/Mowan-4.jpeg" class="w-100" alt="Shop Image">
                        </div>
                        <div class="col-md-12 mb-30">
                        <iframe width="1268" height="713" src="https://www.youtube.com/embed/bjtCy-97gqg" title="Megix|10 l&#39;esclusiva colorazione professionale che ricostruisce il capello in soli 10 minuti di posa" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                        </div>
                    </div>
                    <div class="product-inner-list mb-4">
                        <ul>
                            <li>10 minutes processing time</li>
                            <li>10 times safer</li>
                            <li>10 times healthier hair</li>
                            <li>10 times more softness and shine</li>
                        </ul>
                    </div>
                    <div class="product-inner-list ">
                        <ul>
                            <li>10 + 8 aminoacids</li>
                            <li>10 out of 10 in in cromatic intensity</li>
                            <li>10 out of 10 in grey coverage</li>
                            <li>10 times more efficient hair colouring service</li>
                        </ul>
                    </div>
                </div>
                <!--<div class="tab-pane fade" id="reviews" role="tabpanel" aria-labelledby="reviews-tab">-->
<!-- 
                    <div class="vs-comments-wrap pt-3 ">
                        <ul class="comment-list">
                            <li class="review vs-comment-item">
                                <div class="vs-post-comment">
                                    <div class="comment-avater">
                                        <img src="assets/img/blog/comment-author-1.jpg" alt="Comment Author">
                                    </div>
                                    <div class="comment-content">
                                        <div class="star-rating" role="img" aria-label="Rated 5.00 out of 5">
                                            <span style="width:100%">Rated <strong class="rating">5.00</strong> out of 5 based on <span class="rating">1</span> customer rating</span>
                                        </div>
                                        <h4 class="name h4">Mark Jack</h4>
                                        <span class="commented-on">22 April, 2022</span>
                                        <p class="text">Progressively procrastinate mission-critical action items before team building ROI.
                                            Interactively provide access to cross functional quality vectors for client-centric catalysts for change.
                                        </p>
                                    </div>
                                </div>
                            </li>
                            <li class="review vs-comment-item">
                                <div class="vs-post-comment">
                                    <div class="comment-avater">
                                        <img src="assets/img/blog/comment-author-2.jpg" alt="Comment Author">
                                    </div>
                                    <div class="comment-content">
                                        <div class="star-rating" role="img" aria-label="Rated 5.00 out of 5">
                                            <span style="width:100%">Rated <strong class="rating">5.00</strong> out of 5 based on <span class="rating">1</span> customer rating</span>
                                        </div>
                                        <h4 class="name h4">John Deo</h4>
                                        <span class="commented-on">26 April, 2022</span>
                                        <p class="text">Competently provide access to fully researched methods of empowerment without sticky models. Credibly morph front-end niche markets whereas 2.0 users. Enthusiastically seize team.</p>
                                    </div>
                                </div>
                            </li>
                            <li class="review vs-comment-item">
                                <div class="vs-post-comment">
                                    <div class="comment-avater">
                                        <img src="assets/img/blog/comment-author-1.jpg" alt="Comment Author">
                                    </div>
                                    <div class="comment-content">
                                        <div class="star-rating" role="img" aria-label="Rated 5.00 out of 5">
                                            <span style="width:100%">Rated <strong class="rating">5.00</strong> out of 5 based on <span class="rating">1</span> customer rating</span>
                                        </div>
                                        <h4 class="name h4">Tara sing</h4>
                                        <span class="commented-on">26 April, 2022</span>
                                        <p class="text">Competently provide access to fully researched methods of empowerment without sticky models. Credibly morph front-end niche markets whereas 2.0 users. Enthusiastically seize team.</p>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div> -->
                    
                     <!-- Comment Form -->
                    <!--<div class="vs-comment-form pt-3">-->
                    <!--    <div class="form-title">-->
                    <!--        <h3 class="blog-inner-title h3">Book Now</h3>-->
                    <!--    </div>-->
                    <!--    <div class="row">-->
                          
                    <!--        <div class="col-12 form-group mb-4">-->
                    <!--            <textarea placeholder="Write a Message" class="form-control style3"></textarea>-->
                    <!--            <i class="text-title far fa-pencil-alt"></i>-->
                    <!--        </div>-->
                    <!--        <div class="col-md-6 form-group mb-4">-->
                    <!--            <input type="text" placeholder="Your Name" class="form-control style3">-->
                    <!--            <i class="text-title far fa-user"></i>-->
                    <!--        </div>-->
                    <!--        <div class="col-md-6 form-group mb-4">-->
                    <!--            <input type="text" placeholder="Your Email" class="form-control style3">-->
                    <!--            <i class="text-title far fa-envelope"></i>-->
                    <!--        </div>-->
                    <!--        <div class="col-12 form-group mb-4">-->
                    <!--            <input id="reviewcheck" name="reviewcheck" type="checkbox">-->
                    <!--            <label for="reviewcheck">Save my name, email, and website in this browser for the next time I comment.<span class="checkmark"></span></label>-->
                    <!--        </div>-->
                    <!--        <div class="col-12 form-group mb-0">-->
                    <!--            <button class="vs-btn style2 text-white">Submit Now</button>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                </div>
            </div>
        </div>
    </section>
    
    <?php include'footer.php' ?>


</body>

</html>