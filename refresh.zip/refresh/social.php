<!doctype html>
<html class="no-js" lang="zxx">

 <!-- Favicons - Place favicon.ico in the root directory -->
    <link rel="icon" type="image/png" size="16x16" href="assets/img/logo-1.png">
    <!-- <link rel="manifest" href="assets/img/favicons/manifest.json"> -->

<body>


    <?php include'header.php'?>
    <!--==============================
    Breadcumb
============================== -->
    
    <div class="breadcumb-wrapper " data-bg-src="assets/img/bg/banner4.jpg">
        <div class="container z-index-common">
            <div class="breadcumb-content text-center">
                <h1 class="breadcumb-title">Social</h1>
                <div class="breadcumb-menu-wrap">
                    <ul class="breadcumb-menu">
                        <li><a href="index.php">Home</a></li>
                        <li class="active">Social</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
<!--==============================
    Service Area
    ==============================-->
    <section class=" space">
        <div class="container">
            <div class="row justify-content-center text-center">
                <div class="col-md-11 col-lg-8 col-xl-6">
                    
                </div>
            </div>
            <script src="https://static.elfsight.com/platform/platform.js" data-use-service-core defer></script>
            <div class="elfsight-app-e215f463-69ed-4e4e-9d52-7b52330b196b" data-elfsight-app-lazy></div>


        </div>
    </section>


    <!--==============================
    Counter Area
    ==============================-->
    <!--<div class="vs-counter-wrapper space-negative bg-light">-->
    <!--    <div class="container">-->
    <!--        <div class="row">-->
    <!--            <div class="col-sm-6 col-lg-3">-->
    <!--                <div class="vs-counter style3 text-center">-->
    <!--                    <div class="counter-icon">-->
    <!--                        <img src="assets/img/icon/counter--1-1.png" alt="Counter icon">-->
    <!--                    </div>-->
    <!--                    <span class="counter-number">3116</span>-->
    <!--                    <p class="counter-text mb-0">Hair Treatments</p>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-sm-6 col-lg-3">-->
    <!--                <div class="vs-counter style3 text-center">-->
    <!--                    <div class="counter-icon">-->
    <!--                        <img src="assets/img/icon/counter--1-2.png" alt="Counter icon">-->
    <!--                    </div>-->
    <!--                    <span class="counter-number">200</span>-->
    <!--                    <p class="counter-text mb-0">Salon Products</p>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-sm-6 col-lg-3">-->
    <!--                <div class="vs-counter style3 text-center">-->
    <!--                    <div class="counter-icon">-->
    <!--                        <img src="assets/img/icon/counter--1-3.png" alt="Counter icon">-->
    <!--                    </div>-->
    <!--                    <span class="counter-number">350</span>-->
    <!--                    <p class="counter-text mb-0">Shades of colors</p>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-sm-6 col-lg-3">-->
    <!--                <div class="vs-counter style3 text-center">-->
    <!--                    <div class="counter-icon">-->
    <!--                        <img src="assets/img/icon/counter--1-4.png" alt="Counter icon">-->
    <!--                    </div>-->
    <!--                    <span class="counter-number">130k</span>-->
    <!--                    <p class="counter-text mb-0">Satisfied Customers</p>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->

              
  <?php include'footer.php'?>

</body>

</html>