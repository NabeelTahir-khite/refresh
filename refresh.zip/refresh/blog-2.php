<!doctype html>
<html class="no-js" lang="zxx">
     <!-- Favicons - Place favicon.ico in the root directory -->
    <link rel="icon" type="image/png" size="16x16" href="assets/img/logo-1.png">
    <!-- <link rel="manifest" href="assets/img/favicons/manifest.json"> -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Haarino - Barber and Salon HTML Template - Our Blog</title>
    <meta name="author" content="Vecuro">
    <meta name="description" content="Haarino - Barber and Salon HTML Template">
    <meta name="keywords" content="Haarino - Barber and Salon HTML Template" />
    <meta name="robots" content="INDEX,FOLLOW">

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


    <!--==============================
	    All CSS File
	============================== -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Handlee&family=Open+Sans:wght@400;600&family=Syne:wght@600;700&display=swap" rel="stylesheet">


    <!-- Favicons - Place favicon.ico in the root directory -->
    <link rel="apple-touch-icon" sizes="57x57" href="assets/img/favicons/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="assets/img/favicons/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="assets/img/favicons/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="assets/img/favicons/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="assets/img/favicons/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="assets/img/favicons/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="assets/img/favicons/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="assets/img/favicons/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="assets/img/favicons/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicons/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="assets/img/favicons/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">

    <!--==============================
	    All CSS File
	============================== -->
    <!-- Bootstrap -->
    <!-- <link rel="stylesheet" href="assets/css/app.min.css"> -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- Fontawesome Icon -->
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <!-- Layerslider -->
    <link rel="stylesheet" href="assets/css/layerslider.min.css">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="assets/css/magnific-popup.min.css">
    <!-- Slick Slider -->
    <link rel="stylesheet" href="assets/css/slick.min.css">
    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>


    <!--[if lte IE 9]>
    	<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
  <![endif]-->



    <!--********************************
   		Code Start From Here 
	******************************** -->




    <!--==============================
     Preloader
  ==============================-->
    <div class="preloader  ">
        <button class="vs-btn preloaderCls">Cancel Preloader </button>
        <div class="preloader-inner">
            <img src="assets/img/logo.png" alt="Haarino">
            <span class="loader"></span>
        </div>
    </div>
    <!--==============================
    Mobile Menu
  ============================== -->
    <div class="vs-menu-wrapper">
        <div class="vs-menu-area text-center">
            <button class="vs-menu-toggle"><i class="fal fa-times"></i></button>
            <div class="mobile-logo">
                <a href="index.html"><img src="assets/img/logo-mobile.png" alt="Haarino"></a>
            </div>
            <div class="vs-mobile-menu">
                <ul>
                    <li class="menu-item-has-children">
                        <a href="index.html">Home</a>
                        <ul class="sub-menu">
                            <li><a href="index.html">Home One</a></li>
                            <li><a href="index-2.html">Home Two</a></li>
                            <li><a href="index-3.html">Home Three</a></li>
                            <li><a href="index-4.html">Home Four<span class="new-label">New</span></a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="about.html">About</a>
                    </li>
                    <li class="menu-item-has-children">
                        <a href="blog.html">Blog</a>
                        <ul class="sub-menu">
                            <li><a href="blog.html">Blog One</a></li>
                            <li><a href="blog-2.html">Blog Two</a></li>
                            <li><a href="blog-details.html">Blog Details</a></li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children">
                        <a href="#">Pages</a>
                        <ul class="sub-menu">
                            <li><a href="find-salon.html">Find a Salon</a></li>
                            <li><a href="gallery.html">Gallery One</a></li>
                            <li><a href="gallery-2.html">Gallery Two</a></li>
                            <li><a href="price-list.html">Price List One</a></li>
                            <li><a href="price-list-2.html">Price List Two</a></li>
                            <li><a href="price-list-3.html">Price List Three</a></li>
                            <li><a href="team-details.html">Team Details</a></li>
                            <li><a href="discount-offers.html">Discount Offers</a></li>
                            <li><a href="product-details.html">Products Details</a></li>
                            <li><a href="cart.html">Shopping Cart</a></li>
                            <li><a href="checkout.html">Check Out</a></li>
                            <li><a href="error.html">Error Page</a></li>
                        </ul>
                    </li>
                    <li class="menu-item-has-children">
                        <a href="#">Elements</a>
                        <ul class="sub-menu">
                            <li><a href="element-typography.html">Typography</a></li>
                            <li><a href="element-buttons.html">Buttons</a></li>
                            <li><a href="element-columns.html">Columns</a></li>
                            <li><a href="element-messagebox.html">Message Box</a></li>
                            <li><a href="element-separators.html">Separators</a></li>
                            <li><a href="element-services.html">Services Card</a></li>
                            <li><a href="element-testimonials.html">Testimonials</a></li>
                            <li><a href="element-projectbox.html">Gallery</a></li>
                            <li><a href="element-priceplan.html">Price Plan</a></li>
                            <li><a href="element-counters.html">Counters</a></li>
                            <li><a href="element-accordions.html">Accordions</a></li>
                            <li><a href="element-team.html">Team</a></li>
                            <li><a href="element-forms.html">Forms</a></li>
                            <li><a href="element-blogcard.html">Blog Card</a></li>
                            <li><a href="element-ctas.html">Call To Actions</a></li>
                            <li><a href="element-map.html">Google Map</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="contact.html">Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!--==============================
        Header Area
    ==============================-->
    <header class="vs-header header-layout1">
        <!-- Header Top Area -->
        <div class="header-top py-15 d-none d-sm-block">
            <div class="container">
                <div class="row align-items-center justify-content-center justify-content-lg-between">
                    <div class="col-sm-auto d-none d-lg-block">
                        <p class="m-0 fw-semibold text-white"><i class="fal fa-map-marker-alt me-2"></i> <a href="find-salon.html" class="text-reset">Locate a Salon</a></p>
                    </div>
                    <div class="col-auto">
                        <div class="header-info-list text-white">
                            <ul>
                                <li><i class="fas fa-phone-alt"></i>Phone: <a class="text-reset" href="tel:02073885619">020 7388 5619</a></li>
                                <li><i class="fal fa-envelope"></i>Email: <a class="text-reset" href="mailto:info@example.com">info@example.com</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="sticky-wrapper">
            <div class="sticky-active">
                <!-- Main Menu Area -->
                <div class="header-inner">
                    <div class="container">
                        <div class="row align-items-center justify-content-between">
                            <div class="col-7 col-sm-auto order-1">
                                <div class="header-logo py-2 py-lg-0">
                                    <a href="index.html"><img src="assets/img/logo.png" alt="Haarino"></a>
                                </div>
                            </div>
                            <div class="col-auto order-3 order-sm-2">
                                <nav class="main-menu menu-style1 d-none d-lg-block">
                                    <ul>
                                        <li class="menu-item-has-children">
                                            <a href="index.html"><span class="has-new-lable">Home<span class="new-label">new</span></span></a>
                                            <ul class="sub-menu">
                                                <li><a href="index.html">Home One</a></li>
                                                <li><a href="index-2.html">Home Two</a></li>
                                                <li><a href="index-3.html">Home Three</a></li>
                                                <li><a href="index-4.html">Home Four<span class="new-label">New</span></a></li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="about.html">About</a>
                                        </li>
                                        <li class="menu-item-has-children mega-menu-wrap">
                                            <a href="#"><span class="has-new-lable">Elements<span class="new-label">new</span></span></a>
                                            <ul class="mega-menu">
                                                <li><a href="shop.html">Elements</a>
                                                    <ul>
                                                        <li><a href="element-typography.html">Typography</a></li>
                                                        <li><a href="element-buttons.html">Buttons</a></li>
                                                        <li><a href="element-columns.html">Columns</a></li>
                                                        <li><a href="element-messagebox.html">Message Box</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="#">Elements</a>
                                                    <ul>
                                                        <li><a href="element-separators.html">Separators</a></li>
                                                        <li><a href="element-services.html">Services Card</a></li>
                                                        <li><a href="element-testimonials.html">Testimonials</a></li>
                                                        <li><a href="element-projectbox.html">Gallery</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="#">Elements</a>
                                                    <ul>
                                                        <li><a href="element-priceplan.html">Price Plan</a></li>
                                                        <li><a href="element-counters.html">Counters</a></li>
                                                        <li><a href="element-accordions.html">Accordions</a></li>
                                                        <li><a href="element-team.html">Team</a></li>

                                                    </ul>
                                                </li>
                                                <li><a href="#">Elements</a>
                                                    <ul>
                                                        <li><a href="element-forms.html">Forms</a></li>
                                                        <li><a href="element-blogcard.html">Blog Card</a></li>
                                                        <li><a href="element-ctas.html">Call To Actions</a></li>
                                                        <li><a href="element-map.html">Google Map</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class="menu-item-has-children mega-menu-wrap">
                                            <a href="#">Pages</a>
                                            <ul class="mega-menu">
                                                <li><a href="shop.html">Pagelist 1</a>
                                                    <ul>
                                                        <li><a href="index.html">Home One</a></li>
                                                        <li><a href="index-2.html">Home Two</a></li>
                                                        <li><a href="index-3.html">Home Three</a></li>
                                                        <li><a href="index-4.html">Home Four<span class="new-label">New</span></a></li>
                                                        <li><a href="about.html">About Us</a></li>
                                                        <li><a href="find-salon.html">Find a Salon</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="#">Pagelist 2</a>
                                                    <ul>
                                                        <li><a href="gallery.html">Gallery One</a></li>
                                                        <li><a href="gallery-2.html">Gallery Two</a></li>
                                                        <li><a href="price-list.html">Price List One</a></li>
                                                        <li><a href="price-list-2.html">Price List Two</a></li>
                                                        <li><a href="price-list-3.html">Price List Three</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="#">Pagelist 3</a>
                                                    <ul>
                                                        <li><a href="team-details.html">Team Details</a></li>
                                                        <li><a href="discount-offers.html">Discount Offers</a></li>
                                                        <li><a href="shop.html">Our Products<span class="new-label">New</span></a></li>
                                                        <li><a href="product-details.html">Products Details</a></li>
                                                        <li><a href="cart.html">Shopping Cart</a></li>
                                                        <li><a href="checkout.html">Check Out</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="#">Pagelist 4</a>
                                                    <ul>
                                                        <li><a href="blog.html">Blog One</a></li>
                                                        <li><a href="blog-2.html">Blog Two</a></li>
                                                        <li><a href="blog-details.html">Blog Details</a></li>
                                                        <li><a href="contact.html">Contact Us</a></li>
                                                        <li><a href="error.html">Error Page</a></li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="contact.html">Contact</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                            <div class="col-5 col-sm-auto order-2 order-sm-3 text-end">
                                <div class="header-btn">
                                    <a href="cart.html" class="cart-icon me-4 me-lg-3 mr-xl-0"><i class="fal fa-shopping-cart"></i><span class="badge">1</span></a>
                                    <a href="contact.html" class="vs-btn d-none d-xl-inline-block">Book Now</a>
                                    <button class="vs-menu-toggle d-inline-block d-lg-none"><i class="fas fa-bars"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!--==============================
    Breadcumb
============================== -->
    <div class="breadcumb-wrapper " data-bg-src="assets/img/breadcumb/breadcumb-1.jpg">
        <div class="container z-index-common">
            <div class="breadcumb-content text-center">
                <h1 class="breadcumb-title">Our Blog</h1>
                <div class="breadcumb-menu-wrap">
                    <ul class="breadcumb-menu">
                        <li><a href="index.html">Home</a></li>
                        <li class="active">Our Blog</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!--==============================
    Blog Area
    ==============================-->
    <section class="vs-blog-wrapper space-top space-negative-bottom">
        <div class="container">
            <div class="blog-fliped">
                <div class="row justify-content-between gx-xl-0">
                    <div class="col-lg-6 col-xl-5 align-self-center order-1 order-lg-0">
                        <div class="blog-content">
                            <div class="meta-box">
                                <a href="blog.html"><i class="far fa-calendar-alt"></i>Dec 12, 2022</a>
                                <a href="blog.html"><i class="fas fa-comment-alt"></i>21</a>
                            </div>
                            <h2 class="blog-title fw-semibold"><a href="blog-details.html">Hair thinning: what can you do about it?</a></h2>
                            <p class="blog-text">Alienum phaedrum torquato eu, vis detraxit Mei an per m vs iculaeuripidis Alienum phaedrum vis detraxit periculis a enu quato eu, ienum phaedrume vis detraxit.</p>
                            <a href="blog-details.html" class="icon-btn"><i class="fas fa-chevron-right"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-6 order-0 order-lg-1">
                        <div class="blog-img">
                            <a href="blog-details.html"><img src="assets/img/blog/blog-3-1.jpg" alt="Blog Image" class="w-100"></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="blog-fliped">
                <div class="row justify-content-between gx-xl-0">
                    <div class="col-lg-6 col-xl-5 align-self-center order-1 order-lg-0">
                        <div class="blog-content">
                            <div class="meta-box">
                                <a href="blog.html"><i class="far fa-calendar-alt"></i>Dec 12, 2022</a>
                                <a href="blog.html"><i class="fas fa-comment-alt"></i>21</a>
                            </div>
                            <h2 class="blog-title fw-semibold"><a href="blog-details.html">Do you really know what’s your shampoo?</a></h2>
                            <p class="blog-text">Alienum phaedrum torquato eu, vis detraxit Mei an per m vs iculaeuripidis Alienum phaedrum vis detraxit periculis a enu quato eu, ienum phaedrume vis detraxit.</p>
                            <a href="blog-details.html" class="icon-btn"><i class="fas fa-chevron-right"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-6 order-0 order-lg-1">
                        <div class="blog-img">
                            <a href="blog-details.html"><img src="assets/img/blog/blog-3-2.jpg" alt="Blog Image" class="w-100"></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="blog-fliped">
                <div class="row justify-content-between gx-xl-0">
                    <div class="col-lg-6 col-xl-5 align-self-center order-1 order-lg-0">
                        <div class="blog-content">
                            <div class="meta-box">
                                <a href="blog.html"><i class="far fa-calendar-alt"></i>Dec 12, 2022</a>
                                <a href="blog.html"><i class="fas fa-comment-alt"></i>21</a>
                            </div>
                            <h2 class="blog-title fw-semibold"><a href="blog-details.html">What is this magic ingredient Olaplex?</a></h2>
                            <p class="blog-text">Alienum phaedrum torquato eu, vis detraxit Mei an per m vs iculaeuripidis Alienum phaedrum vis detraxit periculis a enu quato eu, ienum phaedrume vis detraxit.</p>
                            <a href="blog-details.html" class="icon-btn"><i class="fas fa-chevron-right"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-6 order-0 order-lg-1">
                        <div class="blog-img">
                            <a href="blog-details.html"><img src="assets/img/blog/blog-3-3.jpg" alt="Blog Image" class="w-100"></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="blog-fliped">
                <div class="row justify-content-between gx-xl-0">
                    <div class="col-lg-6 col-xl-5 align-self-center order-1 order-lg-0">
                        <div class="blog-content">
                            <div class="meta-box">
                                <a href="blog.html"><i class="far fa-calendar-alt"></i>Dec 12, 2022</a>
                                <a href="blog.html"><i class="fas fa-comment-alt"></i>21</a>
                            </div>
                            <h2 class="blog-title fw-semibold"><a href="blog-details.html">Fringe Benefits. Do fringes suit everyone?</a></h2>
                            <p class="blog-text">Alienum phaedrum torquato eu, vis detraxit Mei an per m vs iculaeuripidis Alienum phaedrum vis detraxit periculis a enu quato eu, ienum phaedrume vis detraxit.</p>
                            <a href="blog-details.html" class="icon-btn"><i class="fas fa-chevron-right"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-6 order-0 order-lg-1">
                        <div class="blog-img">
                            <a href="blog-details.html"><img src="assets/img/blog/blog-3-4.jpg" alt="Blog Image" class="w-100"></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="blog-fliped">
                <div class="row justify-content-between gx-xl-0">
                    <div class="col-lg-6 col-xl-5 align-self-center order-1 order-lg-0">
                        <div class="blog-content">
                            <div class="meta-box">
                                <a href="blog.html"><i class="far fa-calendar-alt"></i>Dec 12, 2022</a>
                                <a href="blog.html"><i class="fas fa-comment-alt"></i>21</a>
                            </div>
                            <h2 class="blog-title fw-semibold"><a href="blog-details.html">Need to know about allergy skin tests</a></h2>
                            <p class="blog-text">Alienum phaedrum torquato eu, vis detraxit Mei an per m vs iculaeuripidis Alienum phaedrum vis detraxit periculis a enu quato eu, ienum phaedrume vis detraxit.</p>
                            <a href="blog-details.html" class="icon-btn"><i class="fas fa-chevron-right"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-6 order-0 order-lg-1">
                        <div class="blog-img">
                            <a href="blog-details.html"><img src="assets/img/blog/blog-3-5.jpg" alt="Blog Image" class="w-100"></a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="vs-pagination pb-30">
                <ul>
                    <li><a href="#" class="active">1</a></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#"><i class="fas fa-angle-right"></i></a></li>
                </ul>
            </div>
        </div>
    </section>
    <!--==============================
			Footer Area
	==============================-->
    <footer class="footer-wrapper footer-layout1 bg-dark">
        <div class="widget-area">
            <div class="container">
                <div class="row justify-content-between">
                    <div class="col-md-12 col-lg-4">
                        <div class="widget footer-widget pt-0  ">
                            <h3 class="widget_title">About Us</h3>
                            <div class="vs-widget-about">
                                <!-- <div class="footer-logo mb-3">
      <a href="index.html"><img src="assets/img/logo-mix.png" alt="Haarino"></a>
    </div> -->
                                <p class="pe-xl-5 mb-3">My course involved cutting, colouring, relaxing and all sort of hair treatments Available for Appointment.</p>
                                <div class="footer-rating">
                                    <p class="text-uppercase text-white mb-0">5 Star - 3,674 reviews</p>
                                    <div class="text-theme fs-16">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 col-xl-3">
                        <div class="widget footer-widget  ">
                            <h3 class="widget_title">Contact Us</h3>
                            <div class="vs-widget-about">
                                <p class="footer-info"><i class="fas fa-map-marker-alt"></i>66 Walker Road, Suite D, Great Virginia 22066</p>
                                <p class="footer-info"><i class="fas fa-envelope"></i>Email: <a class="text-inherit" href="mailto:Haarino@email.com">Haarino@email.com</a></p>
                                <p class="footer-info"><i class="fas fa-phone-alt"></i>Tel: <a class="text-inherit" href="tel:703-261-6660">703-261-6660</a></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 col-xl-3">
                        <div class="widget footer-widget   ">
                            <h3 class="widget_title">Openinng Hours</h3>
                            <div class="footer-table text-white">
                                <table>
                                    <tr>
                                        <td>Mon - Thu:</td>
                                        <td>10am - 7pm</td>
                                    </tr>
                                    <tr>
                                        <td>Saturday:</td>
                                        <td>10am - 7pm</td>
                                    </tr>
                                    <tr>
                                        <td>Sunday:</td>
                                        <td><a class="text-theme" href="contact.html">By Appointment</a></td>
                                    </tr>
                                    <tr>
                                        <td>Friday:</td>
                                        <td><a class="text-theme" href="contact.html">By Call</a></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer-instagram pt-30" data-pos-for=".copyright-wrap" data-sec-pos="bottom-half">
                    <div class="row vs-carousel" data-slide-show="6" data-lg-slide-show="5" data-md-slide-show="4" data-sm-slide-show="3" data-xs-slide-show="2">
                        <div class="col-md-2">
                            <div class="gallery-thumb">
                                <img src="assets/img/insta/insta-1-1.jpg" class="w-100" alt="Thumb Image">
                                <a href="assets/img/insta/insta-1-1.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="gallery-thumb">
                                <img src="assets/img/insta/insta-1-2.jpg" class="w-100" alt="Thumb Image">
                                <a href="assets/img/insta/insta-1-2.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="gallery-thumb">
                                <img src="assets/img/insta/insta-1-3.jpg" class="w-100" alt="Thumb Image">
                                <a href="assets/img/insta/insta-1-3.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="gallery-thumb">
                                <img src="assets/img/insta/insta-1-4.jpg" class="w-100" alt="Thumb Image">
                                <a href="assets/img/insta/insta-1-4.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="gallery-thumb">
                                <img src="assets/img/insta/insta-1-5.jpg" class="w-100" alt="Thumb Image">
                                <a href="assets/img/insta/insta-1-5.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="gallery-thumb">
                                <img src="assets/img/insta/insta-1-6.jpg" class="w-100" alt="Thumb Image">
                                <a href="assets/img/insta/insta-1-6.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright-wrap bg-theme">
            <div class="container">
                <div class="row  py-30 align-items-center justify-content-between">
                    <div class="col-lg-auto text-center text-lg-end">
                        <p class="mb-0 text-white">Copyright <i class="fal fa-copyright"></i> 2022 <a class="text-white" href="index.html">Haarino</a> - All rights reserved by <a class="text-white" href="https://themeforest.net/user/vecuro_themes">Vecuro</a>.</p>
                    </div>
                    <div class="col-auto d-none d-lg-block">
                        <div class="vs-social">
                            <ul>
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--********************************
                Code End  Here 
        ******************************** -->


    <!-- Scroll To Top -->
    <a href="#" class="scrollToTop scroll-btn"><i class="far fa-arrow-up"></i></a>



    <!--==============================
        All Js File
    ============================== -->
    <!-- Jquery -->
    <script src="assets/js/vendor/jquery.min.js"></script>
    <!-- Slick Slider -->
    <!-- <script src="assets/js/app.min.js"></script> -->
    <script src="assets/js/slick.min.js"></script>
    <!-- Layerslider -->
    <script src="assets/js/layerslider.utils.js"></script>
    <script src="assets/js/layerslider.transitions.js"></script>
    <script src="assets/js/layerslider.kreaturamedia.jquery.js"></script>
    <!-- Bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Magnific Popup -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <!-- Isotope Filter -->
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <!-- Custom Carousel -->
    <script src="assets/js/vscustom-carousel.min.js"></script>
    <!-- Form Js -->
    <script src="assets/js/ajax-mail.js"></script>
    <!-- Main Js File -->
    <script src="assets/js/main.js"></script>


</body>

</html>