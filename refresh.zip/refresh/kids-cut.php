<!doctype html>
<html class="no-js" lang="zxx">
     <!-- Favicons - Place favicon.ico in the root directory -->
    <link rel="icon" type="image/png" size="16x16" href="assets/img/logo-1.png">
    <!-- <link rel="manifest" href="assets/img/favicons/manifest.json"> -->



<body>


    <?php include'header.php'?>
    <!--==============================
    Breadcumb
============================== -->
    <div class="breadcumb-wrapper " data-bg-src="assets/img/bg/banner10.jpg">
        <div class="container z-index-common">
            <div class="breadcumb-content text-center">
                <h1 class="breadcumb-title">Kids under 12 Cut and Style</h1>
                <div class="breadcumb-menu-wrap">
                    <ul class="breadcumb-menu">
                        <li><a href="index.php">Home</a></li>
                        <li class="active">Kids under 12 Cut and Style</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!--==============================
  Team Area
  ============================== -->
    <section class="vs-team-details space-top space-negative-bottom">
        <div class="container">
            <div class="row justify-content-around">
                <!--<div class="col-lg-6 mb-30">-->
                <!--    <div class="position-relative">-->
                <!--        <div class=" " data-mask-src="assets/img/shape/team-mask-2.png"></div>-->
                <!--        <div >-->
                <!--            <img src="assets/img/about/about-1-1.jpg" alt="member Image" class="w-100">-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <div class="col-lg-12 col-xl-12 mb-30 align-self-center">
                    <div class="team-details-content">
                        <h2 class="member-name h3 mb-0 fw-semibold">A Pampered Haircut Experience for Your Little VIP at Refresh Hair Studio!</h2>
                        <span class="member-degi">At Refresh Hair Studio, we understand that even the littlest members of your family deserve a touch of luxury. That's why we offer a <strong>premium haircut service</strong> specifically designed for <strong>children under 12</strong>.</span>
                        <div class="row mt-4 mt-xl-3">
                            <div class="col-sm-6 col-lg-6 col-xl-6 mb-20">
                                <h3 class="fw-semibold fs-22 mb-1 mb-lg-2">A Tranquil Escape:</h3>
                                <p class="mb-0">Step away from the hustle and bustle of the typical kids' salon. Our dedicated space provides a <strong>calm and relaxing environment</strong> where your child can truly unwind before their haircut.</p>
                                 <br>
                                <a href="https://booksy.com/en-us/644713_refresh-hair-studio-chicago_hair-salon_18229_chicago/staffer/1077596#ba_s=sh_1" class="vs-btn mb-30"> BOOK NOW</a>
                                
                                
                            </div>
                            <div class="col-sm-6 col-lg-6 col-xl-6 mb-20">
                                <h3 class="fw-semibold fs-22 mb-1 mb-lg-2">Personalized Attention</h3>
                                <p class="mb-0">Our stylists are not just experienced with children's hair, they're <strong>experts in creating a comfortable and positive experience</strong>. They'll take the time to understand your child's individual preferences and desired style, ensuring a haircut that they'll love.</p>
                                <br>
                                <a href="consultation.php" class="vs-btn mb-30"> CONSULT NOW</a>
                            </div>
                        </div>
                        <div class="vs-social style2 hover-black">
                            <h3 class="fw-semibold fs-22 mb-3">Follow On</h3>
                            <ul>
                                <li><a href="https://www.facebook.com/RefreshHairStudioChicago/?_rdr"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="https://goo.gl/maps/dWeauU3M7baxohVSA"><i class="fab fa-google-plus-g"></i></a></li>
                                <li><a href="https://www.instagram.com/refreshhairstudio/"><i class="fab fa-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="team-details-desc mt-4 pt-1">
                <h2 class="inner-title-style2">Efficiency Meets Expertise</h2>
                <p>We understand that your time is valuable. Our stylists combine their <strong>years of experience</strong> with a focus on <strong>efficiency</strong>, ensuring a high-quality haircut completed in a timely manner.</p>
                <h2 class="inner-title-style2">Parent-Focused Comfort</h2>
                <p>We know parents want to be involved in the process. Enjoy comfortable seating in a <strong>discreet</strong> area where you can relax and observe the haircut, offering guidance when needed.</p>
                <h2 class="inner-title-style2">Beyond the Cut</h2>
                <p>The experience goes beyond just a haircut. Our stylists will pamper your child with a gentle scalp massage and hair wash, using <strong>high-quality, child-friendly products</strong>. We'll also offer a warm towel service and styling tips to keep your child's new look picture-perfect.</p>
                <h2 class="inner-title-style2">A Haircut They'll Look Forward To</h2>
                <p>Forget the overwhelming toys and distractions. Our luxury children's haircut service focuses on <strong>personalized attention, comfort, and a touch of pampering</strong>. We want your child to leave feeling confident and excited about their new haircut!</p>
                
                <div class="row g-3 my-1 my-lg-3 my-xl-3 py-xl-3">
                    <div class="col-md-3">
                        <div class="image-scale-hover">
                            <img src="assets/img/about/user_upload__09-01-2022-21-56-38.jpeg" alt="About Image" class="w-100">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="image-scale-hover position-relative">
                            <img src="assets/img/about/user_upload__09-01-2022-21-54-25.jpeg" alt="About Image" class="w-100">
                            <!--<a href="https://www.youtube.com/watch?v=_sI_Ps7JSEk" class="play-btn position-center popup-video"><i class="fas fa-play"></i></a>-->
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="image-scale-hover">
                            <img src="assets/img/about/user_upload__09-01-2022-21-56-22.jpeg" alt="About Image" class="w-100">
                        </div>
                    </div>
                </div>
                <p class="mt-4 pt-2"><strong>Ready to treat your little VIP to a haircut they'll love?</strong> Schedule an appointment at Refresh Hair Studio today! We look forward to creating a memorable experience for your entire family.</p>
                <p class="mt-4 pt-2"><strong>Kids haircut $50-$65</strong></p>
                 <!--==============================
                            Testimonial Area
        ============================== -->
    <section class="vs-testimonial-wrapper space-bottom space-top">
        <div class="container position-relative">
            
           
            
            <div class="row justify-content-center">
           <?php
                include_once 'google-reviews.php';
            ?>
            
                <div class="col-lg-9 col-xl-7">
              
                    <div class="vs-carousel" id="testimonialslide1" data-asnavfor="#avaterfly" data-fade="true" data-slide-show="1" data-md-slide-show="1">
                    


                        <!-- <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>Jamie does a n amazing job every time I see her She is always cautious and listens attentively to what the client wants. She is always honest and does not tryto sell you into doing more than what you asked for and will not lie if she believes what you are asking for might not work. I will not go to anyone else. She is extremely knowledgeable, honest, caring and personable. And she will go out of her way to make sure you ae comfortable during your styling and happy with your end results, Jamie is truly one of the very best</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Amy Jo</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div>
                        <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>I've been getting my short hair/pixie cut done by Jamie for years and she never disappoints! Jamie's amazing at both cutting and coloring hair and is super friendly, as well. Before Jamie, I went to a bunch of places in Chicago and could never really find the perfect pixie cut but she really gets it. Thank you Jamie!!!</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Katie F</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div>
                        <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>Absolutely stunning results, hair has dimension, shine, and feels amazing. Jaime is an absolute joy to spend time with and makes the experience feel so personal yet luxurious. 5 stars isn't enough!!!</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Kellie E</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div>
                        <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>I had such a great experience at Jamie's salon! She is down to earth and super friendly, and absolutely love the color and cut she gave me!</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Rachel</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div>
                        <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>Jamie is hands down the best. For years she's been the only one I've let do my hair. She always seems to understand what I want and what would work best for my hair. She's a consummate professional and an incredibly kind and friendly human to boot. Cannot recommend her enough1</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Esther S</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div> -->

                    </div>
                </div>

            </div>
            
         </div>
        

               

            </div>
        </div>
    </section>
  <?php include'footer.php'?>


</body>

</html>