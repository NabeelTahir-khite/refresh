<!doctype html>
<html class="no-js" lang="zxx">

 <!-- Favicons - Place favicon.ico in the root directory -->
    <link rel="icon" type="image/png" size="16x16" href="assets/img/logo-1.png">
    <!-- <link rel="manifest" href="assets/img/favicons/manifest.json"> -->

<body>
<style>
    .vs-service {
  height: 430px;
}

.spacemargin{
    margin-top: -121px;
}
</style>

    <?php include'header.php'?>
    <!--==============================
    Breadcumb
============================== -->
    <div class="breadcumb-wrapper " data-bg-src="assets/img/bg/banner11.jpg">
        <div class="container z-index-common">
            <div class="breadcumb-content text-center">
                <h1 class="breadcumb-title">Services</h1>
                <div class="breadcumb-menu-wrap">
                    <ul class="breadcumb-menu">
                        <li><a href="index.php">Home</a></li>
                        <li class="active">Services</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
     <section class="vs-about-wrapper space-top">
        <div class="shape-mockup jump-reverse-img d-none d-xxl-block" data-top="22%" data-left="-7%">
        </div>
        <div class="shape-mockup jump-img d-none d-xxxl-block" data-top="17%" data-right="13%"><img
                src="assets/img/shape/leaf-1-4.png" alt="shape"></div>
        <div class="container">
            <div class="row justify-content-around">
                <div class="col-lg-6 mb-30">
                    <div class="position-relative">
                        <div class=" " data-mask-src="assets/img/shape/team-mask-2.png"></div>
                        <div >
                            <img src="assets/img/about/stylist.jpg" alt="member Image" class="w-100" style="margin-top: 120px;">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-xl-6 mb-30 align-self-center">
                    <div class="team-details-content">
                        <h2 class="member-name h3 mb-0 fw-semibold">We Are More Than Just A<span class="text-theme"> Hairstylist!</span></h2>
                       
                        <div class="row mt-4 mt-xl-3">
                            <div class="col-sm-12 col-lg-12 col-xl-12 mb-20">
                                
                                <p class="mb-0">We are more than just making connections, but building relationships. In order for you to trust us completely we need to know and understand exactly how we can help you by building a relationship with you and your hair. We all desire something but may not have the vision yet, not knowing the possibilities or the options available to you where we can help! Or you’ve had a vision and been told something isn’t possible or wouldn’t work for you leaving you with no options.</p>
                                <br>
                                
                                <p class="mb-0">I can promise you that we put in constant education in this ever changing industry . Will we know everything absolutely not as it’s almost impossible to have enough time in the day to keep up with the constant flow of information and education. We are a part of a nationwide community of hairstylists all over the world and unafraid to learn new skills that benefit you as our client. The skills that can’t be taught is our ability to listen and hear you with the truest intention of only serving you ! You will never see us give any fluff or make a decision for you that wouldn’t be in your best interest . Again, this is why the relationship building is so important. I truly believe there is no client that we can’t help ! What we do is Is thorough investigation on what’s been going on with you and your hair what you’re dreaming for and all the possibilities available.</p>
                               
                                
                            </div>
                           
                        </div>
                      
                    </div>
                </div>
            </div>
            <!--<div class="row justify-content-center text-center">-->
            <!--    <div class="col-lg-8 col-xl-9">-->
            <!--        <div class="title-area">-->
                        <!--<div class="sec-icon">-->
                        <!--    <img src="assets/img/icon/sec-icon.png" alt="Section Title">-->
                        <!--</div>-->
                        
            <!--            <h2 class="sec-title">We Are More Than Just A<span class="text-theme"> Hairstylist!</span></h2>-->
                        
            <!--            <p>We are more than just making connections, but building relationships. In order for you to trust us completely we need to know and understand exactly how we can help you by building a relationship with you and your hair. We all desire something but may not have the vision yet, not knowing the possibilities or the options available to you where we can help! Or you’ve had a vision and been told something isn’t possible or wouldn’t work for you leaving you with no options.</p>-->
            <!--            <p>I can promise you that we put in constant education in this ever changing industry . Will we know everything absolutely not as it’s almost impossible to have enough time in the day to keep up with the constant flow of information and education. We are a part of a nationwide community of hairstylists all over the world and unafraid to learn new skills that benefit you as our client. The skills that can’t be taught is our ability to listen and hear you with the truest intention of only serving you ! You will never see us give any fluff or make a decision for you that wouldn’t be in your best interest . Again, this is why the relationship building is so important. I truly believe there is no client that we can’t help ! What we do is Is thorough investigation on what’s been going on with you and your hair what you’re dreaming for and all the possibilities available.</p>-->
            <!--    </div>-->
            <!--</div>-->


    </section>
    
    
<!--==============================
    Service Area
    ==============================-->
    <section class=" space">
        <div class="container">
            <div class="row justify-content-center text-center">
                <div class="col-md-11 col-lg-8 col-xl-6">
                    <div class="title-area">
                        <h2 class="sec-title">Hair Color Services</h2>
                        <p>For clear, lasting results, groom your hair with our skillfully created, customized color journeys and restorative treatments.</p>
                    </div>
                </div>
            </div>
            <div class="row gx-10 gy-gx justify-content-center">
                <div class="col-sm-6 col-lg-4 col-xl-3">
                    <div class="vs-service">
                        <span class="service-icon" style="border-radius: 91px;"><img src="assets/img/process/Custom-Color-Consultation.jpg" alt="icon" class="rounded-circle"></span>
                        <div class="service-content">
                            <h3 class="service-title h4"><a href="Full-Custom-Color-Transformation.php">Full Refresh Custom Color</a></h3>
                            <p class="service-text">A fashioned knowledge to get the look you want.</p>
                            <br><h3 class="service-title h4"><a href="Full-Custom-Color-Transformation.php">Read More</a></h3>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4 col-xl-3">
                    <div class="vs-service">
                        <span class="service-icon" style="border-radius: 91px;"><img src="assets/img/process/Full-Custom-Color-Transformation.jpg" alt="icon" style="border-radius: 63px;"></span>
                        <div class="service-content">
                            <h3 class="service-title h4"><a href="Partial-Custom-Color-Transformation.php">Partial Refresh Custom Color</a></h3>
                            <p class="service-text">Use partial custom color to revitalize for small maintenance or adjustments.</p><br>
                            <h3 class="service-title h4"><a href="Partial-Custom-Color-Transformation.php">Read More</a></h3>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4 col-xl-3">
                    <div class="vs-service">
                        <span class="service-icon" style="border-radius: 91px;"><img src="assets/img/process/mini.jpg" alt="icon" class="rounded-circle"></span>
                        <div class="service-content">
                            <h3 class="service-title h4"><a href="teens-cut.php">Mini Makeover</a></h3>
                            <p class="service-text">Give Your Hair a Mini Makeover with The Mini</p><br><br>
                            <h3 class="service-title h4"><a href="teens-cut.php">Read More</a></h3>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4 col-xl-3">
                    <div class="vs-service">
                        <span class="service-icon" style="border-radius: 91px;"><img src="assets/img/process/Single-Application-or-Glaze.jpg" alt="icon" style="border-radius: 63px;"></span>
                        <div class="service-content">
                            <h3 class="service-title h4"><a href="Single-Application.php">Single Dose Application</a></h3>
                            <p class="service-text">Every visit, receive precise color applications for vibrant, healthy hair.</p><br>
                            <h3 class="service-title h4"><a href="Single-Application.php">Read More</a></h3>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4 col-xl-3">
                    <div class="vs-service">
                        <span class="service-icon" style="border-radius: 91px;"><img src="assets/img/process/2-Color-Application-Color-Melt.jpg" alt="icon" style="border-radius: 63px;"></span>
                        <div class="service-content">
                            <h3 class="service-title h4"><a href="2-color-application.php">Double Dose Application</a></h3>
                            <p class="service-text">Color mastery in two steps for smooth transitions and long-lasting effects.</p><br>
                            <h3 class="service-title h4"><a href="2-color-application.php">Read More</a></h3>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4 col-xl-3">
                    <div class="vs-service">
                        <span class="service-icon" style="border-radius: 91px;"><img src="assets/img/process/EXPRESS-ROOT-COVERAGE.jpg" alt="icon"  style="border-radius: 63px;"></span>
                        <div class="service-content">
                            <h3 class="service-title h4"><a href="EXPRESS-ROOT-COVERAGE.php">Express Root Touch Up</a></h3>
                            <p class="service-text">Perfect roots in an <br>hour or so.</p>
                            <br><h3 class="service-title h4"><a href="EXPRESS-ROOT-COVERAGE.php">Read More</a></h3>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4 col-xl-3">
                    <div class="vs-service">
                        <span class="service-icon" style="border-radius: 91px;"><img src="assets/img/process/the-works.jpg" alt="icon"  style="border-radius: 63px;"></span>
                        <div class="service-content">
                            <h3 class="service-title h4"><a href="THE-WORKS.php">The Works</a></h3>
                            <p class="service-text">Total makeover for amazing,<br> long-lasting effects. </p><br><br>
                            <h3 class="service-title h4"><a href="THE-WORKS.php">Read More</a></h3>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4 col-xl-3">
                    <div class="vs-service">
                        <span class="service-icon" style="border-radius: 91px;"><img src="assets/img/process/HAIR-DETOX-Add-on.jpg" alt="icon" style="border-radius: 63px;"></span>
                        <div class="service-content">
                            <h3 class="service-title h4"><a href="HAIR-DETOX-Add-on.php">HAIR DETOX Add on</a></h3>
                            <p class="service-text">For vibrant color retention, renew and purify with necessary detoxification procedures.</p><br>
                            <h3 class="service-title h4"><a href="HAIR-DETOX-Add-on.php">Read More</a></h3>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4 col-xl-3">
                    <div class="vs-service">
                        <span class="service-icon" style="border-radius: 91px;"><img src="assets/img/process/IMG_3575.jpeg" alt="icon" class="rounded-circle"></span>
                        <div class="service-content">
                            <h3 class="service-title h4"><a href="teens-cut.php">GREY BLENDING</a></h3>
                            <p class="service-text">Embrace Your Silver Lining with The Silver Blend</p><br><br>
                            <h3 class="service-title h4"><a href="teens-cut.php">Read More</a></h3>
                        </div>
                    </div>
                </div>
                <!--<div class="col-sm-6 col-lg-4 col-xl-3">-->
                <!--    <div class="vs-service">-->
                <!--        <span class="service-icon rounded-circle"><img src="assets/img/process/IMG_3575.jpeg" alt="icon" class="rounded-circle"></span>-->
                <!--        <div class="service-content">-->
                <!--            <h3 class="service-title h4"><a href="Full-Custom-Color-Transformation.php">Full Custom Color Transformation</a></h3>-->
                <!--            <p class="service-text">Personalized color paths to help you reach your dream.</p>-->
                <!--            <br><h3 class="service-title h4"><a href="Full-Custom-Color-Transformation.php">Read More</a></h3>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
            </div>
        </div>
    </section>
    
    <section class=" space spacemargin">
        <div class="container">
            <div class="row justify-content-center text-center">
                <div class="col-md-11 col-lg-8 col-xl-6">
                    <div class="title-area">
                        <h2 class="sec-title">Hair Cut Services</h2>
                        <p>For clear, lasting results, groom your hair with our skillfully created, customized color journeys and restorative treatments.</p>
                    </div>
                </div>
            </div>
            <div class="row gx-10 gy-gx justify-content-center">
                
                <div class="col-sm-6 col-lg-3 col-xl-3">
                    <div class="vs-service">
                        <span class="service-icon" style="border-radius: 91px;"><img src="assets/img/process/HAIRCUT-STYLE.jpg" alt="icon" class='rounded-circle'></span>
                        <div class="service-content">
                            <h3 class="service-title h4"><a href="haircut-style.php">Haircut and style</a></h3>
                            <p class="service-text">With our experienced haircutting and style services, you can get a new look.</p><br><br>
                            <h3 class="service-title h4"><a href="haircut-style.php">Read More</a></h3>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-xl-3">
                    <div class="vs-service">
                        <span class="service-icon" style="border-radius: 91px;"><img src="assets/img/process/SHORT-PIXIE-CLIPPER-CUT.jpg" alt="icon" class="rounded-circle"></span>
                        <div class="service-content">
                            <h3 class="service-title h4"><a href="short-clipper-cut.php">Gender Neutral Pixie/Clipper Cut</a></h3>
                            <p class="service-text">Cuts that are sleek and attractive, made just for you</p><br><br>
                            <h3 class="service-title h4"><a href="short-clipper-cut.php">Read More</a></h3>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-xl-3">
                    <div class="vs-service">
                        <span class="service-icon" style="border-radius: 91px;"><img src="assets/img/process/IMG_4261.jpeg" alt="icon" class="rounded-circle"></span>
                        <div class="service-content">
                            <h3 class="service-title h4"><a href="teens-cut.php">Teens Cut and Style</a></h3>
                            <p class="service-text">Check out our newest teen hairstyles that will enhance their individuality.</p><br><br>
                            <h3 class="service-title h4"><a href="teens-cut.php">Read More</a></h3>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3 col-xl-3">
                    <div class="vs-service">
                        <span class="service-icon" style="border-radius: 91px;"><img src="assets/img/process/IMG_2189.jpeg" class="rounded-circle" alt="icon"></span>
                        <div class="service-content">
                            <h3 class="service-title h4"><a href="kids-cut.php">Kids under 12 Cut and Style</a></h3>
                            <p class="service-text">Expert cuts for youthful vim, designed to please every child.</p><br><br>
                            <h3 class="service-title h4"><a href="kids-cut.php">Read More</a></h3>
                        </div>
                    </div>
                </div>
                
                
            </div>
        </div>
    </section>


    <!--==============================
    Counter Area
    ==============================-->
    <!--<div class="vs-counter-wrapper space-negative bg-light">-->
    <!--    <div class="container">-->
    <!--        <div class="row">-->
    <!--            <div class="col-sm-6 col-lg-3">-->
    <!--                <div class="vs-counter style3 text-center">-->
    <!--                    <div class="counter-icon">-->
    <!--                        <img src="assets/img/icon/counter--1-1.png" alt="Counter icon">-->
    <!--                    </div>-->
    <!--                    <span class="counter-number">3116</span>-->
    <!--                    <p class="counter-text mb-0">Hair Treatments</p>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-sm-6 col-lg-3">-->
    <!--                <div class="vs-counter style3 text-center">-->
    <!--                    <div class="counter-icon">-->
    <!--                        <img src="assets/img/icon/counter--1-2.png" alt="Counter icon">-->
    <!--                    </div>-->
    <!--                    <span class="counter-number">200</span>-->
    <!--                    <p class="counter-text mb-0">Salon Products</p>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-sm-6 col-lg-3">-->
    <!--                <div class="vs-counter style3 text-center">-->
    <!--                    <div class="counter-icon">-->
    <!--                        <img src="assets/img/icon/counter--1-3.png" alt="Counter icon">-->
    <!--                    </div>-->
    <!--                    <span class="counter-number">350</span>-->
    <!--                    <p class="counter-text mb-0">Shades of colors</p>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-sm-6 col-lg-3">-->
    <!--                <div class="vs-counter style3 text-center">-->
    <!--                    <div class="counter-icon">-->
    <!--                        <img src="assets/img/icon/counter--1-4.png" alt="Counter icon">-->
    <!--                    </div>-->
    <!--                    <span class="counter-number">130k</span>-->
    <!--                    <p class="counter-text mb-0">Satisfied Customers</p>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->

               
  <?php include'footer.php'?>


</body>

</html>