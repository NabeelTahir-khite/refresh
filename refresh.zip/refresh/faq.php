<!doctype html>
<html class="no-js" lang="zxx">

 <!-- Favicons - Place favicon.ico in the root directory -->
    <link rel="icon" type="image/png" size="16x16" href="assets/img/logo-1.png">
    <!-- <link rel="manifest" href="assets/img/favicons/manifest.json"> -->

<body>


    <?php include'header.php'?>
    <!--==============================
    Breadcumb
============================== -->
    <div class="breadcumb-wrapper " data-bg-src="assets/img/bg/banner17.jpg">
        <div class="container z-index-common">
            <div class="breadcumb-content text-center">
                <h1 class="breadcumb-title">FAQs</h1>
                <div class="breadcumb-menu-wrap">
                    <ul class="breadcumb-menu">
                        <li><a href="index.php">Home</a></li>
                        <li class="active">FAQs</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

<!--==============================
    Service Area
    ==============================-->
    <section class=" space">
        <div class="container">
            <div class="row justify-content-center text-center">
                <div class="col-md-11 col-lg-8 col-xl-6">
                    <div class="title-area">
                        <h2 class="sec-title">FAQs</h2>
                    </div>
                </div>
            </div>
            <div class="about-space bg-smoke p-3 p-lg-5 mt-1">
            <h3>What is a custom color specialist?</h3>
            <p>As a custom color specialist, we go beyond standard color applications and focus on creating personalized unique color transformations tailored to each client .</p>
            <p class="pe-xl-5 mb-3">We have advanced training and expertise in color theory, blending, and creating custom shades.</p>
            <p class="pe-xl-5 mb-3">As a custom color specialist, we work closely with every client to understand their individual styles, hair texture, goals and desired outcome. There may be a variety of techniques used, including blending multiple colors, to achieve a more nuanced and personalized look to reach your goals.</p>
            <p class="pe-xl-5 mb-3">We have advanced training in gray hair coverage, blending and camouflaging that goes beyond color formulation. As a custom color specialist, we will get to know you and your hair and give you the best possible customized plan for upkeep that works with your lifestyle.</p>
            <p class="pe-xl-5 mb-3">There is no longer a one color technique fits all type of service. In truth there never was. We have always loved more than anything working with a client getting to know them, understanding what they are truly hoping for and educating our clients on the maintenance and follow up that is required.</p>
            <p class="pe-xl-5 mb-3">We give each and every client 100% of my attention during the entire service, never ever allowing a client to over process. Our number one goal is always healthy hair and keeping integrity to your hair which is why we only choose to use some of the best products in the market. All of our color products have a unique formulation that speeds up processing time all while keeping your hair truly healthy.</p>
            <p class="pe-xl-5 mb-3">We pride ourselves on transparency. Every client has a right to know exactly what is going into your hair! It is our job to fully understand what your hair is capable of, as well as educating you on the maintenance required.
            </p>
            <p class="pe-xl-5 mb-3">We can’t emphasize enough how much we love what we do . Our continuing education is a guaranteed. We absolutely love learning and sharing with our clients all the possibilities for the best outcome.
            </p>
            <p class="pe-xl-5 mb-3">We currently working on adding in a consultation form here. This will help us quickly determine where we’re starting at and where we’re heading and give us more time in the salon to simply focus on getting to know you and creating your color transformation. Cause let’s just be real. No one wants to spend hours and hours in the salon. But we definitely all want a little time to either relax or to gossip and let loose. And of course get their hair done.</p>
            <p class="pe-xl-5 mb-3">So, in the meantime, go ahead and fill out the contact request form, along with some photos of your hair and any inspirational photos you might have. And we promise we will get back to you as quickly as possible.
            </p>
            <p class="pe-xl-5 mb-3">We can’t wait to meet you!</p>
            
            </div>
        </div>
    </section>


    <!--==============================
    Counter Area
    ==============================-->
    <!--<div class="vs-counter-wrapper space-negative bg-light">-->
    <!--    <div class="container">-->
    <!--        <div class="row">-->
    <!--            <div class="col-sm-6 col-lg-3">-->
    <!--                <div class="vs-counter style3 text-center">-->
    <!--                    <div class="counter-icon">-->
    <!--                        <img src="assets/img/icon/counter--1-1.png" alt="Counter icon">-->
    <!--                    </div>-->
    <!--                    <span class="counter-number">3116</span>-->
    <!--                    <p class="counter-text mb-0">Hair Treatments</p>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-sm-6 col-lg-3">-->
    <!--                <div class="vs-counter style3 text-center">-->
    <!--                    <div class="counter-icon">-->
    <!--                        <img src="assets/img/icon/counter--1-2.png" alt="Counter icon">-->
    <!--                    </div>-->
    <!--                    <span class="counter-number">200</span>-->
    <!--                    <p class="counter-text mb-0">Salon Products</p>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-sm-6 col-lg-3">-->
    <!--                <div class="vs-counter style3 text-center">-->
    <!--                    <div class="counter-icon">-->
    <!--                        <img src="assets/img/icon/counter--1-3.png" alt="Counter icon">-->
    <!--                    </div>-->
    <!--                    <span class="counter-number">350</span>-->
    <!--                    <p class="counter-text mb-0">Shades of colors</p>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--            <div class="col-sm-6 col-lg-3">-->
    <!--                <div class="vs-counter style3 text-center">-->
    <!--                    <div class="counter-icon">-->
    <!--                        <img src="assets/img/icon/counter--1-4.png" alt="Counter icon">-->
    <!--                    </div>-->
    <!--                    <span class="counter-number">130k</span>-->
    <!--                    <p class="counter-text mb-0">Satisfied Customers</p>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->

               
  <?php include'footer.php'?>


</body>

</html>