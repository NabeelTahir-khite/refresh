<?php 

$servername = "localhost";
$username = "linkcom_linkcom_refresh_admin_u";
$password = "J1g&a5IX(i{-";
$dbname = "linkcom_refresh_admin_db";
$conn = mysqli_connect($servername, $username, $password, $dbname);

?>