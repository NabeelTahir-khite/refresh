<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Refresh Hair Studio</title>
    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


    <!--==============================
	    All CSS File
	============================== -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Handlee&family=Open+Sans:wght@400;600&family=Syne:wght@600;700&display=swap" rel="stylesheet">


    <!-- Favicons - Place favicon.ico in the root directory -->
    <link rel="icon" type="image/png" size="192x192" href="assets/img/logo-fav.png">
    <!-- <link rel="manifest" href="assets/img/favicons/manifest.json"> -->
    

    <!--==============================
	    All CSS File
	============================== -->
    <!-- Bootstrap -->
    <!-- <link rel="stylesheet" href="assets/css/app.min.css"> -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <!-- Fontawesome Icon -->
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <!-- Layerslider -->
    <link rel="stylesheet" href="assets/css/layerslider.min.css">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="assets/css/magnific-popup.min.css">
    <!-- Slick Slider -->
    <link rel="stylesheet" href="assets/css/slick.min.css">
    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    
    
    
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


<style>
.dropdown-submenu {
  position: relative;
}

.submanu{
    border: 2px solid #d03673;
    border-radius: 2px;
}

.submanumanu{
    top: 0px !important;
    margin-left: 193px !important;
    border: 2px solid #d03673;
    border-radius: 2px;
}

.submanumanus{
    top: 0px !important;
    margin-left: 193px !important;
    border: 2px solid #d03673;
    border-radius: 2px;
}

.dropdown-submenu .dropdown-menu {
  top: 110px;
  left: 0%;
  margin-top: -1px;
}
.innerstyle{
    font-size: 17px;
    line-height: 2;
    font-weight: bold;
}

.dropdown-menu>li>a {
    display: block;
    padding: 3px 20px;
    clear: both;
    font-weight: 400;
    line-height: 1.42857143;
    color: #333;
    white-space: nowrap;
    font-size: 17px;
    line-height: 2;
    font-weight: bold;
    width: 100%;
}

.setui{
    width: 100%;
}

.setui:hover {
    width: 100%;
    color: white;
    background: #C53578;
}

.dropdown-menu>li>a:hover {
     width: 100%;
    color: white;
    background: #C53578;
}
</style>
    

</head>
<!--[if lte IE 9]>
    	<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
  <![endif]-->



    <!--********************************
   		Code Start From Here 
	******************************** -->




    <!--==============================
     Preloader
  ==============================-->
  <div class="preloader  ">
        <button class="vs-btn preloaderCls">Cancel Preloader </button>
        <div class="preloader-inner">
            <img src="assets/img/logo-loader.png" alt="Haarino">
            <span class="loader"></span>
        </div>
    </div>
    <!--==============================
    Mobile Menu
  ============================== -->
    <div class="vs-menu-wrapper">
        <div class="vs-menu-area text-center">
            <button class="vs-menu-toggle"><i class="fal fa-times"></i></button>
            <div class="mobile-logo">
                <a href="index.php"><img src="assets/img/logo-1.png" alt="Haarino"></a>
            </div>
            <div class="vs-mobile-menu">
                <ul>
                    <li class="menu-item-has-children">
                        <a href="index.php">Home</a>
                       
                    </li>
                    <li>
                        <a href="our-stylist.php">Our Stylist</a>
                    </li>
                    
                    <li class="menu-item-has-children">
                        <a href="services.php">Services</a>
                        <ul class="sub-menu">
                        <!--<li><a href="Full-Custom-Color-Transformation.php">Full Custom Color Transformation</a></li>-->
                        <li><a href="Full-Custom-Color-Transformation.php"></a>Full Refresh Custom Color</li>
                        <li><a href="Partial-Custom-Color-Transformation.php">Partial Refresh Custom Color</a></li>
                        <li><a href="the-mini.php">Mini Makeover</a></li>
                        <li><a href="Single-Application.php">Single Dose Application</a></li>
                        <li><a href="2-color-application.php">Double Dose Application</a></li>
                        <li><a href="EXPRESS-ROOT-COVERAGE.php">Express Root Touch Up</a></li>
                        <li><a href="THE-WORKS.php">The Works</a></li>
                        <li><a href="HAIR-DETOX-Add-on.php">Hair Detox Add On</a></li>
                        <li><a href="grey-blending.php">Grey Blending</a></li>
                        <li><a href="haircut-style.php">Haircut and style</a></li>
                        <li><a href="short-clipper-cut.php">Gender Neutral Pixie/Clipper Cut</a></li>
                        <li><a href="teens-cut.php">Teens Cut and Style</a></li>
                        <li><a href="kids-cut.php">Kids under 12 Cut and Style</a></li>
                        
                        
                            
                        </ul>
                    </li>

                    <li>
                       <a href="social.php">Social</a>
                    </li>
                    
                    
                    
                    <li>
                        <a href="product.php">Products</a>
                    </li>
                    <li>
                        <a href="faq.php">FAQs</a>
                    </li>
                    <li>
                        <a href="contact.php">Contact</a>
                    </li>
                    <li>
                          <a href="consultation.php">Consult Now</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!--==============================
        Header Area
    ==============================-->
    <header class="vs-header header-layout1">
        <!-- Header Top Area -->
        <div class="header-top py-15 d-none d-sm-block">
            <div class="container">
                <div class="row align-items-center justify-content-center justify-content-lg-between">
                    <div class="col-sm-auto d-none d-lg-block">
                        <p class="m-0 fw-semibold text-white"><i class="fal fa-map-marker-alt me-2"></i> <a href="#" class="text-reset">Locate a Salon</a></p>
                    </div>
                    <div class="col-auto">
                        <div class="header-info-list text-white">
                            <ul>
                                <li><i class="fas fa-phone-alt"></i>Phone: <a class="text-reset" href="tel:(773) 815-7576">(773) 815-7576</a></li>
                                <li><i class="fal fa-envelope"></i>Email: <a class="text-reset" href="mailto:info@refreshhairstudiochicago.com">info@refreshhairstudiochicago.com</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="sticky-wrapper">
            <div class="sticky-active">
                <!-- Main Menu Area -->
                <div class="header-inner">
                    <div class="container">
                        <div class="row align-items-center justify-content-between">
                            <div class="col-7 col-sm-auto order-1">
                                <div class="header-logo py-2 py-lg-0">
                                    <a href="index.php"><img src="assets/img/logo-1.png" alt="Haarino"></a>
                                </div>
                            </div>
                            <div class="col-auto order-3 order-sm-2">
                                <nav class="main-menu menu-style1 d-none d-lg-block">
                                    <ul>
                                        <li class="menu-item-has-children">
                                            <a href="index.php"><span class="has-new-lable">Home</a>
                                            
                                        </li>
                                       
                                        <!--<li class="menu-item-has-children mega-menu-wrap">-->
                                        <!--    <a href="services.php"><span class="has-new-lable">Services</span></a>-->
                                        <!--    <ul class="mega-menu">-->
                                        <!--        <li><a href="#">Color Services</a>-->
                                        <!--            <ul>-->
                                                        
                                        <!--                <li><a href="Full-Custom-Color-Transformation.php">Full Custom Color Transformation</a></li>-->
                                        <!--                <li><a href="Partial-Custom-Color-Transformation.php">Full Refresh Custom Color</a></li>-->
                                        <!--                <li><a href="Single-Application.php">Single Dose Application</a></li>-->
                                        <!--                <li><a href="2-color-application.php">Double Dose Application</a></li>-->
                                        <!--                <li><a href="EXPRESS-ROOT-COVERAGE.php">Express Root Touch Up</a></li>-->
                                        <!--                <li><a href="THE-WORKS.php">The Works</a></li>-->
                                                        
                                                        
                                        <!--            </ul>-->
                                        <!--        </li>-->
                                        <!--        <li><a href="#" style="color: white;">Color Services</a>-->
                                        <!--            <ul>-->
                                                     
                                        <!--                <li><a href="HAIR-DETOX-Add-on.php">Hair Detox Add On</a></li>-->
                                        <!--                <li><a href="Custom-Color-Consultation.php">Partial Refresh Custom Color</a></li>-->
                                        <!--                <li><a href="the-mini.php">The Mini</a></li>-->
                                        <!--                <li><a href="grey-blending.php">Grey Blending</a></li>   -->
                                        <!--            </ul>-->
                                        <!--        </li>-->
                                                
                                                
                                        <!--        <li><a href="#">Haircuts</a>-->
                                        <!--            <ul>-->
                                        <!--                <li><a href="haircut-style.php">Haircut and style</a></li>-->
                                        <!--                <li><a href="short-clipper-cut.php">Gender Neutral Pixie/Clipper Cut</a></li>-->
                                        <!--                <li><a href="kids-cut.php">Kids under 12 Cut and Style</a></li>-->
                                        <!--                <li><a href="teens-cut.php">Teens Cut and Style</a></li>-->
                                                        
                                        <!--            </ul>-->
                                        <!--        </li>-->
                                        <!--    </ul>-->
                                        <!--</li>-->
                                        
                                        
                                        <li class="dropdown-submenus">
                                        <a class="tests" tabindex="-1" href="services.php">Services<span class="caret"></span></a>
                                        <ul class="dropdown-menu submanus">
                                          <li class="setui"><a tabindex="-1" href="services.php">All Services</a></li>
                                          <li class="dropdown-submenus setui">
                                            <a class="test" href="#">Hair Color Services<span class="caret"></span></a>
                                            <ul class="dropdown-menu submanumanu">
                                                <li class="setui"><a href="Full-Custom-Color-Transformation.php">Full Refresh Custom Color</a></li>
                                                <li class="setui"><a href="Partial-Custom-Color-Transformation.php">Partial Refresh Custom Color</a></li>
                                                <li class="setui"><a href="the-mini.php">Mini Makeover</a></li></br>
                                                <li class="setui"><a href="Single-Application.php">Single Dose Application</a></li>
                                                <li class="setui"><a href="2-color-application.php">Double Dose Application</a></li>
                                                <li class="setui"><a href="EXPRESS-ROOT-COVERAGE.php">Express Root Touch Up</a></li>
                                                <li class="setui"><a href="THE-WORKS.php">The Works</a></li>
                                                <li class="setui"><a href="HAIR-DETOX-Add-on.php">Hair Detox Add On</a></li>
                                                <!--<li><a href="Full-Custom-Color-Transformation.php">Full Custom Color Transformation</a></li>-->
                                                <li class="setui"><a href="grey-blending.php">Grey Blending</a></li>   
                                            </ul>
                                          </li>
                                          <li class="dropdown-submenus setui" >
                                            <a class="test" href="#">Hair Cut Services<span class="caret"></span></a>
                                            <ul class="dropdown-menu submanumanus">
                                                    <li class="setui"><a href="haircut-style.php">Haircut and style</a></li>
                                                    <li class="setui"><a href="short-clipper-cut.php">Gender Neutral Pixie/Clipper Cut</a></li>
                                                    <li class="setui"><a href="teens-cut.php">Teens Cut and Style</a></li>
                                                    <li class="setui"><a href="kids-cut.php">Kids under 12 Cut and Style</a></li>
                                                    
                                            </ul>
                                          </li>
                                        </ul>
                                      </li>


                                        <li>
                                            <a href="our-stylist.php">Our Stylist</a>
                                        </li>

                                        <li>
                                            <a href="social.php">Social</a>
                                        </li>
                                        
                                         <li>
                                            <a href="product.php">Product</a>
                                        </li>
                                        <li>
                                        <a href="faq.php">FAQs</a>
                                        </li>
                                        <li>
                                                <a href="contact.php">Contact</a>
                                        </li>
                                        
                                    </ul>
                                </nav>
                            </div>
                            <div class="col-5 col-sm-auto order-2 order-sm-3 text-end">
                                <div class="header-btn">
                                    <a href="#" class="cart-icon me-4 me-lg-3 mr-xl-0"><i class="fal fa-shopping-cart"></i><span class="badge">1</span></a>
                                    <a href="consultation.php" class="vs-btn d-none d-xl-inline-block">Consult Now</a>
                                    <button class="vs-menu-toggle d-inline-block d-lg-none"><i class="fas fa-bars"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <script>
// $(document).ready(function(){
//   $('.dropdown-submenu a.test').on("click", function(e){
//     $(this).next('ul').toggle();
//     e.stopPropagation();
//     e.preventDefault();
//   });
// });
$(document).ready(function(){
  $('.dropdown-submenus').hover(
    function(e) {
      $(this).children('ul').stop(true, true).slideDown('fast');
      e.stopPropagation();
      e.preventDefault();
    },
    function(e) {
      $(this).children('ul').stop(true, true).slideUp('fast');
      e.stopPropagation();
      e.preventDefault();
    }
  );
});
</script>