 <!doctype html>
<html class="no-js" lang="zxx">

 <!-- Favicons - Place favicon.ico in the root directory -->
    <link rel="icon" type="image/png" size="16x16" href="assets/img/logo-1.png">
    <!-- <link rel="manifest" href="assets/img/favicons/manifest.json"> -->

<body>
    <?php include'header.php'?>
   
    
    <style>
        .fontcolor
        {
            color: #c73475 !important;
            font-weight: bold;
        }
    </style>


    
    <div class="breadcumb-wrapper" data-bg-src="assets/img/bg/banner11.jpg">
        <div class="container z-index-common">
            <div class="breadcumb-content text-center">
                <h1 class="breadcumb-title">Thank <span class="inner-text">You</span></h1>
                <div class="breadcumb-menu-wrap">
                    <ul class="breadcumb-menu">
                        <li><a href="index.html">Home</a></li>
                        <li><span class="inner-text">Thank You</span></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<section class="space-extra-bottom">
    <!--<h2 class="sec-title text-center my-4">Consultation <span class="text-theme">Form</span></h2>-->

    <div class="mt-5 space-negative-bottom container consult d-flex justify-content-center">
        
            <div class="form-container" style="color: #3c813c;">
                <h3>Thank you for filling this out. We will get back to you as soon as posible!</h3>
                
            </div>
        
    </div>
</section>
 
 <?php include'footer.php'?>
</body>

</html>