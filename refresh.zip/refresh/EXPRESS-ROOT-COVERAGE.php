<!doctype html>
<html class="no-js" lang="zxx">
 <!-- Favicons - Place favicon.ico in the root directory -->
    <link rel="icon" type="image/png" size="16x16" href="assets/img/logo-1.png">
    <!-- <link rel="manifest" href="assets/img/favicons/manifest.json"> -->



<body>


    <?php include'header.php'?>
    <!--==============================
    Breadcumb
============================== -->
    <div class="breadcumb-wrapper " data-bg-src="assets/img/bg/banner10.jpg">
        <div class="container z-index-common">
            <div class="breadcumb-content text-center">
                <h1 class="breadcumb-title">Express Root Touch Up</h1>
                <div class="breadcumb-menu-wrap">
                    <ul class="breadcumb-menu">
                        <li><a href="index.php">Home</a></li>
                        <li class="active">Express Root Touch Up</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!--==============================
  Team Area
  ============================== -->
    <section class="vs-team-details space-top space-negative-bottom">
        <div class="container">
            <div class="row justify-content-around">
                <!--<div class="col-lg-6 mb-30">-->
                <!--    <div class="position-relative">-->
                <!--        <div class=" " data-mask-src="assets/img/shape/team-mask-2.png"></div>-->
                <!--        <div >-->
                <!--            <img src="assets/img/about/about-1-1.jpg" alt="member Image" class="w-100">-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <div class="col-lg-12 col-xl-12 mb-30 align-self-center">
                    <div class="team-details-content">
                        <h2 class="member-name h3 mb-0 fw-semibold">Refresh Your Roots, Refine Your Look: Express Root Touch-Up at Refresh Hair Studio</h2>
                        <span class="member-degi">Looking to revive your color and banish grays, but short on time? Look no further than our <strong>Express Root Touch-Up</strong> service at Refresh Hair Studio! This efficient and effective service is designed to get you back to your busy life with gorgeous, refreshed roots in under an hour.</span>
                        <div class="row mt-4 mt-xl-3">
                            <div class="col-sm-6 col-lg-6 col-xl-6 mb-20">
                                <h3 class="fw-semibold fs-22 mb-1 mb-lg-2">Fast & Flawless with Magic 10:</h3>
                                <p class="mb-0">Our Express Root Touch-Up utilizes the power of <strong>Magic 10</strong>, a revolutionary color system that delivers exceptional results in just 10 minutes. This innovative formula provides:</p>
                                <ul>
                                    <li><strong>Full Gray Coverage:</strong> Say goodbye to unwanted grays! Magic 10 effectively covers even the most stubborn grays, leaving your hair looking youthful and uniform.</li>
                                    <li><strong>Seamless Blending:</strong> Achieve a natural, flawless finish. Magic 10 blends seamlessly with your existing hair color, eliminating harsh lines and creating a beautiful, multi-dimensional effect.</li>
                                </ul>
                                <br>
                                <a href="https://booksy.com/en-us/644713_refresh-hair-studio-chicago_hair-salon_18229_chicago/staffer/1077596#ba_s=sh_1" class="vs-btn mb-30"> BOOK NOW</a>
                            </div>
                            <div class="col-sm-6 col-lg-6 col-xl-6 mb-20">
                                <h3 class="fw-semibold fs-22 mb-1 mb-lg-2">The Express Advantage:</h3>
                                <ul>
                                    <li><strong>Time-Saving Efficiency:</strong> In and out in under an hour! Our experienced stylists work efficiently to ensure your root touch-up is completed quickly, without compromising quality.</li>
                                    <li><strong>Convenience for Busy Lifestyles:</strong> We understand your time is valuable. This express service is perfect for those who need a quick refresh but can't spare hours in the salon.</li>
                                    <li><strong>Beautiful Finish Included:</strong> Your Express Root Touch-Up doesn't stop at color. We'll complete your look with a beautiful blow-dry or style, leaving you ready to take on the day with confidence.</li>
                                </ul>
                                <br>
                                <a href="consultation.php" class="vs-btn mb-30"> CONSULT NOW</a>
                            </div>
                        </div>
                        <div class="vs-social style2 hover-black">
                            <h3 class="fw-semibold fs-22 mb-3">Follow On</h3>
                            <ul>
                               <li><a href="https://www.facebook.com/RefreshHairStudioChicago/?_rdr"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="https://goo.gl/maps/dWeauU3M7baxohVSA"><i class="fab fa-google-plus-g"></i></a></li>
                                <li><a href="https://www.instagram.com/refreshhairstudio/"><i class="fab fa-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="team-details-desc mt-4 pt-1">
                <h2 class="inner-title-style2">The Perfect Choice For</h2>
                <ul>
                    <li>Busy professionals on the go</li>
                    <li>Clients seeking a quick refresh between full color appointments</li>
                    <li>Those with minimal gray growth who want to maintain a youthful appearance</li>
                </ul>
                <h2 class="inner-title-style2">Ready to Experience the Express Root Touch-Up Difference?</h2>
                <p>Schedule your appointment at Refresh Hair Studio today! During your consultation, our stylists will assess your hair and discuss your desired outcome to ensure a perfect color match and a flawless finish.</p>
                <div class="row g-3 my-1 my-lg-3 my-xl-3 py-xl-3">
                    <div class="col-md-3">
                        <div class="image-scale-hover">
                            <img src="assets/img/about/IMG_3018.jpeg" alt="About Image" class="w-100" style="height:420px;">
                            <!--<img src="assets/img/about/265373225_877167479659725_5310604177479235356_n.jfif" alt="About Image" class="w-100" style="height:420px;">-->
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="image-scale-hover position-relative">
                            <img src="assets/img/about/IMG_3625.jpeg" alt="About Image" class="w-100">
                            <!--<img src="assets/img/about/445756188_3888984471331523_2245895959415917550_n.jpg" alt="About Image" class="w-100">-->
                            
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="image-scale-hover">
                            <img src="assets/img/about/IMG_4015.jpeg" alt="About Image" class="w-100" style="height:420px;">
                            <!--<img src="assets/img/about/280228375_400114088453060_8090924754591879444_n.jpg" alt="About Image" class="w-100" style="height:420px;">-->
                        </div>
                    </div>
                </div>
                <p class="mt-4 pt-2">Leave the grays behind and embrace refreshed, radiant hair with our Express Root Touch-Up service. Book your appointment today and experience the Refresh Hair Studio difference!</p>
                <p class="mt-4 pt-2"><strong>This service is $100 and books for 1 hour including a finished style ready for you to conquer your day.</strong></p>
                 <!--==============================
                            Testimonial Area
        ============================== -->
    <section class="vs-testimonial-wrapper space-bottom space-top">
        <div class="container position-relative">
           

            
            <div class="row justify-content-center">
            <?php
                include_once 'google-reviews.php';
            ?>
            
                <div class="col-lg-9 col-xl-7">
              
                    <div class="vs-carousel" id="testimonialslide1" data-asnavfor="#avaterfly" data-fade="true" data-slide-show="1" data-md-slide-show="1">
                    


                        <!-- <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>Jamie does a n amazing job every time I see her She is always cautious and listens attentively to what the client wants. She is always honest and does not tryto sell you into doing more than what you asked for and will not lie if she believes what you are asking for might not work. I will not go to anyone else. She is extremely knowledgeable, honest, caring and personable. And she will go out of her way to make sure you ae comfortable during your styling and happy with your end results, Jamie is truly one of the very best</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Amy Jo</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div>
                        <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>I've been getting my short hair/pixie cut done by Jamie for years and she never disappoints! Jamie's amazing at both cutting and coloring hair and is super friendly, as well. Before Jamie, I went to a bunch of places in Chicago and could never really find the perfect pixie cut but she really gets it. Thank you Jamie!!!</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Katie F</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div>
                        <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>Absolutely stunning results, hair has dimension, shine, and feels amazing. Jaime is an absolute joy to spend time with and makes the experience feel so personal yet luxurious. 5 stars isn't enough!!!</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Kellie E</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div>
                        <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>I had such a great experience at Jamie's salon! She is down to earth and super friendly, and absolutely love the color and cut she gave me!</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Rachel</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div>
                        <div class="vs-testimonial">
                            <span class="quote-icon"><img src="assets/img/icon/quote.png" alt="Quote Icon"></span>
                            <div class="testimonial-desc">
                                <p>Jamie is hands down the best. For years she's been the only one I've let do my hair. She always seems to understand what I want and what would work best for my hair. She's a consummate professional and an incredibly kind and friendly human to boot. Cannot recommend her enough1</p>
                            </div>
                            <div class="author">
                                <h3 class="author-name">Esther S</h3>
                                <span class="author-degi">Client</span>
                            </div>
                        </div> -->

                    </div>
                </div>

            </div>
            
         </div>
        

               

            </div>
        </div>
    </section>
  <?php include'footer.php'?>


</body>

</html>