  <!--==============================
			Footer Area
	==============================-->
    <footer class="footer-wrapper footer-layout1 bg-dark">
        <div class="widget-area">
            <div class="container">
                <div class="row justify-content-between">
                    <div class="col-md-12 col-lg-4">
                        <div class="widget footer-widget pt-0  ">
                            <!--<h3 class="widget_title">About Us</h3>-->
                            <div class="vs-widget-about">
                                <div class="footer-logo mb-3">
                                  <a href="index.php"><img src="assets/img/footer-logo.png" alt="Refresh" class="w-50"></a>
                                </div>
                                <p class="pe-xl-5 mb-3">My course involved cutting, colouring, relaxing and all sort of hair treatments Available for Appointment.</p>
                                <div class="footer-rating">
                                                                        <a href="https://www.google.com/search?q=refreshhairstudiochicago&rlz=1C1RLNS_enPK1093PK1093&oq=refreshhairstudiochicago&gs_lcrp=EgZjaHJvbWUyBggAEEUYOTIGCAEQRRg8Mg8IAhAuGA0YrwEYxwEYgAQyBggDEEUYQDINCAQQABiGAxiABBiKBTINCAUQABiGAxiABBiKBTIGCAYQRRg8MgYIBxBFGDzSAQgyNTU2ajBqN6gCALACAA&sourceid=chrome&ie=UTF-8"><img class="google-review" src="assets/img/icon/6293824a30fb025780ee295d.png" alt="Girl in a jacket" width="500" height="600"></a>
                                    <p class="text-uppercase text-white mb-0"><a class="text-inherit" href="https://www.google.com/search?q=refreshhairstudiochicago&rlz=1C1RLNS_enPK1093PK1093&oq=refreshhairstudiochicago&gs_lcrp=EgZjaHJvbWUyBggAEEUYOTIGCAEQRRg8Mg8IAhAuGA0YrwEYxwEYgAQyBggDEEUYQDINCAQQABiGAxiABBiKBTINCAUQABiGAxiABBiKBTIGCAYQRRg8MgYIBxBFGDzSAQgyNTU2ajBqN6gCALACAA&sourceid=chrome&ie=UTF-8">5 Star - 33+ Google reviews</a></p>
                                    
                                    <!--<div class="text-theme fs-16">-->
                                    <!--    <i class="fas fa-star"></i>-->
                                    <!--    <i class="fas fa-star"></i>-->
                                    <!--    <i class="fas fa-star"></i>-->
                                    <!--    <i class="fas fa-star"></i>-->
                                    <!--    <i class="fas fa-star"></i>-->
                                    <!--</div>-->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 col-xl-3">
                        <div class="widget footer-widget  ">
                            <h3 class="widget_title">Contact Us</h3>
                            <div class="vs-widget-about">
                                <p class="footer-info"><i class="fas fa-map-marker-alt"></i>2232 W Lawrence Ave, Chicago, IL 60625</p>
                                <p class="footer-info"><i class="fas fa-envelope"></i><a class="text-inherit" href="mailto:info@refreshhairstudiochicago.com">info@refreshhairstudiochicago.com</a></p>
                                <p class="footer-info"><i class="fas fa-phone-alt"></i>Tel: <a class="text-inherit" href="tel:(773) 815-7576">(773) 815-7576</a></p>
                            </div>
                            <h3 class="widget_title mt-3">Company</h3>
                            <div class="vs-widget-about">
                                <p class="footer-info"><a class="text-inherit" href="privacy-policy.php">Privacy Policy</a></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-4 col-xl-3">
                        <div class="widget footer-widget   ">
                            <h3 class="widget_title">Openinng Hours</h3>
                            <div class="footer-table text-white">
                                <table>
                                    <tr>
                                        <td>Mon - Fri:</td>
                                        <td>11am - 8pm</td>
                                    </tr>
                                    <tr>
                                        <td>Saturday:</td>
                                        <td>10am - 7pm</td>
                                    </tr>
                                    <tr>
                                        <td>Sunday:</td>
                                        <td>Closed</td>
                                    </tr>
                                </table>
                                <!--<p class="pe-xl-5 mb-3">Days and times are flexible. If you can’t find a time that works for you on Booksy please text me. I will work with you to find a time that does!</p>-->
                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer-instagram pt-30" data-pos-for=".copyright-wrap" data-sec-pos="bottom-half">
                    <div class="row vs-carousel" data-slide-show="6" data-lg-slide-show="5" data-md-slide-show="4" data-sm-slide-show="3" data-xs-slide-show="2">
                        <div class="col-md-2">
                            <div class="gallery-thumb">
                                <img src="assets/img/insta/gallery-14.jpg" class="w-100" alt="Thumb Image">
                                <a href="assets/img/insta/gallery-14.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="gallery-thumb">
                                <img src="assets/img/insta/gallery-1.jpeg" class="w-100" alt="Thumb Image">
                                <a href="assets/img/insta/gallery-1.jpeg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="gallery-thumb">
                                <img src="assets/img/insta/gallery-2.jpg" class="w-100" alt="Thumb Image">
                                <a href="assets/img/insta/gallery-2.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="gallery-thumb">
                                <img src="assets/img/insta/gallery-3.jpg" class="w-100" alt="Thumb Image">
                                <a href="assets/img/insta/gallery-3.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="gallery-thumb">
                                <img src="assets/img/insta/gallery-6.jpg" class="w-100" alt="Thumb Image">
                                <a href="assets/img/insta/gallery-6.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="gallery-thumb">
                                <img src="assets/img/insta/gallery-5.jpg" class="w-100" alt="Thumb Image">
                                <a href="assets/img/insta/gallery-5.jpg" class="icon-thumb popup-image"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright-wrap bg-theme">
            <div class="container">
                <div class="row  py-30 align-items-center justify-content-between">
                    <div class="col-lg-auto text-center text-lg-end">
                        <p class="mb-0 text-white">Copyright <i class="fal fa-copyright"></i> <?=date('Y');?> <a class="text-white" href="https://expertswebdesigns.com/">Experts Web Designs</a> - All rights reserved.</p>
                    </div>
                    <div class="col-auto d-none d-lg-block">
                        <div class="vs-social">
                            <ul>
                                <li><a href="https://www.facebook.com/RefreshHairStudioChicago/"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="https://goo.gl/maps/dWeauU3M7baxohVSA"><i class="fab fa-google-plus-g"></i></a></li>
                                <li><a href="https://www.instagram.com/refreshhairstudio/"><i class="fab fa-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--********************************
                Code End  Here 
        ******************************** -->


    <!-- Scroll To Top -->
    <a href="#" class="scrollToTop scroll-btn"><i class="far fa-arrow-up"></i></a>



    <!--==============================
        All Js File
    ============================== -->




  
    <!-- Jquery -->
    <script src="assets/js/vendor/jquery.min.js"></script>
    <!-- Slick Slider -->
    <!-- <script src="assets/js/app.min.js"></script> -->
    <script src="assets/js/slick.min.js"></script>
    <!-- Layerslider -->
    <script src="assets/js/layerslider.utils.js"></script>
    <script src="assets/js/layerslider.transitions.js"></script>
    <script src="assets/js/layerslider.kreaturamedia.jquery.js"></script>
    <!-- Bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Magnific Popup -->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>
    <!-- Isotope Filter -->
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <!-- Custom Carousel -->
    <script src="assets/js/vscustom-carousel.min.js"></script>
    <!-- Form Js -->
    <script src="assets/js/ajax-mail.js"></script>
    <!-- Main Js File -->
    <script src="assets/js/main.js"></script>

    <script>
    document.addEventListener('DOMContentLoaded', (event) => {
            const videos = document.querySelectorAll('.card-video video');

            videos.forEach(video => {
                video.addEventListener('mouseenter', () => {
                    video.play();
                });

                video.addEventListener('mouseleave', () => {
                    video.pause();
                });
            });


        });


    </script>